//
//  DataAdapter.swift
//  cbl-reactnative
//
//  Created by Aaron LaBeau on 7/24/24.
//

import Foundation
import CouchbaseLiteSwift
import React


public class DataAdapter {
    
    // MARK: - Singleton
    public static let shared = DataAdapter()
    
    // MARK: - Private initializer to prevent external instantiation
    private init() {
        // Initialization code here
    }
    
    // Returns nil for an out-of-range value so the caller can reject it, rather than
    // silently running a different (possibly expensive) maintenance operation than requested.
    public func adaptMaintenanceTypeFromInt(intValue: Int) -> MaintenanceType? {
        switch intValue {
            case 0:
                return .compact
            case 1:
                return .reindex
            case 2:
                return .integrityCheck
            case 3:
                return .optimize
            case 4:
                return .fullOptimize
            default:
                return nil
        }
        
    }
    
    public func adaptCollectionArgs(name: String, collectionName: String, scopeName: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, CollectionArgs) {
        let args = CollectionArgs()
        let scopeArgsResults = self.adaptScopeArgs(name: name, scopeName: scopeName, reject: reject)
        if scopeArgsResults.0 {
            return (true, args)
        }
        guard self.validateRequired(collectionName, field: "Collection Name", code: "DATABASE_ERROR", reject: reject) else {
            return (true, args)
        }
        args.databaseName = scopeArgsResults.1.databaseName
        args.scopeName = scopeArgsResults.1.scopeName
        args.collectionName = collectionName
        return (false, args)
    }
    
    public func adaptDocumentArgs(docId: String, concurrencyControlValue: NSNumber, reject: @escaping RCTPromiseRejectBlock) -> (Bool, DocumentArgs) {
        let args = DocumentArgs()

        let documentArgs = self.adaptNonEmptyString(value: docId, propertyName: "docId", reject: reject)
        if documentArgs.0 {
            return (true, args)
        }
        args.documentId = documentArgs.1

        if concurrencyControlValue == -9999 {
            args.concurrencyControlValue = nil
            return (false, args)
        }

        guard
            let uint8Value = UInt8(exactly: concurrencyControlValue),
            let cc = ConcurrencyControl(rawValue: uint8Value)
        else {
            reject(
                "DOCUMENT_ERROR",
                "Error: concurrencyControlValue \(concurrencyControlValue) is not a valid ConcurrencyControl",
                nil
            )
            return (true, args)
        }
        args.concurrencyControlValue = cc
        return (false, args)
    }

    public func adaptDocumentBlobStrings(document: String, blobs: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, DocumentBlobArgs) {
        let args = DocumentBlobArgs()
        guard self.validateRequired(document, field: "document", code: "ERROR", reject: reject) else {
            return (true, args)
        }
        guard self.validateRequired(blobs, field: "blobs", code: "ERROR", reject: reject) else {
            return (true, args)
        }
        args.document = document
        args.blobs = blobs
        return (false, args)
    }

    public func adaptScopeArgs(name: String, scopeName: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, ScopeArgs) {
        let args = ScopeArgs()
        guard self.validateRequired(name, field: "Database Name", code: "DATABASE_ERROR", reject: reject) else {
            return (true, args)
        }
        guard self.validateRequired(scopeName, field: "Scope Name", code: "DATABASE_ERROR", reject: reject) else {
            return (true, args)
        }
        args.databaseName = name
        args.scopeName = scopeName
        return (false, args)
    }
    
    public func adaptCollectionToNSDictionary(_ collection: Collection, databaseName: String) -> NSDictionary {
        // databaseName here holds the value the bridge received as
        // `databaseUniqueName` — always the unique runtime handle.
        let dict: NSDictionary = [
            "databaseUniqueName": databaseName as NSString,
            "scope":              collection.scope.name as NSString,
            "collection":         collection.name as NSString
        ]
        return dict
    }
    
    public func adaptCollectionsToNSDictionaryString(_ collections: [Collection]?, databaseName: String) -> NSArray {
        let data = NSMutableArray()
        if let cols = collections {
            for collection in cols {
                let dict = self.adaptCollectionToNSDictionary(collection, databaseName: databaseName)
                data.add(dict)
            }
        }
        let result = data.copy() as! NSArray
        return result
    }
    
    public func adaptScopeToNSDictionary(_ scope: Scope, databaseName: String) -> NSDictionary {
        let dict: NSDictionary = [
            "databaseUniqueName": databaseName as NSString,
            "scope":              scope.name as NSString
        ]
        return dict
    }
    
    public func adaptScopesToNSDictionary(_ scopes: [Scope]?, databaseName: String) -> NSArray {
        let data = NSMutableArray()
        if let unwrappedScopes = scopes {
            for scope in unwrappedScopes {
                let dict = self.adaptScopeToNSDictionary(scope, databaseName: databaseName)
                data.add(dict)
            }
        }
        let result = data.copy() as! NSArray
        return result
    }
    
    public func adaptDatabaseName(name: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, String) {
        let isValid = self.validateRequired(name, field: "Database Name", code: "DATABASE_ERROR", reject: reject)
        return (!isValid, name)
    }
    
    public func adaptReplicatorId(replicatorId: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, String) {
        let isValid = self.validateRequired(replicatorId, field: "ReplicatorId", code: "DATABASE_ERROR", reject: reject)
        return (!isValid, replicatorId)
    }
    
    public func adaptQueryParameter(
        query: String,
        parameters: NSDictionary,
        reject: @escaping RCTPromiseRejectBlock
    ) -> (Bool, QueryArgs) {
        let args = QueryArgs()
        let isValid = self.validateRequired(query, field: "Query", code: "QUERY_ERROR", reject: reject)
        args.query = query
        args.parameters = (parameters as? [String: Any])
        return (!isValid, args)
    }
    
    public func adaptIndexToArrayAny(dict: NSDictionary, reject: @escaping RCTPromiseRejectBlock) -> (Bool, IndexArgs) {
        let indexArgs = IndexArgs()
        // Soft-cast both fields so a malformed dict falls into the INDEX_ERROR path instead of crashing.
        indexArgs.indexType = dict["type"] as? String ?? ""
        if let items = dict["items"] as? NSArray {
            for item in items {
                if let array = item as? [Any] {
                    indexArgs.indexes.append(array)
                }
            }
        }
        if indexArgs.indexes.isEmpty || indexArgs.indexType.isEmpty {
            reject("INDEX_ERROR", "Can't parse Index information", nil)
            return (true, indexArgs)
        }
        return (false, indexArgs)
    }
    
    public func adaptNonEmptyString(value: String, propertyName: String, reject: @escaping RCTPromiseRejectBlock) -> (Bool, String) {
        let isValid = self.validateRequired(value, field: propertyName, code: "ERROR", reject: reject)
        return (!isValid, value)
    }

    /// Defense-in-depth for filesystem paths supplied from JS: returns true if the path
    /// contains a parent-directory ('..') segment (any separator style), so a path cannot be
    /// used to escape its intended directory for destructive (delete) or write (copy/log)
    /// operations. Absolute, out-of-sandbox paths remain bounded by the app sandbox.
    public func containsPathTraversal(_ path: String) -> Bool {
        let segments = path.split(whereSeparator: { $0 == "/" || $0 == "\\" })
        return segments.contains("..")
    }
    
    // Returns false (and rejects) when value is empty.
    public func validateRequired(
        _ value: String,
        field: String,
        code: String,
        reject: @escaping RCTPromiseRejectBlock
    ) -> Bool {
        if value.isEmpty {
            reject(code, "Error: \(field) must be provided", nil)
            return false
        }
        return true
    }
}
