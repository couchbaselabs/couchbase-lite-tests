import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblEngineModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared

    public func file_GetDefaultPath(
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            let paths = NSSearchPathForDirectoriesInDomains(
                .applicationSupportDirectory, .userDomainMask, true
            )
            resolve(paths.first ?? "")
        }
    }

    public func file_GetFileNamesInDirectory(
        path: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        if path.isEmpty || DataAdapter.shared.containsPathTraversal(path) {
            reject("FILE_ERROR",
                   "Invalid path: must be non-empty and must not contain parent-directory traversal ('..')",
                   nil)
            return
        }
        backgroundQueue.async {
            do {
                let files = try FileSystemHelper.fileGetFileNamesInDirectory(path)
                resolve(["files": files])
            } catch let error as NSError {
                reject("FILE_ERROR", error.localizedDescription, error)
            }
        }
    }

    public func listenerToken_Remove(
        changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            guard let record = ListenerTokenStore.shared.remove(token: changeListenerToken) else {
                reject("LISTENER_ERROR",
                       "No listener found for token \(changeListenerToken)", nil)
                return
            }
            record.nativeListenerToken.remove()
            if record.listenerType == .query {
                QueryManager.shared.removeListener(token: changeListenerToken)
            }
            resolve(nil)
        }
    }
}
