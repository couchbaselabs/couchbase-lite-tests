import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblLoggingModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared
    private let sendEventClosure: (String, Any?) -> Void

    // Set when the owning React Native module is invalidated (e.g. JS reload).
    // Once true, in-flight custom-log callbacks stop emitting into a bridge that
    // is being torn down. Written on the RN teardown thread, read on the CBL
    // logging thread; a Bool read/write is atomic enough for this best-effort guard.
    private var isInvalidated = false

    @objc public init(sendEvent: @escaping (String, Any?) -> Void) {
        self.sendEventClosure = sendEvent
        super.init()
    }

    /// Called when the React Native module is being torn down (JS reload, bridge
    /// recreation, app teardown). Couchbase Lite's `LogSinks.custom` is global
    /// static state that retains the emit closure; if we don't remove it here, CBL
    /// keeps invoking a closure bound to a dead bridge and the sink objects leak
    /// for the lifetime of the process. Only the custom sink calls back into JS —
    /// the console/file sinks are owned by CBL and hold no bridge reference, so we
    /// leave them intact to avoid disrupting persistent file logging.
    @objc public func invalidate() {
        isInvalidated = true
        backgroundQueue.async {
            try? LogSinksManager.shared.setCustomSink(level: nil, domains: nil, callback: nil)
        }
    }

    public func database_SetLogLevel(
        domain: String, logLevel: Double,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            do {
                try LoggingManager.shared.setLogLevel(domain, logLevel: Int(logLevel))
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, error)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, error)
            }
        }
    }

    public func database_SetFileLoggingConfig(
        name: String, directory: String, logLevel: Double,
        maxSize: Double, maxRotateCount: Double, shouldUsePlainText: Bool,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        if DataAdapter.shared.containsPathTraversal(directory) {
            reject("DATABASE_ERROR",
                   "Invalid log directory: parent-directory traversal ('..') is not allowed", nil)
            return
        }
        var config: [String: Any] = [:]
        config["level"] = Int(logLevel)
        config["directory"] = directory
        config["maxRotateCount"] = Int(maxRotateCount)
        // Key and type must match LoggingManager.setFileLogging's reader:
        // it reads "maxSize" as UInt64 and "usePlaintext" (lowercase t). Using a
        // different key/type here silently drops the value.
        config["maxSize"] = UInt64(maxSize)
        config["usePlaintext"] = shouldUsePlainText
        backgroundQueue.async {
            do {
                try LoggingManager.shared.setFileLogging(name, config: config)
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, error)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, error)
            }
        }
    }

    // With Turbo Modules, codegen enforces `double` and `[String]` — the JS layer
    // sends -1 for "disable" and an empty array for "all domains". The legacy code used
    // Any? and NSNumber? which allowed nil, but Turbo Modules never send nil for non-optional params.
    public func logsinks_SetConsole(
        level: Double, domains: [String],
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            do {
                let intLevel = Int(level) == -1 ? nil : Int(level)
                // An empty domains array means "all domains" (per the JS contract and
                // convertLogDomains), NOT disable. Pass it through unchanged; disabling is
                // driven solely by level == -1 (intLevel == nil). Mapping empty -> nil here
                // would incorrectly disable the sink when enabling with no explicit domains.
                try LogSinksManager.shared.setConsoleSink(level: intLevel, domains: domains)
                resolve(nil)
            } catch let error as NSError {
                reject("LOGSINKS_ERROR", error.localizedDescription, error)
            } catch {
                reject("LOGSINKS_ERROR", error.localizedDescription, error as NSError)
            }
        }
    }

    public func logsinks_SetFile(
        level: Double, config: Any,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            do {
                let intLevel = Int(level) == -1 ? nil : Int(level)
                let configDict = config as? [String: Any]
                if let dir = configDict?["directory"] as? String,
                   DataAdapter.shared.containsPathTraversal(dir) {
                    reject("LOGSINKS_ERROR",
                           "Invalid log directory: parent-directory traversal ('..') is not allowed", nil)
                    return
                }
                try LogSinksManager.shared.setFileSink(level: intLevel, config: configDict)
                resolve(nil)
            } catch let error as NSError {
                reject("LOGSINKS_ERROR", error.localizedDescription, error)
            } catch {
                reject("LOGSINKS_ERROR", error.localizedDescription, error as NSError)
            }
        }
    }

    public func logsinks_SetCustom(
        level: Double, domains: [String], token: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let intLevel = Int(level) == -1 ? nil : Int(level)
        // Require a non-empty token whenever we are enabling (not disabling) the custom sink.
        if intLevel != nil && token.isEmpty {
            reject("LOGSINKS_ERROR", "Error: token must be provided when enabling a custom log sink", nil)
            return
        }
        backgroundQueue.async {
            do {
                // An empty domains array means "all domains" (per the JS contract and
                // convertLogDomains), NOT disable. Disabling is driven solely by level == -1
                // (callback == nil below); mapping empty -> nil here would incorrectly disable
                // the sink when enabling with no explicit domains.
                let tokenValue: String? = token.isEmpty ? nil : token
                let callback: ((LogLevel, LogDomain, String) -> Void)? =
                    (intLevel != nil && tokenValue != nil) ?
                    { [weak self] logLevel, logDomain, message in
                        guard let self = self, !self.isInvalidated else { return }
                        // Same-thread re-entrancy guard: if emitting this log entry
                        // synchronously triggers more CBL logging on the same thread,
                        // drop the nested entry to avoid a feedback loop. (User
                        // callbacks should be cheap and must not log via Couchbase Lite.)
                        let tld = Thread.current.threadDictionary
                        if tld["cbl_custom_log_emitting"] != nil { return }
                        tld["cbl_custom_log_emitting"] = true
                        defer { tld.removeObject(forKey: "cbl_custom_log_emitting") }
                        let eventData: [String: Any] = [
                            "token": tokenValue!,
                            "level": logLevel.rawValue,
                            "domain": self.logDomainToString(logDomain),
                            "message": message
                        ]
                        self.sendEventClosure("customLogMessage", eventData)
                    } : nil
                try LogSinksManager.shared.setCustomSink(
                    level: intLevel, domains: domains, callback: callback
                )
                resolve(nil)
            } catch let error as NSError {
                reject("LOGSINKS_ERROR", error.localizedDescription, error)
            } catch {
                reject("LOGSINKS_ERROR", error.localizedDescription, error as NSError)
            }
        }
    }

    public func logging_WriteLog(
        level: Double, domain: String, message: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            do {
                try LogSinksManager.shared.writeLog(
                    level: Int(level), domain: domain, message: message)
                resolve(nil)
            } catch let error as NSError {
                reject("LOGSINKS_ERROR", error.localizedDescription, error)
            } catch {
                reject("LOGSINKS_ERROR", error.localizedDescription, error as NSError)
            }
        }
    }

    private func logDomainToString(_ domain: LogDomain) -> String {
        switch domain {
        case .database:   return "DATABASE"
        case .query:      return "QUERY"
        case .replicator: return "REPLICATOR"
        case .network:    return "NETWORK"
        case .listener:   return "LISTENER"
        case .peerDiscovery: return "PEER_DISCOVERY"
        case .mdns:       return "MDNS"
        case .multipeer:  return "MULTIPEER"
        @unknown default: return "UNKNOWN"
        }
    }
}
