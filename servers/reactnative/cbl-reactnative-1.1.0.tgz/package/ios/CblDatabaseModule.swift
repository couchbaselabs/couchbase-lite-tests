import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblDatabaseModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared

    private func removeActiveQueryListeners(for databaseName: String) {
        let listenerTokens = QueryManager.shared.listenerTokens(forDatabaseName: databaseName)
        for token in listenerTokens {
            if let record = ListenerTokenStore.shared.remove(token: token) {
                record.nativeListenerToken.remove()
            }
        }
        QueryManager.shared.removeQueries(databaseName: databaseName)
    }

    // Drop collection-change and collection-document-change listeners attached to this
    // database before close/delete. Without this their CBL ListenerTokens stay registered
    // and their store entries leak across open/close cycles, and callbacks can fire against
    // a closed database handle.
    private func removeActiveCollectionListeners(for databaseUniqueName: String) {
        let records = ListenerTokenStore.shared.removeAll(forDatabaseUniqueName: databaseUniqueName)
        for record in records {
            record.nativeListenerToken.remove()
        }
    }

    public func database_Open(
        databaseName: String,
        directory: String?,
        encryptionKey: String?,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseName, reject: reject
        )
        if isError { return }

        var config: [AnyHashable: Any] = [:]
        if let dir = directory, !dir.isEmpty, dir != "null", dir != "undefined" {
            config["directory"] = dir
        }
        if let key = encryptionKey, !key.isEmpty, key != "null", key != "undefined" {
            config["encryptionKey"] = key
        }

        backgroundQueue.async {
            do {
                let uniqueName = try DatabaseManager.shared.open(
                    databaseName, databaseConfig: config
                )
                resolve(["databaseUniqueName": uniqueName])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_Close(
        databaseUniqueName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                self.removeActiveQueryListeners(for: databaseName)
                self.removeActiveCollectionListeners(for: databaseName)
                try DatabaseManager.shared.close(databaseName)
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_Delete(
        databaseUniqueName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                self.removeActiveQueryListeners(for: databaseName)
                self.removeActiveCollectionListeners(for: databaseName)
                try DatabaseManager.shared.delete(databaseName)
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_DeleteWithPath(
        path: String,
        databaseName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isPathError, databasePath) = DataAdapter.shared.adaptNonEmptyString(
            value: path, propertyName: "path", reject: reject
        )
        if isPathError { return }
        if DataAdapter.shared.containsPathTraversal(databasePath) {
            reject("DATABASE_ERROR",
                   "Error: path must not contain parent-directory traversal ('..')", nil)
            return
        }
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                // `databaseName` here is the LOGICAL name (delete-by-path is not tied to an
                // open handle). Cached queries and listeners are keyed by the unique runtime
                // handle, so resolve the open handles for this logical name and tear those
                // down — passing the logical name directly would never match and would leak.
                for uniqueName in DatabaseManager.shared.openUniqueNames(forLogicalName: databaseName) {
                    self.removeActiveQueryListeners(for: uniqueName)
                    self.removeActiveCollectionListeners(for: uniqueName)
                }
                try DatabaseManager.shared.delete(databasePath, databaseName: databaseName)
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_Copy(
        path: String,
        newDatabaseName: String,
        directory: String?,
        encryptionKey: String?,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: newDatabaseName, reject: reject
        )
        if isError { return }
        let (isPathError, databasePath) = DataAdapter.shared.adaptNonEmptyString(
            value: path, propertyName: "path", reject: reject
        )
        if isPathError { return }
        if DataAdapter.shared.containsPathTraversal(databasePath) {
            reject("DATABASE_ERROR",
                   "Error: path must not contain parent-directory traversal ('..')", nil)
            return
        }

        var config: [AnyHashable: Any] = [:]
        if let dir = directory, !dir.isEmpty, dir != "null", dir != "undefined" {
            config["directory"] = dir
        }
        if let key = encryptionKey, !key.isEmpty, key != "null", key != "undefined" {
            config["encryptionKey"] = key
        }

        backgroundQueue.async {
            do {
                try DatabaseManager.shared.copy(
                    databasePath, newName: databaseName, databaseConfig: config
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_Exists(
        databaseName: String,
        directory: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isNameError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseName, reject: reject
        )
        if isNameError { return }
        let (isDirError, path) = DataAdapter.shared.adaptNonEmptyString(
            value: directory, propertyName: "directory", reject: reject
        )
        if isDirError { return }
        if DataAdapter.shared.containsPathTraversal(path) {
            reject("DATABASE_ERROR",
                   "Error: directory must not contain parent-directory traversal ('..')", nil)
            return
        }
        backgroundQueue.async {
            let exists = DatabaseManager.shared.exists(databaseName, directoryPath: path)
            resolve(exists)
        }
    }

    public func database_GetPath(
        databaseUniqueName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                guard let path = try DatabaseManager.shared.getPath(databaseName) else {
                    reject("DATABASE_ERROR",
                           "Unable to get path for database \(databaseName)", nil)
                    return
                }
                resolve(path)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_PerformMaintenance(
        databaseUniqueName: String,
        maintenanceType: Double,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        guard let mType = DataAdapter.shared.adaptMaintenanceTypeFromInt(
            intValue: Int(maintenanceType)
        ) else {
            reject("DATABASE_ERROR",
                   "Invalid maintenance type: \(Int(maintenanceType)) (expected 0-4)", nil)
            return
        }
        backgroundQueue.async {
            do {
                try DatabaseManager.shared.performMaintenance(
                    databaseName, maintenanceType: mType
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func database_ChangeEncryptionKey(
        databaseUniqueName: String,
        newKey: String?,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        let keyToUse = newKey.flatMap { $0.isEmpty ? nil : $0 }
        backgroundQueue.async {
            do {
                try DatabaseManager.shared.changeEncryptionKey(databaseName, newKey: keyToUse) // TODO(deferred): rename databaseName arg to databaseUniqueName when the manager-layer plan lands.
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }
}
