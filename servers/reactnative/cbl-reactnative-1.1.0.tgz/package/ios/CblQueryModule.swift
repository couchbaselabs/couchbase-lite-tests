import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblQueryModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared
    private let listenerQueue = CblNativeQueue.listener
    private let sendEventClosure: (String, Any?) -> Void

    @objc public init(sendEvent: @escaping (String, Any?) -> Void) {
        self.sendEventClosure = sendEvent
        super.init()
    }

    public func query_Execute(
        databaseUniqueName: String, queryId: String, query: String, parameters: Any,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        let (isQueryIdError, qid) = DataAdapter.shared.adaptNonEmptyString(
            value: queryId, propertyName: "queryId", reject: reject
        )
        if isQueryIdError { return }
        let parametersDict = parameters as? NSDictionary ?? NSDictionary()
        let (isQueryError, queryArgs) = DataAdapter.shared.adaptQueryParameter(
            query: query, parameters: parametersDict, reject: reject
        )
        if isQueryError { return }
        backgroundQueue.async {
            do {
                let results: String
                if let cachedQuery = QueryManager.shared.existing(queryId: qid) {
                    if let params = queryArgs.parameters {
                        cachedQuery.parameters = try QueryHelper.getParamatersFromJson(params)
                    }
                    let resultJSONs = try cachedQuery.execute().map { $0.toJSON() }
                    results = "[" + resultJSONs.joined(separator: ",") + "]"
                } else if let params = queryArgs.parameters {
                    results = try DatabaseManager.shared.executeQuery(
                        queryArgs.query, parameters: params, databaseName: databaseName
                    )
                } else {
                    results = try DatabaseManager.shared.executeQuery(
                        queryArgs.query, databaseName: databaseName
                    )
                }
                resolve(["data": results])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func query_Explain(
        databaseUniqueName: String, queryId: String, query: String, parameters: Any,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        let (isQueryIdError, qid) = DataAdapter.shared.adaptNonEmptyString(
            value: queryId, propertyName: "queryId", reject: reject
        )
        if isQueryIdError { return }
        let parametersDict = parameters as? NSDictionary ?? NSDictionary()
        let (isQueryError, queryArgs) = DataAdapter.shared.adaptQueryParameter(
            query: query, parameters: parametersDict, reject: reject
        )
        if isQueryError { return }
        backgroundQueue.async {
            do {
                let results: String
                if let cachedQuery = QueryManager.shared.existing(queryId: qid) {
                    if let params = queryArgs.parameters {
                        cachedQuery.parameters = try QueryHelper.getParamatersFromJson(params)
                    }
                    results = try cachedQuery.explain()
                } else if let params = queryArgs.parameters {
                    results = try DatabaseManager.shared.queryExplain(
                        queryArgs.query, parameters: params, databaseName: databaseName
                    )
                } else {
                    results = try DatabaseManager.shared.queryExplain(
                        queryArgs.query, databaseName: databaseName
                    )
                }
                resolve(["data": results])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func query_AddChangeListener(
        databaseUniqueName: String, queryId: String, query: String, parameters: Any,
        changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        let (isTokenError, uuidToken) = DataAdapter.shared.adaptNonEmptyString(
            value: changeListenerToken,
            propertyName: "changeListenerToken", reject: reject
        )
        if isTokenError { return }
        let (isQueryIdError, qid) = DataAdapter.shared.adaptNonEmptyString(
            value: queryId, propertyName: "queryId", reject: reject
        )
        if isQueryIdError { return }
        let (isQueryError, queryString) = DataAdapter.shared.adaptNonEmptyString(
            value: query, propertyName: "query", reject: reject
        )
        if isQueryError { return }
        backgroundQueue.async {
            do {
                guard let database = DatabaseManager.shared.getDatabase(databaseName) else {
                    reject("DATABASE_ERROR",
                           "Could not find database with name \(databaseName)", nil)
                    return
                }
                let q = try QueryManager.shared.getOrCreate(
                    queryId: qid,
                    queryString: queryString,
                    databaseName: databaseName,
                    database: database
                )
                let parametersDict = parameters as? [String: Any] ?? [:]
                if !parametersDict.isEmpty {
                    let params = try QueryHelper.getParamatersFromJson(parametersDict)
                    q.parameters = params
                }
                let listener = q.addChangeListener(
                    withQueue: self.listenerQueue
                ) { [weak self] change in
                    guard let self = self else { return }
                    let resultData = NSMutableDictionary()
                    resultData["token"] = uuidToken
                    if let results = change.results {
                        let jsonArray = "[" +
                            results.map { $0.toJSON() }.joined(separator: ",") + "]"
                        resultData["data"] = jsonArray
                    }
                    if let error = change.error {
                        resultData["error"] = error.localizedDescription
                    }
                    self.sendEventClosure("queryChange", resultData)
                }
                ListenerTokenStore.shared.add(
                    token: uuidToken,
                    record: ChangeListenerRecord(
                        nativeListenerToken: listener, listenerType: .query
                    )
                )
                QueryManager.shared.recordListener(queryId: qid, token: uuidToken)
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func query_RemoveChangeListener(
        changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            guard let record = ListenerTokenStore.shared.remove(token: changeListenerToken) else {
                reject("LISTENER_ERROR",
                       "No listener found for token \(changeListenerToken)", nil)
                return
            }
            record.nativeListenerToken.remove()
            QueryManager.shared.removeListener(token: changeListenerToken)
            resolve(nil)
        }
    }
}
