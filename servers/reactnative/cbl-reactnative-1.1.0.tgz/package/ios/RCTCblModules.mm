#import "RCTCblModules.h"
#import "cbl_reactnative-Swift.h"

#import <React/RCTAssert.h>
#import <React/RCTConstants.h>
#import <React/RCTLog.h>

// ============================================================
// MARK: - RCTCblDatabase
// ============================================================

@implementation RCTCblDatabase {
    CblDatabaseModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        _impl = [CblDatabaseModule new];
    }
    return self;
}

RCT_EXPORT_MODULE(CblDatabase)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblDatabaseSpecJSI>(params);
}

- (void)database_Open:(NSString *)databaseName
           directory:(NSString *)directory
       encryptionKey:(NSString *)encryptionKey
             resolve:(RCTPromiseResolveBlock)resolve
              reject:(RCTPromiseRejectBlock)reject {
    [_impl database_OpenWithDatabaseName:databaseName directory:directory
                           encryptionKey:encryptionKey resolve:resolve reject:reject];
}

- (void)database_Close:(NSString *)databaseUniqueName
               resolve:(RCTPromiseResolveBlock)resolve
                reject:(RCTPromiseRejectBlock)reject {
    [_impl database_CloseWithDatabaseUniqueName:databaseUniqueName resolve:resolve reject:reject];
}

- (void)database_Delete:(NSString *)databaseUniqueName
                resolve:(RCTPromiseResolveBlock)resolve
                 reject:(RCTPromiseRejectBlock)reject {
    [_impl database_DeleteWithDatabaseUniqueName:databaseUniqueName resolve:resolve reject:reject];
}

- (void)database_DeleteWithPath:(NSString *)path
                   databaseName:(NSString *)databaseName
                        resolve:(RCTPromiseResolveBlock)resolve
                         reject:(RCTPromiseRejectBlock)reject {
    [_impl database_DeleteWithPathWithPath:path databaseName:databaseName
                                   resolve:resolve reject:reject];
}

- (void)database_Copy:(NSString *)path
      newDatabaseName:(NSString *)newDatabaseName
            directory:(NSString *)directory
        encryptionKey:(NSString *)encryptionKey
              resolve:(RCTPromiseResolveBlock)resolve
               reject:(RCTPromiseRejectBlock)reject {
    [_impl database_CopyWithPath:path newDatabaseName:newDatabaseName directory:directory
                   encryptionKey:encryptionKey resolve:resolve reject:reject];
}

- (void)database_Exists:(NSString *)databaseName
              directory:(NSString *)directory
                resolve:(RCTPromiseResolveBlock)resolve
                 reject:(RCTPromiseRejectBlock)reject {
    [_impl database_ExistsWithDatabaseName:databaseName directory:directory
                                   resolve:resolve reject:reject];
}

- (void)database_GetPath:(NSString *)databaseUniqueName
                 resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject {
    [_impl database_GetPathWithDatabaseUniqueName:databaseUniqueName resolve:resolve reject:reject];
}

- (void)database_PerformMaintenance:(NSString *)databaseUniqueName
                    maintenanceType:(double)maintenanceType
                            resolve:(RCTPromiseResolveBlock)resolve
                             reject:(RCTPromiseRejectBlock)reject {
    [_impl database_PerformMaintenanceWithDatabaseUniqueName:databaseUniqueName
                                            maintenanceType:maintenanceType
                                                    resolve:resolve reject:reject];
}

- (void)database_ChangeEncryptionKey:(NSString *)databaseUniqueName
                              newKey:(nullable NSString *)newKey
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject {
    [_impl database_ChangeEncryptionKeyWithDatabaseUniqueName:databaseUniqueName
                                                      newKey:newKey
                                                     resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblScope
// ============================================================

@implementation RCTCblScope {
    CblScopeModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        _impl = [CblScopeModule new];
    }
    return self;
}

RCT_EXPORT_MODULE(CblScope)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblScopeSpecJSI>(params);
}

- (void)scope_GetDefault:(NSString *)databaseUniqueName
                 resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject {
    [_impl scope_GetDefaultWithDatabaseUniqueName:databaseUniqueName resolve:resolve reject:reject];
}

- (void)scope_GetScope:(NSString *)databaseUniqueName
             scopeName:(NSString *)scopeName
               resolve:(RCTPromiseResolveBlock)resolve
                reject:(RCTPromiseRejectBlock)reject {
    [_impl scope_GetScopeWithDatabaseUniqueName:databaseUniqueName scopeName:scopeName
                                        resolve:resolve reject:reject];
}

- (void)scope_GetScopes:(NSString *)databaseUniqueName
                resolve:(RCTPromiseResolveBlock)resolve
                 reject:(RCTPromiseRejectBlock)reject {
    [_impl scope_GetScopesWithDatabaseUniqueName:databaseUniqueName resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblDocument
// ============================================================

@implementation RCTCblDocument {
    CblDocumentModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        _impl = [CblDocumentModule new];
    }
    return self;
}

RCT_EXPORT_MODULE(CblDocument)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblDocumentSpecJSI>(params);
}

- (void)collection_GetDocument:(NSString *)databaseUniqueName
                collectionName:(NSString *)collectionName
                     scopeName:(NSString *)scopeName
                         docId:(NSString *)docId
                       resolve:(RCTPromiseResolveBlock)resolve
                        reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetDocumentWithDatabaseUniqueName:databaseUniqueName
                                        collectionName:collectionName scopeName:scopeName
                                                 docId:docId resolve:resolve reject:reject];
}

- (void)collection_Save:(NSString *)databaseUniqueName
         collectionName:(NSString *)collectionName
              scopeName:(NSString *)scopeName
                  docId:(NSString *)docId
               document:(NSString *)document
                  blobs:(NSString *)blobs
concurrencyControlValue:(double)concurrencyControlValue
                resolve:(RCTPromiseResolveBlock)resolve
                 reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_SaveWithDatabaseUniqueName:databaseUniqueName
                                 collectionName:collectionName scopeName:scopeName
                                          docId:docId document:document blobs:blobs
                        concurrencyControlValue:concurrencyControlValue
                                        resolve:resolve reject:reject];
}

- (void)collection_DeleteDocument:(NSString *)databaseUniqueName
                   collectionName:(NSString *)collectionName
                        scopeName:(NSString *)scopeName
                            docId:(NSString *)docId
               concurrencyControl:(double)concurrencyControl
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_DeleteDocumentWithDatabaseUniqueName:databaseUniqueName
                                           collectionName:collectionName scopeName:scopeName
                                                    docId:docId
                                       concurrencyControl:concurrencyControl
                                                  resolve:resolve reject:reject];
}

- (void)collection_PurgeDocument:(NSString *)databaseUniqueName
                  collectionName:(NSString *)collectionName
                       scopeName:(NSString *)scopeName
                           docId:(NSString *)docId
                         resolve:(RCTPromiseResolveBlock)resolve
                          reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_PurgeDocumentWithDatabaseUniqueName:databaseUniqueName
                                          collectionName:collectionName scopeName:scopeName
                                                   docId:docId resolve:resolve reject:reject];
}

- (void)collection_GetDocumentExpiration:(NSString *)databaseUniqueName
                          collectionName:(NSString *)collectionName
                               scopeName:(NSString *)scopeName
                                   docId:(NSString *)docId
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetDocumentExpirationWithDatabaseUniqueName:databaseUniqueName
                                                  collectionName:collectionName
                                                       scopeName:scopeName docId:docId
                                                         resolve:resolve reject:reject];
}

- (void)collection_SetDocumentExpiration:(NSString *)databaseUniqueName
                          collectionName:(NSString *)collectionName
                               scopeName:(NSString *)scopeName
                                   docId:(NSString *)docId
                              expiration:(NSString * _Nullable)expiration
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_SetDocumentExpirationWithDatabaseUniqueName:databaseUniqueName
                                                  collectionName:collectionName
                                                       scopeName:scopeName docId:docId
                                                      expiration:expiration
                                                         resolve:resolve reject:reject];
}

- (void)collection_GetBlobContent:(NSString *)databaseUniqueName
                   collectionName:(NSString *)collectionName
                        scopeName:(NSString *)scopeName
                       documentId:(NSString *)documentId
                              key:(NSString *)key
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetBlobContentWithDatabaseUniqueName:databaseUniqueName
                                           collectionName:collectionName scopeName:scopeName
                                               documentId:documentId key:key
                                                  resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblEngine
// ============================================================

@implementation RCTCblEngine {
    CblEngineModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        _impl = [CblEngineModule new];
    }
    return self;
}

RCT_EXPORT_MODULE(CblEngine)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblEngineSpecJSI>(params);
}

- (void)file_GetDefaultPath:(RCTPromiseResolveBlock)resolve
                     reject:(RCTPromiseRejectBlock)reject {
    [_impl file_GetDefaultPathWithResolve:resolve reject:reject];
}

- (void)file_GetFileNamesInDirectory:(NSString *)path
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject {
    [_impl file_GetFileNamesInDirectoryWithPath:path
                                        resolve:resolve
                                         reject:reject];
}

- (void)listenerToken_Remove:(NSString *)changeListenerToken
                     resolve:(RCTPromiseResolveBlock)resolve
                      reject:(RCTPromiseRejectBlock)reject {
    [_impl listenerToken_RemoveWithChangeListenerToken:changeListenerToken
                                              resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblCollection
// ============================================================

@implementation RCTCblCollection {
    CblCollectionModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        __weak __typeof__(self) weakSelf = self;
        _impl = [[CblCollectionModule alloc] initWithSendEvent:^(NSString *name, id body) {
            __typeof__(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if ([name isEqualToString:@"collectionChange"]) {
                [strongSelf emitCollectionChange:body];
            } else if ([name isEqualToString:@"collectionDocumentChange"]) {
                [strongSelf emitCollectionDocumentChange:body];
            }
        }];
    }
    return self;
}

RCT_EXPORT_MODULE(CblCollection)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblCollectionSpecJSI>(params);
}

- (void)collection_CreateCollection:(NSString *)databaseUniqueName
                     collectionName:(NSString *)collectionName
                          scopeName:(NSString *)scopeName
                            resolve:(RCTPromiseResolveBlock)resolve
                             reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_CreateCollectionWithDatabaseUniqueName:databaseUniqueName
                                             collectionName:collectionName scopeName:scopeName
                                                    resolve:resolve reject:reject];
}

- (void)collection_DeleteCollection:(NSString *)databaseUniqueName
                     collectionName:(NSString *)collectionName
                          scopeName:(NSString *)scopeName
                            resolve:(RCTPromiseResolveBlock)resolve
                             reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_DeleteCollectionWithDatabaseUniqueName:databaseUniqueName
                                             collectionName:collectionName scopeName:scopeName
                                                    resolve:resolve reject:reject];
}

- (void)collection_GetCollection:(NSString *)databaseUniqueName
                  collectionName:(NSString *)collectionName
                       scopeName:(NSString *)scopeName
                         resolve:(RCTPromiseResolveBlock)resolve
                          reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetCollectionWithDatabaseUniqueName:databaseUniqueName
                                          collectionName:collectionName scopeName:scopeName
                                                 resolve:resolve reject:reject];
}

- (void)collection_GetCollections:(NSString *)databaseUniqueName
                        scopeName:(NSString *)scopeName
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetCollectionsWithDatabaseUniqueName:databaseUniqueName
                                                scopeName:scopeName resolve:resolve reject:reject];
}

- (void)collection_GetDefault:(NSString *)databaseUniqueName
                      resolve:(RCTPromiseResolveBlock)resolve
                       reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetDefaultWithDatabaseUniqueName:databaseUniqueName
                                               resolve:resolve reject:reject];
}

- (void)collection_GetCount:(NSString *)databaseUniqueName
             collectionName:(NSString *)collectionName
                  scopeName:(NSString *)scopeName
                    resolve:(RCTPromiseResolveBlock)resolve
                     reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetCountWithDatabaseUniqueName:databaseUniqueName
                                     collectionName:collectionName scopeName:scopeName
                                            resolve:resolve reject:reject];
}

- (void)collection_GetFullName:(NSString *)databaseUniqueName
                collectionName:(NSString *)collectionName
                     scopeName:(NSString *)scopeName
                       resolve:(RCTPromiseResolveBlock)resolve
                        reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetFullNameWithDatabaseUniqueName:databaseUniqueName
                                        collectionName:collectionName scopeName:scopeName
                                               resolve:resolve reject:reject];
}

- (void)collection_CreateIndex:(NSString *)databaseUniqueName
                collectionName:(NSString *)collectionName
                     scopeName:(NSString *)scopeName
                     indexName:(NSString *)indexName
                         index:(id)index
                       resolve:(RCTPromiseResolveBlock)resolve
                        reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_CreateIndexWithDatabaseUniqueName:databaseUniqueName
                                        collectionName:collectionName scopeName:scopeName
                                             indexName:indexName index:index
                                               resolve:resolve reject:reject];
}

- (void)collection_DeleteIndex:(NSString *)databaseUniqueName
                collectionName:(NSString *)collectionName
                     scopeName:(NSString *)scopeName
                     indexName:(NSString *)indexName
                       resolve:(RCTPromiseResolveBlock)resolve
                        reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_DeleteIndexWithDatabaseUniqueName:databaseUniqueName
                                        collectionName:collectionName scopeName:scopeName
                                             indexName:indexName resolve:resolve reject:reject];
}

- (void)collection_GetIndexes:(NSString *)databaseUniqueName
               collectionName:(NSString *)collectionName
                    scopeName:(NSString *)scopeName
                      resolve:(RCTPromiseResolveBlock)resolve
                       reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_GetIndexesWithDatabaseUniqueName:databaseUniqueName
                                       collectionName:collectionName scopeName:scopeName
                                              resolve:resolve reject:reject];
}

- (void)collection_AddChangeListener:(NSString *)databaseUniqueName
                      collectionName:(NSString *)collectionName
                           scopeName:(NSString *)scopeName
                 changeListenerToken:(NSString *)changeListenerToken
                             resolve:(RCTPromiseResolveBlock)resolve
                              reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_AddChangeListenerWithDatabaseUniqueName:databaseUniqueName
                                              collectionName:collectionName scopeName:scopeName
                                        changeListenerToken:changeListenerToken
                                                    resolve:resolve reject:reject];
}

- (void)collection_AddDocumentChangeListener:(NSString *)databaseUniqueName
                              collectionName:(NSString *)collectionName
                                   scopeName:(NSString *)scopeName
                                       docId:(NSString *)docId
                         changeListenerToken:(NSString *)changeListenerToken
                                     resolve:(RCTPromiseResolveBlock)resolve
                                      reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_AddDocumentChangeListenerWithDatabaseUniqueName:databaseUniqueName
                                                      collectionName:collectionName
                                                           scopeName:scopeName documentId:docId
                                                changeListenerToken:changeListenerToken
                                                            resolve:resolve reject:reject];
}

- (void)collection_RemoveChangeListener:(NSString *)changeListenerToken
                                resolve:(RCTPromiseResolveBlock)resolve
                                 reject:(RCTPromiseRejectBlock)reject {
    [_impl collection_RemoveChangeListenerWithChangeListenerToken:changeListenerToken
                                                         resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblQuery
// ============================================================

@implementation RCTCblQuery {
    CblQueryModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        __weak __typeof__(self) weakSelf = self;
        _impl = [[CblQueryModule alloc] initWithSendEvent:^(NSString *name, id body) {
            __typeof__(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if ([name isEqualToString:@"queryChange"]) {
                [strongSelf emitQueryChange:body];
            }
        }];
    }
    return self;
}

RCT_EXPORT_MODULE(CblQuery)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblQuerySpecJSI>(params);
}

- (void)query_Execute:(NSString *)databaseUniqueName
             queryId:(NSString *)queryId
               query:(NSString *)query
          parameters:(id)parameters
             resolve:(RCTPromiseResolveBlock)resolve
              reject:(RCTPromiseRejectBlock)reject {
    [_impl query_ExecuteWithDatabaseUniqueName:databaseUniqueName queryId:queryId
                                         query:query parameters:parameters
                                       resolve:resolve reject:reject];
}

- (void)query_Explain:(NSString *)databaseUniqueName
              queryId:(NSString *)queryId
                query:(NSString *)query
           parameters:(id)parameters
              resolve:(RCTPromiseResolveBlock)resolve
               reject:(RCTPromiseRejectBlock)reject {
    [_impl query_ExplainWithDatabaseUniqueName:databaseUniqueName queryId:queryId
                                         query:query parameters:parameters
                                       resolve:resolve reject:reject];
}

- (void)query_AddChangeListener:(NSString *)databaseUniqueName
                        queryId:(NSString *)queryId
                          query:(NSString *)query
                     parameters:(id)parameters
            changeListenerToken:(NSString *)changeListenerToken
                        resolve:(RCTPromiseResolveBlock)resolve
                         reject:(RCTPromiseRejectBlock)reject {
    [_impl query_AddChangeListenerWithDatabaseUniqueName:databaseUniqueName queryId:queryId
                                                   query:query parameters:parameters
                                    changeListenerToken:changeListenerToken
                                                resolve:resolve reject:reject];
}

- (void)query_RemoveChangeListener:(NSString *)changeListenerToken
                           resolve:(RCTPromiseResolveBlock)resolve
                            reject:(RCTPromiseRejectBlock)reject {
    [_impl query_RemoveChangeListenerWithChangeListenerToken:changeListenerToken
                                                    resolve:resolve reject:reject];
}

@end

// ============================================================
// MARK: - RCTCblLogging
// ============================================================

@implementation RCTCblLogging {
    CblLoggingModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        __weak __typeof__(self) weakSelf = self;
        _impl = [[CblLoggingModule alloc] initWithSendEvent:^(NSString *name, id body) {
            __typeof__(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if ([name isEqualToString:@"customLogMessage"]) {
                [strongSelf emitCustomLogMessage:body];
            }
        }];
    }
    return self;
}

RCT_EXPORT_MODULE(CblLogging)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblLoggingSpecJSI>(params);
}

- (void)database_SetLogLevel:(NSString *)domain logLevel:(double)logLevel
                     resolve:(RCTPromiseResolveBlock)resolve
                      reject:(RCTPromiseRejectBlock)reject {
    [_impl database_SetLogLevelWithDomain:domain logLevel:logLevel
                                  resolve:resolve reject:reject];
}

- (void)database_SetFileLoggingConfig:(NSString *)name directory:(NSString *)directory
                             logLevel:(double)logLevel maxSize:(double)maxSize
                       maxRotateCount:(double)maxRotateCount
                    shouldUsePlainText:(BOOL)shouldUsePlainText
                               resolve:(RCTPromiseResolveBlock)resolve
                                reject:(RCTPromiseRejectBlock)reject {
    [_impl database_SetFileLoggingConfigWithName:name directory:directory logLevel:logLevel
                                        maxSize:maxSize maxRotateCount:maxRotateCount
                              shouldUsePlainText:shouldUsePlainText
                                        resolve:resolve reject:reject];
}

- (void)logsinks_SetConsole:(double)level domains:(NSArray<NSString *> *)domains
                    resolve:(RCTPromiseResolveBlock)resolve
                     reject:(RCTPromiseRejectBlock)reject {
    [_impl logsinks_SetConsoleWithLevel:level domains:domains resolve:resolve reject:reject];
}

- (void)logsinks_SetFile:(double)level config:(id)config
                 resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject {
    [_impl logsinks_SetFileWithLevel:level config:config resolve:resolve reject:reject];
}

- (void)logsinks_SetCustom:(double)level domains:(NSArray<NSString *> *)domains
                     token:(NSString *)token resolve:(RCTPromiseResolveBlock)resolve
                    reject:(RCTPromiseRejectBlock)reject {
    [_impl logsinks_SetCustomWithLevel:level domains:domains token:token
                               resolve:resolve reject:reject];
}

// JS→native log injection (file + console + custom). No event involved.
- (void)logging_WriteLog:(double)level domain:(NSString *)domain
                 message:(NSString *)message resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject {
    [_impl logging_WriteLogWithLevel:level domain:domain message:message
                             resolve:resolve reject:reject];
}

// RCTInvalidating: called by the bridge on teardown/reload. Forward to the Swift
// impl so the global CBL custom log sink is removed and stops calling into a dead
// bridge (otherwise it leaks and silently drops events after a reload).
- (void)invalidate {
    [_impl invalidate];
}

@end

// ============================================================
// MARK: - RCTCblReplicator
// ============================================================

@implementation RCTCblReplicator {
    CblReplicatorModule *_impl;
}

- (id)init {
    if (self = [super init]) {
        __weak __typeof__(self) weakSelf = self;
        _impl = [[CblReplicatorModule alloc] initWithSendEvent:^(NSString *name, id body) {
            __typeof__(self) strongSelf = weakSelf;
            if (!strongSelf) return;
            if ([name isEqualToString:@"replicatorStatusChange"]) {
                [strongSelf emitReplicatorStatusChange:body];
            } else if ([name isEqualToString:@"replicatorDocumentChange"]) {
                [strongSelf emitReplicatorDocumentChange:body];
            }
        }];
    }
    return self;
}

RCT_EXPORT_MODULE(CblReplicator)

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    return std::make_shared<facebook::react::NativeCblReplicatorSpecJSI>(params);
}

- (void)replicator_Create:(id)config resolve:(RCTPromiseResolveBlock)resolve
                   reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_CreateWithConfig:config resolve:resolve reject:reject];
}

- (void)replicator_Start:(NSString *)replicatorId resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_StartWithReplicatorId:replicatorId resolve:resolve reject:reject];
}

- (void)replicator_Stop:(NSString *)replicatorId resolve:(RCTPromiseResolveBlock)resolve
                 reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_StopWithReplicatorId:replicatorId resolve:resolve reject:reject];
}

- (void)replicator_Cleanup:(NSString *)replicatorId resolve:(RCTPromiseResolveBlock)resolve
                    reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_CleanupWithReplicatorId:replicatorId resolve:resolve reject:reject];
}

- (void)replicator_GetStatus:(NSString *)replicatorId resolve:(RCTPromiseResolveBlock)resolve
                      reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_GetStatusWithReplicatorId:replicatorId resolve:resolve reject:reject];
}

- (void)replicator_ResetCheckpoint:(NSString *)replicatorId
                           resolve:(RCTPromiseResolveBlock)resolve
                            reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_ResetCheckpointWithReplicatorId:replicatorId resolve:resolve reject:reject];
}

- (void)replicator_GetPendingDocumentIds:(NSString *)databaseUniqueName
                            replicatorId:(NSString *)replicatorId
                          collectionName:(NSString *)collectionName
                               scopeName:(NSString *)scopeName
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_GetPendingDocumentIdsWithDatabaseUniqueName:databaseUniqueName
                                                    replicatorId:replicatorId
                                                  collectionName:collectionName
                                                       scopeName:scopeName
                                                         resolve:resolve reject:reject];
}

- (void)replicator_IsDocumentPending:(NSString *)databaseUniqueName
                         replicatorId:(NSString *)replicatorId
                       collectionName:(NSString *)collectionName
                            scopeName:(NSString *)scopeName
                           documentId:(NSString *)documentId
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_IsDocumentPendingWithDatabaseUniqueName:databaseUniqueName
                                                replicatorId:replicatorId
                                              collectionName:collectionName
                                                   scopeName:scopeName
                                                  documentId:documentId
                                                     resolve:resolve reject:reject];
}

- (void)replicator_AddChangeListener:(NSString *)changeListenerToken
                         replicatorId:(NSString *)replicatorId
                              resolve:(RCTPromiseResolveBlock)resolve
                               reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_AddChangeListenerWithChangeListenerToken:changeListenerToken
                                                 replicatorId:replicatorId
                                                      resolve:resolve reject:reject];
}

- (void)replicator_AddDocumentChangeListener:(NSString *)changeListenerToken
                                 replicatorId:(NSString *)replicatorId
                                      resolve:(RCTPromiseResolveBlock)resolve
                                       reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_AddDocumentChangeListenerWithChangeListenerToken:changeListenerToken
                                                         replicatorId:replicatorId
                                                              resolve:resolve reject:reject];
}

- (void)replicator_RemoveChangeListener:(NSString *)changeListenerToken
                            replicatorId:(NSString *)replicatorId
                                 resolve:(RCTPromiseResolveBlock)resolve
                                  reject:(RCTPromiseRejectBlock)reject {
    [_impl replicator_RemoveChangeListenerWithChangeListenerToken:changeListenerToken
                                                    replicatorId:replicatorId
                                                         resolve:resolve reject:reject];
}

@end
