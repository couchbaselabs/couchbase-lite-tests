import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblDocumentModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared

    public func collection_GetDocument(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentId) = DataAdapter.shared.adaptNonEmptyString(
            value: docId, propertyName: "docId", reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                guard let doc = try CollectionManager.shared.document(
                    documentId,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    resolve(NSDictionary())
                    return
                }
                var data: [String: Any] = [:]
                let documentJson = doc.toJSON()
                if !documentJson.isEmpty {
                    guard let jsonData = documentJson.data(using: .utf8),
                          let jsonDict = try JSONSerialization.jsonObject(
                            with: jsonData, options: []
                          ) as? [String: Any] else {
                        reject("DOCUMENT_ERROR", "Failed to parse document JSON", nil)
                        return
                    }
                    data["_data"] = jsonDict
                } else {
                    data["_data"] = [:]
                }
                data["_id"] = documentId
                data["_sequence"] = doc.sequence
                data["_revId"] = doc.revisionID ?? ""
                resolve(data as NSDictionary)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_Save(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        document: String,
        blobs: String,
        concurrencyControlValue: Double,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentArgs) = DataAdapter.shared.adaptDocumentArgs(
            docId: docId,
            concurrencyControlValue: NSNumber(value: concurrencyControlValue),
            reject: reject
        )
        if isDocError { return }
        let (isBlobError, documentBlobArgs) = DataAdapter.shared.adaptDocumentBlobStrings(
            document: document, blobs: blobs, reject: reject
        )
        if isBlobError { return }
        backgroundQueue.async {
            do {
                let blobMap = try CollectionManager.shared.blobsFromJsonString(
                    documentBlobArgs.blobs
                )
                let result = try CollectionManager.shared.saveDocument(
                    documentArgs.documentId,
                    document: documentBlobArgs.document,
                    blobs: blobMap,
                    concurrencyControl: documentArgs.concurrencyControlValue,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve([
                    "_id": result.id,
                    "_revId": result.revId ?? "",
                    "_sequence": result.sequence,
                    "concurrencyControlResult": result.concurrencyControl as Any
                ])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_DeleteDocument(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        concurrencyControl: Double,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentArgs) = DataAdapter.shared.adaptDocumentArgs(
            docId: docId,
            concurrencyControlValue: NSNumber(value: concurrencyControl),
            reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                let result = try CollectionManager.shared.deleteDocument(
                    documentArgs.documentId,
                    concurrencyControl: documentArgs.concurrencyControlValue,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(["concurrencyControlResult": result])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_PurgeDocument(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentId) = DataAdapter.shared.adaptNonEmptyString(
            value: docId, propertyName: "docId", reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                try CollectionManager.shared.purgeDocument(
                    documentId,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetDocumentExpiration(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentId) = DataAdapter.shared.adaptNonEmptyString(
            value: docId, propertyName: "docId", reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                if let date = try CollectionManager.shared.getDocumentExpiration(
                    documentId,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) {
                    let formatter = ISO8601DateFormatter()
                    resolve(["date": formatter.string(from: date)])
                } else {
                    resolve(nil)
                }
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_SetDocumentExpiration(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        docId: String,
        expiration: String?,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, documentId) = DataAdapter.shared.adaptNonEmptyString(
            value: docId, propertyName: "docId", reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                let date: Date?
                if let expirationString = expiration {
                    let formatter = ISO8601DateFormatter()
                    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
                    guard let parsed = formatter.date(from: expirationString) else {
                        reject("DATABASE_ERROR",
                               "Unable to convert date to ISO8601. " +
                               "Validate expiration is in ISO8601 format.", nil)
                        return
                    }
                    date = parsed
                } else {
                    date = nil
                }
                try CollectionManager.shared.setDocumentExpiration(
                    documentId,
                    expiration: date,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetBlobContent(
        databaseUniqueName: String,
        collectionName: String,
        scopeName: String,
        documentId: String,
        key: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName,
            collectionName: collectionName,
            scopeName: scopeName,
            reject: reject
        )
        if isError { return }
        let (isDocError, docId) = DataAdapter.shared.adaptNonEmptyString(
            value: documentId, propertyName: "docId", reject: reject
        )
        if isDocError { return }
        let (isKeyError, keyValue) = DataAdapter.shared.adaptNonEmptyString(
            value: key, propertyName: "key", reject: reject
        )
        if isKeyError { return }
        backgroundQueue.async {
            do {
                guard let blob = try CollectionManager.shared.getBlobContent(
                    keyValue,
                    documentId: docId,
                    collectionName: args.collectionName,
                    scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    resolve(["data": []])
                    return
                }
                resolve(["data": blob])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }
}
