/*
 * ============================================================
 * LEGACY FILE — DO NOT USE
 * ============================================================
 *
 * This header supplied React Native legacy bridge imports (`RCTBridgeModule`,
 * `RCTEventEmitter`, `RCTViewManager`, etc.) for the monolithic
 * `CblReactnative` native module. The shipping integration uses React Native
 * New Architecture Turbo Modules instead: native bindings are declared in
 * `src/NativeCbl*.ts`, implemented from Objective-C++ in `ios/RCTCblModules.mm`
 * and `ios/RCTCbl*.mm`, and backed by Swift in `ios/Cbl*Module.swift` with
 * `ios/RCTCblModules.h` for generated spec bases.
 *
 * Original filename: CblReactnative-Bridging-Header.h
 * Renamed to:        legacy_CblReactnative-Bridging-Header.h
 *
 * All legacy `#import` lines below remain commented out for historical reference.
 * ============================================================
 */

/*
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <React/RCTViewManager.h>
*/

/*
 * ============================================================
 * END OF LEGACY FILE
 * ============================================================
 */
