import Foundation
import CouchbaseLiteSwift
import React

@objcMembers public class CblCollectionModule: NSObject {

    private let backgroundQueue = CblNativeQueue.shared
    private let listenerQueue = CblNativeQueue.listener
    private let sendEventClosure: (String, Any?) -> Void

    @objc public init(sendEvent: @escaping (String, Any?) -> Void) {
        self.sendEventClosure = sendEvent
        super.init()
    }

    public func collection_CreateCollection(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                guard let collection = try DatabaseManager.shared.createCollection(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    reject("DATABASE_ERROR",
                           "Unable to create collection <\(args.scopeName)." +
                           "\(args.collectionName)> in database <\(args.databaseName)>", nil)
                    return
                }
                let dict = DataAdapter.shared.adaptCollectionToNSDictionary(
                    collection, databaseName: args.databaseName
                )
                resolve(dict)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_DeleteCollection(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                try DatabaseManager.shared.deleteCollection(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetCollection(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                guard let collection = try DatabaseManager.shared.collection(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    reject("DATABASE_ERROR",
                           "Unable to get collection <\(args.scopeName)." +
                           "\(args.collectionName)> in database <\(args.databaseName)>", nil)
                    return
                }
                let dict = DataAdapter.shared.adaptCollectionToNSDictionary(
                    collection, databaseName: args.databaseName
                )
                resolve(dict)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetCollections(
        databaseUniqueName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptScopeArgs(
            name: databaseUniqueName, scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                if let collections = try DatabaseManager.shared.collections(
                    args.scopeName, databaseName: args.databaseName
                ) {
                    let collectionsArray = DataAdapter.shared.adaptCollectionsToNSDictionaryString(
                        collections, databaseName: args.databaseName
                    )
                    resolve(["collections": collectionsArray])
                } else {
                    reject("DATABASE_ERROR",
                           "Unable to get collections for scope <\(args.scopeName)> " +
                           "in database <\(args.databaseName)>", nil)
                    return
                }
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetDefault(
        databaseUniqueName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, databaseName) = DataAdapter.shared.adaptDatabaseName(
            name: databaseUniqueName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                guard let collection = try DatabaseManager.shared.defaultCollection(databaseName)
                else {
                    reject("DATABASE_ERROR",
                           "Unable to get default collection for database \(databaseName)", nil)
                    return
                }
                let dict = DataAdapter.shared.adaptCollectionToNSDictionary(
                    collection, databaseName: databaseName
                )
                resolve(dict)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetCount(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                let count = try CollectionManager.shared.documentsCount(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(["count": count])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetFullName(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                let fullName = try CollectionManager.shared.fullName(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(["fullName": fullName])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_CreateIndex(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        indexName: String, index: Any,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        let (isIdxNameError, idxName) = DataAdapter.shared.adaptNonEmptyString(
            value: indexName, propertyName: "indexName", reject: reject
        )
        if isIdxNameError { return }
        let indexDict = index as? NSDictionary ?? NSDictionary()
        let (isIdxError, indexData) = DataAdapter.shared.adaptIndexToArrayAny(
            dict: indexDict, reject: reject
        )
        if isIdxError { return }
        backgroundQueue.async {
            do {
                try CollectionManager.shared.createIndex(
                    idxName, indexType: indexData.indexType, items: indexData.indexes,
                    collectionName: args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_DeleteIndex(
        databaseUniqueName: String, collectionName: String, scopeName: String, indexName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        let (isIdxNameError, idxName) = DataAdapter.shared.adaptNonEmptyString(
            value: indexName, propertyName: "indexName", reject: reject
        )
        if isIdxNameError { return }
        backgroundQueue.async {
            do {
                try CollectionManager.shared.deleteIndex(
                    idxName, collectionName: args.collectionName,
                    scopeName: args.scopeName, databaseName: args.databaseName
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_GetIndexes(
        databaseUniqueName: String, collectionName: String, scopeName: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        backgroundQueue.async {
            do {
                let indexes = try CollectionManager.shared.indexes(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                )
                resolve(["indexes": indexes])
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_AddChangeListener(
        databaseUniqueName: String, collectionName: String,
        scopeName: String, changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        let (isTokenError, uuidToken) = DataAdapter.shared.adaptNonEmptyString(
            value: changeListenerToken,
            propertyName: "changeListenerToken", reject: reject
        )
        if isTokenError { return }
        backgroundQueue.async {
            do {
                guard let collection = try CollectionManager.shared.getCollection(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    reject("DATABASE_ERROR", "Could not find collection", nil)
                    return
                }
                let listener = collection.addChangeListener(
                    queue: self.listenerQueue
                ) { [weak self] change in
                    guard let self = self else { return }
                    let resultData = NSMutableDictionary()
                    resultData["token"] = uuidToken
                    resultData["documentIDs"] = change.documentIDs
                    resultData["collection"] = DataAdapter.shared.adaptCollectionToNSDictionary(
                        collection, databaseName: args.databaseName
                    )
                    self.sendEventClosure("collectionChange", resultData)
                }
                ListenerTokenStore.shared.add(
                    token: uuidToken,
                    record: ChangeListenerRecord(
                        nativeListenerToken: listener, listenerType: .collection,
                        databaseUniqueName: args.databaseName
                    )
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_AddDocumentChangeListener(
        databaseUniqueName: String, collectionName: String,
        scopeName: String, documentId: String, changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        let (isError, args) = DataAdapter.shared.adaptCollectionArgs(
            name: databaseUniqueName, collectionName: collectionName,
            scopeName: scopeName, reject: reject
        )
        if isError { return }
        let (isTokenError, uuidToken) = DataAdapter.shared.adaptNonEmptyString(
            value: changeListenerToken,
            propertyName: "changeListenerToken", reject: reject
        )
        if isTokenError { return }
        let (isDocError, docId) = DataAdapter.shared.adaptNonEmptyString(
            value: documentId, propertyName: "documentId", reject: reject
        )
        if isDocError { return }
        backgroundQueue.async {
            do {
                guard let collection = try CollectionManager.shared.getCollection(
                    args.collectionName, scopeName: args.scopeName,
                    databaseName: args.databaseName
                ) else {
                    reject("DATABASE_ERROR", "Could not find collection", nil)
                    return
                }
                let listener = collection.addDocumentChangeListener(
                    id: docId, queue: self.listenerQueue
                ) { [weak self] change in
                    guard let self = self else { return }
                    let resultData = NSMutableDictionary()
                    resultData["token"] = uuidToken
                    resultData["documentId"] = change.documentID
                    resultData["database"] = change.database.name
                    resultData["collection"] = DataAdapter.shared.adaptCollectionToNSDictionary(
                        collection, databaseName: args.databaseName
                    )
                    self.sendEventClosure("collectionDocumentChange", resultData)
                }
                ListenerTokenStore.shared.add(
                    token: uuidToken,
                    record: ChangeListenerRecord(
                        nativeListenerToken: listener, listenerType: .collectionDocument,
                        databaseUniqueName: args.databaseName
                    )
                )
                resolve(nil)
            } catch let error as NSError {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            } catch {
                reject("DATABASE_ERROR", error.localizedDescription, nil)
            }
        }
    }

    public func collection_RemoveChangeListener(
        changeListenerToken: String,
        resolve: @escaping RCTPromiseResolveBlock,
        reject: @escaping RCTPromiseRejectBlock
    ) {
        backgroundQueue.async {
            guard let record = ListenerTokenStore.shared.remove(token: changeListenerToken) else {
                reject("LISTENER_ERROR",
                       "No listener found for token \(changeListenerToken)", nil)
                return
            }
            record.nativeListenerToken.remove()
            resolve(nil)
        }
    }
}
