#import <Foundation/Foundation.h>
#import <CblReactnativeSpecs/CblReactnativeSpecs.h>
#import <React/RCTBridgeModule.h>

// MARK: - Non-event modules

@interface RCTCblDatabase  : NSObject                    <NativeCblDatabaseSpec>    @end
@interface RCTCblScope     : NSObject                    <NativeCblScopeSpec>       @end
@interface RCTCblDocument  : NSObject                    <NativeCblDocumentSpec>    @end
@interface RCTCblEngine    : NSObject                    <NativeCblEngineSpec>      @end

// MARK: - Event-emitting modules
// After running codegen with EventEmitter<T> specs, NativeCblXxxSpecBase gains
// emitXxx: methods backed by AsyncEventEmitter (JSI runtimeExecutor path).
// JS subscribes via NativeCblCollection.collectionChange(cb) — no NativeEventEmitter.

@interface RCTCblCollection : NativeCblCollectionSpecBase <NativeCblCollectionSpec> @end
@interface RCTCblQuery      : NativeCblQuerySpecBase      <NativeCblQuerySpec>      @end
// RCTCblLogging conforms to RCTInvalidating so the bridge calls -invalidate on
// teardown, letting us unregister the custom log sink (see CblLoggingModule.swift).
@interface RCTCblLogging    : NativeCblLoggingSpecBase    <NativeCblLoggingSpec, RCTInvalidating> @end
@interface RCTCblReplicator : NativeCblReplicatorSpecBase <NativeCblReplicatorSpec> @end
