import Foundation
import CouchbaseLiteSwift

struct ChangeListenerRecord {
    let nativeListenerToken: ListenerToken
    let listenerType: ChangeListenerType
    var replicatorId: String? = nil
    // RN unique database handle for collection / collection-document listeners, so they
    // can be swept when their owning database is closed or deleted. nil for query
    // (tracked via QueryManager) and replicator (tracked via replicatorId) listeners.
    var databaseUniqueName: String? = nil
}

enum ChangeListenerType: String {
    case collection
    case collectionDocument
    case query
    case replicator
    case replicatorDocument
}

class ListenerTokenStore {

    static let shared: ListenerTokenStore = ListenerTokenStore()
    private init() {}

    private let queue = DispatchQueue(
        label: "com.cblite.ListenerTokenStore",
        attributes: .concurrent
    )
    private var store: [String: ChangeListenerRecord] = [:]

    func add(token: String, record: ChangeListenerRecord) {
        // If a record already existed for this token, capture it under the barrier and
        // remove its native listener afterwards (outside the lock, mirroring remove(token:))
        // so overwriting the entry doesn't orphan the previous CBL ListenerToken.
        var previous: ChangeListenerRecord?
        queue.sync(flags: .barrier) {
            previous = self.store[token]
            self.store[token] = record
        }
        previous?.nativeListenerToken.remove()
    }

    func remove(token: String) -> ChangeListenerRecord? {
        var removed: ChangeListenerRecord?
        queue.sync(flags: .barrier) {
            removed = self.store.removeValue(forKey: token)
        }
        return removed
    }

    func get(token: String) -> ChangeListenerRecord? {
        queue.sync {
            return self.store[token]
        }
    }

    func removeAll(forReplicatorId replicatorId: String) -> [ChangeListenerRecord] {
        var removed: [ChangeListenerRecord] = []
        queue.sync(flags: .barrier) {
            let keys = self.store.compactMap { key, record -> String? in
                record.replicatorId == replicatorId ? key : nil
            }
            for key in keys {
                if let record = self.store.removeValue(forKey: key) {
                    removed.append(record)
                }
            }
        }
        return removed
    }

    func removeAll(forDatabaseUniqueName databaseUniqueName: String) -> [ChangeListenerRecord] {
        var removed: [ChangeListenerRecord] = []
        queue.sync(flags: .barrier) {
            let keys = self.store.compactMap { key, record -> String? in
                record.databaseUniqueName == databaseUniqueName ? key : nil
            }
            for key in keys {
                if let record = self.store.removeValue(forKey: key) {
                    removed.append(record)
                }
            }
        }
        return removed
    }
}
