import Foundation

enum CblNativeQueue {
    /// Serial lane for request handling (opens/saves/deletes/queries/etc.). Kept serial so
    /// the implicit serialization of native state that the modules rely on is preserved —
    /// making this concurrent would surface races currently masked by single-lane execution.
    static let shared = DispatchQueue(
        label: "com.cblite.reactnative.backgroundQueue",
        qos: .userInitiated
    )

    /// Separate serial lane on which CBL delivers listener callbacks (collection / document /
    /// query / replicator change events) and from which they emit to JS. Splitting this off
    /// the request lane keeps bursty event traffic from contending with — and delaying —
    /// long native operations. These callbacks only build payloads and emit; they do not
    /// mutate the native state guarded by `shared`, so a dedicated lane is safe.
    static let listener = DispatchQueue(
        label: "com.cblite.reactnative.listenerQueue",
        qos: .userInitiated
    )
}
