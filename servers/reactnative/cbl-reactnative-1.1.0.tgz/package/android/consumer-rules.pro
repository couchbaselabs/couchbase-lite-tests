# Consumer ProGuard/R8 rules shipped to apps that depend on cbl-reactnative.
#
# The RN log-write path (LogSinks.write / logging_WriteLog) injects log lines
# into Couchbase Lite via the SDK's internal logging entry point,
# com.couchbase.lite.internal.logging.Log.log(...). That class is @Internal and
# would otherwise be a candidate for stripping/obfuscation in release builds,
# which would silently break file/console/custom forwarding. Keep it intact.
-keep class com.couchbase.lite.internal.logging.Log { *; }
