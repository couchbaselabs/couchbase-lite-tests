package com.cblreactnative

import cbl.js.kotlin.DatabaseManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@Suppress("FunctionName")
class CblScopeModule(reactContext: ReactApplicationContext) :
  NativeCblScopeSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    scope.cancel()
    super.invalidate()
  }

  override fun scope_GetDefault(databaseUniqueName: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
          return@launch
        }
        val scopeValue = DatabaseManager.defaultScope(databaseUniqueName)
        if (scopeValue != null) {
          val scopeMap = DataAdapter.scopeToMap(scopeValue, databaseUniqueName)
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(scopeMap)
          }
        } else {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Error getting default scope")
          }
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun scope_GetScope(
    databaseUniqueName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateScope(scopeName, databaseUniqueName, promise)) {
          return@launch
        }
        val scopeValue = DatabaseManager.getScope(databaseUniqueName, scopeName)
        if (scopeValue != null) {
          val scopeMap = DataAdapter.scopeToMap(scopeValue, databaseUniqueName)
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(scopeMap)
          }
        } else {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Error getting scope")
          }
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun scope_GetScopes(databaseUniqueName: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
          return@launch
        }
        val scopes = DatabaseManager.scopes(databaseUniqueName)
        val scopeList = Arguments.createArray()
        scopes.forEach { scope ->
          val scopeMap = DataAdapter.scopeToMap(scope, databaseUniqueName)
          scopeList.pushMap(scopeMap)
        }
        val resultsScopes: WritableMap = Arguments.createMap()
        resultsScopes.putArray("scopes", scopeList)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(resultsScopes)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }
}
