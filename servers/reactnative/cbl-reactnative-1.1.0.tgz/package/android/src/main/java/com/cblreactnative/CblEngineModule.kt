package com.cblreactnative

import android.util.Log
import cbl.js.kotlin.FileSystemHelper
import cbl.js.kotlin.QueryManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

// Engine TurboModule — see ios/CblEngineModule.swift.
@Suppress("FunctionName")
class CblEngineModule(reactContext: ReactApplicationContext) :
  NativeCblEngineSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    scope.cancel()
    super.invalidate()
  }

  companion object {
    private const val TAG = "CblEngineModule"
  }

  override fun file_GetDefaultPath(promise: Promise) {
    scope.launch {
      try {
        val path = FileSystemHelper.fileGetDefaultPath(reactApplicationContext)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(path)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("FILE_ERROR", e.message)
        }
      }
    }
  }

  override fun file_GetFileNamesInDirectory(path: String, promise: Promise) {
    scope.launch {
      try {
        // Defense-in-depth: reject empty paths and parent-directory traversal before
        // touching the filesystem.
        if (path.isEmpty() || DataValidation.hasPathTraversal(path)) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "FILE_ERROR",
              "Invalid path: must be non-empty and must not contain parent-directory traversal ('..')"
            )
          }
          return@launch
        }
        // Reject non-directories up front; iOS relies on the same FILE_ERROR from the helper.
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("FILE_ERROR", "Path is not a directory: $path")
          }
          return@launch
        }
        val names = FileSystemHelper.listFilesAndDirectories(path)
        val arr = Arguments.createArray()
        for (n in names) arr.pushString(n)
        val map = Arguments.createMap()
        map.putArray("files", arr)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(map)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("FILE_ERROR", e.message)
        }
      }
    }
  }

  // Generic token removal; QUERY tokens also evict the cached Query. Matches iOS.
  override fun listenerToken_Remove(
    changeListenerToken: String,
    promise: Promise,
  ) {
    Log.d(TAG, "listenerToken_Remove ENTER token=$changeListenerToken")
    scope.launch {
      try {
        // Peek without evicting so a failing native remove() does not leave the
        // store inconsistent (mirrors query_RemoveChangeListener).
        val record = ListenerTokenStore.get(changeListenerToken)
        if (record == null) {
          val msg = "No listener found for token $changeListenerToken"
          Log.w(TAG, "listenerToken_Remove: $msg")
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("LISTENER_ERROR", msg)
          }
          return@launch
        }
        // Tear down the native listener first; only evict from the store once it
        // has succeeded so the record stays recoverable if remove() throws.
        record.nativeListenerToken.remove()
        ListenerTokenStore.remove(changeListenerToken)
        if (record.listenerType == ChangeListenerType.QUERY) {
          QueryManager.removeListener(changeListenerToken)
        }
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(TAG, "listenerToken_Remove threw: ${e.javaClass.simpleName} ${e.message}", e)
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LISTENER_ERROR", e.message)
        }
      }
    }
  }
}
