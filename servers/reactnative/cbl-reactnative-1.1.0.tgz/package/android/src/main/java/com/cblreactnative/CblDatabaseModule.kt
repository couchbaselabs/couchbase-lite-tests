package com.cblreactnative

import cbl.js.kotlin.DatabaseManager
import cbl.js.kotlin.QueryManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@Suppress("FunctionName")
class CblDatabaseModule(reactContext: ReactApplicationContext) :
  NativeCblDatabaseSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    scope.cancel()
    super.invalidate()
  }

  private fun removeActiveQueryListeners(databaseName: String) {
    val tokens = QueryManager.listenerTokens(databaseName)
    for (token in tokens) {
      val record = ListenerTokenStore.remove(token)
      // Best-effort cleanup: a single failing token must not abort the loop
      // or block the subsequent close/delete.
      runCatching { record?.nativeListenerToken?.remove() }
    }
    QueryManager.removeQueries(databaseName)
  }

  // Drop collection-change and collection-document-change listeners attached to this
  // database before close/delete. Without this their CBL ListenerTokens stay registered
  // and their store entries leak across open/close cycles, and callbacks can fire against
  // a closed database handle.
  private fun removeActiveCollectionListeners(databaseUniqueName: String) {
    val records = ListenerTokenStore.removeAllForDatabase(databaseUniqueName)
    for (record in records) {
      // Best-effort cleanup: a single failing token must not abort the loop
      // or block the subsequent close/delete.
      runCatching { record.nativeListenerToken.remove() }
    }
  }

  override fun database_Open(
    databaseName: String,
    directory: String?,
    encryptionKey: String?,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseName, promise)) {
        return@launch
      }
      try {
        val databaseConfig = DataAdapter.toDatabaseConfigJson(directory, encryptionKey)
        val databaseUniqueName = DatabaseManager.openDatabase(
          databaseName,
          databaseConfig,
          reactApplicationContext
        )
        reactApplicationContext.runOnUiQueueThread {
          val result = Arguments.createMap()
          result.putString("databaseUniqueName", databaseUniqueName)
          promise.resolve(result)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_Close(databaseUniqueName: String, promise: Promise) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        removeActiveQueryListeners(databaseUniqueName)
        removeActiveCollectionListeners(databaseUniqueName)
        DatabaseManager.closeDatabase(databaseUniqueName)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_Delete(databaseUniqueName: String, promise: Promise) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        removeActiveQueryListeners(databaseUniqueName)
        removeActiveCollectionListeners(databaseUniqueName)
        DatabaseManager.delete(databaseUniqueName)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_DeleteWithPath(
    path: String,
    databaseName: String,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseName, promise)) {
        return@launch
      }
      if (!DataValidation.validatePath(path, promise)) {
        return@launch
      }
      try {
        // databaseName here is the LOGICAL name (delete-by-path is not tied to an open
        // handle). Cached queries and listeners are keyed by the unique runtime handle, so
        // resolve the open handles for this logical name and tear those down — passing the
        // logical name directly would never match and would leak.
        for (uniqueName in DatabaseManager.openUniqueNamesForLogicalName(databaseName)) {
          removeActiveQueryListeners(uniqueName)
          removeActiveCollectionListeners(uniqueName)
        }
        DatabaseManager.deleteWithPath(databaseName, path)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_Copy(
    path: String,
    newDatabaseName: String,
    directory: String?,
    encryptionKey: String?,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(newDatabaseName, promise)) {
          return@launch
        }
        if (!DataValidation.validatePath(path, promise)) {
          return@launch
        }
        val databaseConfig = DataAdapter.toDatabaseConfigJson(directory, encryptionKey)
        DatabaseManager.copy(path, newDatabaseName, databaseConfig, reactApplicationContext)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_Exists(
    databaseName: String,
    directory: String,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseName, promise)) {
        return@launch
      }
      if (!DataValidation.validatePath(directory, promise)) {
        return@launch
      }
      try {
        val exists = DatabaseManager.exists(databaseName, directory)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(exists)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_GetPath(databaseUniqueName: String, promise: Promise) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        val path = DatabaseManager.getPath(databaseUniqueName)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(path)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_PerformMaintenance(
    databaseUniqueName: String,
    maintenanceType: Double,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        val mType = DataAdapter.intToMaintenanceType(maintenanceType.toInt())
        DatabaseManager.performMaintenance(databaseUniqueName, mType)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun database_ChangeEncryptionKey(
    databaseUniqueName: String,
    newKey: String?,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        val keyToUse = newKey?.takeIf { it.isNotEmpty() }
        DatabaseManager.changeEncryptionKey(databaseUniqueName, keyToUse)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }
}
