package com.cblreactnative

import android.content.Context
import com.couchbase.lite.CouchbaseLite

internal object CouchbaseLiteInitializer {
  @Volatile
  private var initialized = false

  @Synchronized
  fun ensureInit(context: Context) {
    if (initialized) return
    CouchbaseLite.init(context.applicationContext, true)
    initialized = true
  }
}
