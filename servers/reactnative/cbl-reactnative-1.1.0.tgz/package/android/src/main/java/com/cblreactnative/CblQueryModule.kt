package com.cblreactnative

import android.util.Log
import cbl.js.kotlin.DatabaseManager
import cbl.js.kotlin.QueryManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

// Android TurboModule for queries. See ios/CblQueryModule.swift.
@Suppress("FunctionName")
class CblQueryModule(reactContext: ReactApplicationContext) :
  NativeCblQuerySpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  // Guards the emit path so a CBL query-change callback firing after teardown doesn't push
  // into a dead bridge.
  @Volatile
  private var isInvalidated = false

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    isInvalidated = true
    scope.cancel()
    super.invalidate()
  }

  // Same safe emit wrapper as CblCollectionModule.
  private fun emitQueryChangeSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      Log.d(TAG, "emitQueryChange → JSI runtime (typed emitter)")
      emitQueryChange(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitQueryChange FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  companion object {
    private const val TAG = "CblQueryModule"
  }

  override fun query_Execute(
    databaseUniqueName: String,
    queryId: String,
    query: String,
    parameters: ReadableMap,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(databaseUniqueName, promise) ||
          !DataValidation.validateNonEmptyString(queryId, "queryId", promise) ||
          !DataValidation.validateQuery(query, promise)
        ) return@launch

        val database = DatabaseManager.getDatabase(databaseUniqueName)
        if (database == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Could not find database with name $databaseUniqueName")
          }
          return@launch
        }

        val parametersForQuery = try {
          DataAdapter.readableMapToParameters(parameters)
        } catch (e: Throwable) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("QUERY_ERROR", e.message)
          }
          return@launch
        }

        // Reuse a cached query when a listener exists; otherwise run a one-off query.
        val cachedResults = QueryManager.withCachedQuery(queryId) { cached ->
          parametersForQuery?.let { cached.parameters = it }
          val rs = cached.execute().allResults()
          "[" + rs.joinToString(",") { it.toJSON() } + "]"
        }
        val resultsJson = cachedResults
          ?: DatabaseManager.executeQuery(query, databaseUniqueName, parametersForQuery)

        val resultsMap = Arguments.createMap()
        resultsMap.putString("data", resultsJson)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(resultsMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("QUERY_ERROR", e.message)
        }
      }
    }
  }

  override fun query_Explain(
    databaseUniqueName: String,
    queryId: String,
    query: String,
    parameters: ReadableMap,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(databaseUniqueName, promise) ||
          !DataValidation.validateNonEmptyString(queryId, "queryId", promise) ||
          !DataValidation.validateQuery(query, promise)
        ) return@launch

        val database = DatabaseManager.getDatabase(databaseUniqueName)
        if (database == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Could not find database with name $databaseUniqueName")
          }
          return@launch
        }

        val parametersForQuery = try {
          DataAdapter.readableMapToParameters(parameters)
        } catch (e: Throwable) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("QUERY_ERROR", e.message)
          }
          return@launch
        }

        val explanation = QueryManager.withCachedQuery(queryId) { cached ->
          parametersForQuery?.let { cached.parameters = it }
          cached.explain()
        } ?: DatabaseManager.explainQuery(query, databaseUniqueName, parametersForQuery)

        val resultsMap = Arguments.createMap()
        resultsMap.putString("data", explanation)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(resultsMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("QUERY_ERROR", e.message)
        }
      }
    }
  }

  override fun query_AddChangeListener(
    databaseUniqueName: String,
    queryId: String,
    query: String,
    parameters: ReadableMap,
    changeListenerToken: String,
    promise: Promise,
  ) {
    Log.d(
      TAG,
      "query_AddChangeListener ENTER db=$databaseUniqueName qid=$queryId token=$changeListenerToken",
    )
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(databaseUniqueName, promise) ||
          !DataValidation.validateNonEmptyString(changeListenerToken, "changeListenerToken", promise, "LISTENER_ERROR") ||
          !DataValidation.validateNonEmptyString(queryId, "queryId", promise) ||
          !DataValidation.validateQuery(query, promise)
        ) return@launch

        val database = DatabaseManager.getDatabase(databaseUniqueName)
        if (database == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Could not find database with name $databaseUniqueName")
          }
          return@launch
        }

        // Parse params before caching so a bad map does not leave an orphan Query.
        val parametersForQuery = try {
          DataAdapter.readableMapToParameters(parameters)
        } catch (e: Throwable) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("QUERY_ERROR", e.message)
          }
          return@launch
        }

        val q = QueryManager.getOrCreate(queryId, query, databaseUniqueName, database)

        parametersForQuery?.let { params ->
          QueryManager.withCachedQuery(queryId) { cached ->
            cached.parameters = params
          }
        }

        val listener = q.addChangeListener { change ->
          Log.d(
            TAG,
            "[CBL CALLBACK] queryChange fired: token=$changeListenerToken hasError=${change.error != null}",
          )
          val resultMap = Arguments.createMap()
          resultMap.putString("token", changeListenerToken)
          change.results?.let { results ->
            val dataJson = "[" + results.joinToString(",") { it.toJSON() } + "]"
            resultMap.putString("data", dataJson)
          }
          change.error?.let { err ->
            resultMap.putString("error", err.localizedMessage ?: err.toString())
          }
          emitQueryChangeSafe(resultMap)
        }

        ListenerTokenStore.add(
          changeListenerToken,
          ChangeListenerRecord(
            nativeListenerToken = listener,
            listenerType = ChangeListenerType.QUERY,
          ),
        )
        QueryManager.recordListener(queryId, changeListenerToken)

        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(TAG, "query_AddChangeListener threw: ${e.javaClass.simpleName} ${e.message}", e)
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("QUERY_ERROR", e.message)
        }
      }
    }
  }

  override fun query_RemoveChangeListener(
    changeListenerToken: String,
    promise: Promise,
  ) {
    Log.d(TAG, "query_RemoveChangeListener ENTER token=$changeListenerToken")
    scope.launch {
      try {
        // Peek without evicting so a wrong-type token or a failing native
        // remove() does not leave the store inconsistent.
        val record = ListenerTokenStore.get(changeListenerToken)
        if (record == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "No listener found for token $changeListenerToken",
            )
          }
          return@launch
        }

        if (record.listenerType != ChangeListenerType.QUERY) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "Token $changeListenerToken is not a query listener",
            )
          }
          return@launch
        }

        // Tear down the native listener first; only evict from the store once
        // it has succeeded so the record stays recoverable if remove() throws.
        record.nativeListenerToken.remove()
        ListenerTokenStore.remove(changeListenerToken)
        QueryManager.removeListener(changeListenerToken)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(TAG, "query_RemoveChangeListener threw: ${e.javaClass.simpleName} ${e.message}", e)
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LISTENER_ERROR", e.message)
        }
      }
    }
  }
}
