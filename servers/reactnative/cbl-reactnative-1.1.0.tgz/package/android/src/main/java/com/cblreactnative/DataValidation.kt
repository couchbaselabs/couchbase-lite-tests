package com.cblreactnative

import com.facebook.react.bridge.Promise

object DataValidation {

  fun validateCollection(
    collectionName: String,
    scopeName: String,
    databaseName: String,
    promise: Promise): Boolean {
    return validateCollectionName(collectionName, promise)
      && validateScopeName(scopeName, promise)
      && validateDatabaseName(databaseName, promise)
  }

  private fun validateCollectionName(
    collectionName: String,
    promise: Promise): Boolean {
    val isValid = collectionName.isNotEmpty()
    if (!isValid) {
      promise.reject("DATABASE_ERROR", "Collection name must be provided")
    }
    return isValid
  }

  fun validateDatabaseName(
    databaseName: String,
    promise: Promise
  ): Boolean {
    val isValid = databaseName.isNotEmpty()
    if (!isValid) {
      promise.reject("DATABASE_ERROR", "Database name must be provided")
    }
    return isValid
  }

  fun validateDocumentId(
    documentId: String,
    promise: Promise
  ): Boolean {
    val isValid = documentId.isNotEmpty()
    if (!isValid) {
      promise.reject("DATABASE_ERROR", "documentId must be provided")
    }
    return isValid
  }

  fun validatePath(
    path: String,
    promise: Promise): Boolean {
    if (path.isEmpty()) {
      promise.reject("DATABASE_ERROR", "Database path must be provided")
      return false
    }
    if (hasPathTraversal(path)) {
      promise.reject(
        "DATABASE_ERROR",
        "Invalid path: parent-directory traversal ('..') is not allowed"
      )
      return false
    }
    return true
  }

  /**
   * Defense-in-depth for filesystem paths supplied from JS: rejects any parent-directory
   * ('..') segment, regardless of separator style, so a path cannot be used to escape its
   * intended directory for destructive (delete) or write (copy/log) operations. Absolute,
   * out-of-sandbox paths remain bounded by the OS's app-sandbox permissions.
   */
  fun hasPathTraversal(path: String): Boolean {
    return path.split('/', '\\').any { it.trim() == ".." }
  }

  fun validateQuery(
    query: String,
    promise: Promise
  ): Boolean {
    val isValid = query.isNotEmpty()
    if (!isValid) {
      promise.reject("QUERY_ERROR", "Query must be provided")
    }
    return isValid
  }

  fun validateReplicatorId(
    replicatorId: String,
    promise: Promise
  ): Boolean {
    val isValid = replicatorId.isNotEmpty()
    if (!isValid) {
      promise.reject("REPLICATOR_ERROR", "replicatorId must be provided")
    }
    return isValid
  }

  fun validateScope(
    scopeName: String,
    databaseName: String,
    promise: Promise): Boolean {
    return validateScopeName(scopeName, promise)
      && validateDatabaseName(databaseName, promise)
  }

  private fun validateScopeName(
    scopeName: String,
    promise: Promise): Boolean {
    val isValid = scopeName.isNotEmpty()
    if (!isValid) {
      promise.reject("DATABASE_ERROR", "Scope name must be provided")
    }
    return isValid
  }

  fun validateNonEmptyString(
    value: String,
    propertyName: String,
    promise: Promise,
    errorCode: String = "DATABASE_ERROR",
    message: String = "$propertyName must be provided",
  ): Boolean {
    val isValid = value.isNotEmpty()
    if (!isValid) {
      promise.reject(errorCode, message)
    }
    return isValid
  }
}
