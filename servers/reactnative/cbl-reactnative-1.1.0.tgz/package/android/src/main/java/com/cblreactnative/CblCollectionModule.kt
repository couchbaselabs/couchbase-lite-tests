package com.cblreactnative

import android.util.Log
import cbl.js.kotlin.CollectionManager
import cbl.js.kotlin.DatabaseManager
import com.couchbase.lite.IndexBuilder
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@Suppress("FunctionName")
class CblCollectionModule(reactContext: ReactApplicationContext) :
  NativeCblCollectionSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  // Guards the emit path so a CBL collection/document-change callback firing after teardown
  // doesn't push into a dead bridge.
  @Volatile
  private var isInvalidated = false

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    isInvalidated = true
    scope.cancel()
    super.invalidate()
  }

  // Typed codegen emitters; wrap so JSI failures don't escape the CBL callback thread.
  private fun emitCollectionChangeSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      emitCollectionChange(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitCollectionChange FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  private fun emitCollectionDocumentChangeSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      emitCollectionDocumentChange(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitCollectionDocumentChange FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  companion object {
    private const val TAG = "CblCollectionModule"
  }

  override fun collection_CreateCollection(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        val col = DatabaseManager.createCollection(
          collectionName, scopeName, databaseUniqueName
        )
        col?.let { collection ->
          val colMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(colMap)
          }
          return@launch
        }
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", "Error creating collection")
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_DeleteCollection(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        DatabaseManager.deleteCollection(collectionName, scopeName, databaseUniqueName)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetCollection(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        val col = DatabaseManager.getCollection(collectionName, scopeName, databaseUniqueName)
        col?.let { collection ->
          val colMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(colMap)
          }
          return@launch
        }
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", "Error getting collection")
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetCollections(
    databaseUniqueName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateScope(scopeName, databaseUniqueName, promise)) {
          return@launch
        }
        val cols = DatabaseManager.getCollections(scopeName, databaseUniqueName)
        val colList = Arguments.createArray()
        cols?.forEach { collection ->
          val colMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          colList.pushMap(colMap)
        }
        val resultsCollections: WritableMap = Arguments.createMap()
        resultsCollections.putArray("collections", colList)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(resultsCollections)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetDefault(
    databaseUniqueName: String,
    promise: Promise,
  ) {
    scope.launch {
      if (!DataValidation.validateDatabaseName(databaseUniqueName, promise)) {
        return@launch
      }
      try {
        val col = DatabaseManager.defaultCollection(databaseUniqueName)
        col?.let { collection ->
          val colMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(colMap)
          }
          return@launch
        }
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", "Error getting default collection")
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetCount(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        val count = CollectionManager.documentsCount(
          collectionName, scopeName, databaseUniqueName
        )
        val map = Arguments.createMap()
        // 64-bit count: the RN bridge has no 64-bit int, so forward as Double to avoid
        // overflow/truncation for very large collections.
        map.putDouble("count", count.toDouble())
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(map)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetFullName(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        val fullName = CollectionManager.fullName(
          collectionName, scopeName, databaseUniqueName
        )
        val map = Arguments.createMap()
        map.putString("fullName", fullName)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(map)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_CreateIndex(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    indexName: String,
    index: ReadableMap,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateNonEmptyString(
            indexName, "indexName", promise
          )
        ) return@launch
        val indexDto = DataAdapter.mapToIndexDto(indexName, index)
        if (indexDto.type == "value") {
          val idx = IndexBuilder.valueIndex(*indexDto.valueItems)
          CollectionManager.createIndex(
            indexName, idx, collectionName, scopeName, databaseUniqueName
          )
        } else {
          val idx = IndexBuilder.fullTextIndex(*indexDto.fullTextItems)
          if (indexDto.language != null) {
            idx.setLanguage(indexDto.language)
          }
          if (indexDto.ignoreAccents != null) {
            idx.ignoreAccents(indexDto.ignoreAccents)
          }
          CollectionManager.createIndex(
            indexName, idx, collectionName, scopeName, databaseUniqueName
          )
        }
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_DeleteIndex(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    indexName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateNonEmptyString(
            indexName, "indexName", promise
          )
        ) return@launch
        CollectionManager.deleteIndex(
          indexName, collectionName, scopeName, databaseUniqueName
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetIndexes(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          )
        ) return@launch
        val indexes = CollectionManager.getIndexes(
          collectionName, scopeName, databaseUniqueName
        )
        val writableArray = Arguments.createArray()
        if (indexes != null) {
          for (item in indexes) {
            writableArray.pushString(item)
          }
        }
        val resultsIndexes: WritableMap = Arguments.createMap()
        resultsIndexes.putArray("indexes", writableArray)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(resultsIndexes)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_AddChangeListener(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    changeListenerToken: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateNonEmptyString(
            changeListenerToken, "changeListenerToken", promise, "LISTENER_ERROR"
          )
        ) {
          return@launch
        }
        val collection = DatabaseManager.getCollection(
          collectionName, scopeName, databaseUniqueName
        )
        if (collection == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Could not find collection")
          }
          return@launch
        }
        val listener = collection.addChangeListener { change ->
          val resultMap = Arguments.createMap()
          resultMap.putString("token", changeListenerToken)

          val docIdsArray = Arguments.createArray()
          change.documentIDs.forEach { docIdsArray.pushString(it) }
          resultMap.putArray("documentIDs", docIdsArray)

          val collectionMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          resultMap.putMap("collection", collectionMap)
          emitCollectionChangeSafe(resultMap)
        }

        ListenerTokenStore.add(
          changeListenerToken,
          ChangeListenerRecord(
            nativeListenerToken = listener,
            listenerType = ChangeListenerType.COLLECTION,
            databaseUniqueName = databaseUniqueName,
          ),
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "collection_AddChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_AddDocumentChangeListener(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    changeListenerToken: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
          || !DataValidation.validateNonEmptyString(
            changeListenerToken, "changeListenerToken", promise, "LISTENER_ERROR"
          )
        ) {
          return@launch
        }
        val collection = DatabaseManager.getCollection(
          collectionName, scopeName, databaseUniqueName
        )
        if (collection == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject("DATABASE_ERROR", "Could not find collection")
          }
          return@launch
        }
        val listener = collection.addDocumentChangeListener(docId) { change ->
          val resultMap = Arguments.createMap()
          resultMap.putString("token", changeListenerToken)
          resultMap.putString("documentId", change.documentID)
          resultMap.putString("database", collection.database.name) // CBL name, not RN handle
          val collectionMap = DataAdapter.cblCollectionToMap(collection, databaseUniqueName)
          resultMap.putMap("collection", collectionMap)
          emitCollectionDocumentChangeSafe(resultMap)
        }

        ListenerTokenStore.add(
          changeListenerToken,
          ChangeListenerRecord(
            nativeListenerToken = listener,
            listenerType = ChangeListenerType.COLLECTION_DOCUMENT,
            databaseUniqueName = databaseUniqueName,
          ),
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "collection_AddDocumentChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_RemoveChangeListener(
    changeListenerToken: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        val record = ListenerTokenStore.remove(changeListenerToken)
        if (record == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "No listener found for token $changeListenerToken",
            )
          }
          return@launch
        }
        record.nativeListenerToken.remove()
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "collection_RemoveChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LISTENER_ERROR", e.message)
        }
      }
    }
  }
}
