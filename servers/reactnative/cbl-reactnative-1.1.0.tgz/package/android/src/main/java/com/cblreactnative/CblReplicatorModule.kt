package com.cblreactnative

import android.util.Log
import cbl.js.kotlin.ReplicatorHelper
import cbl.js.kotlin.ReplicatorManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableType
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

// Android TurboModule for replication. See ios/CblReplicatorModule.swift.
@Suppress("FunctionName")
class CblReplicatorModule(reactContext: ReactApplicationContext) :
  NativeCblReplicatorSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  // Guards the emit path so a CBL replicator status/document callback firing after teardown
  // doesn't push into a dead bridge.
  @Volatile
  private var isInvalidated = false

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    isInvalidated = true
    scope.cancel()
    super.invalidate()
  }

  // Same safe emit wrappers as CblCollectionModule.
  private fun emitReplicatorStatusChangeSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      Log.d(TAG, "emitReplicatorStatusChange → JSI runtime (typed emitter)")
      emitReplicatorStatusChange(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitReplicatorStatusChange FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  private fun emitReplicatorDocumentChangeSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      Log.d(TAG, "emitReplicatorDocumentChange → JSI runtime (typed emitter)")
      emitReplicatorDocumentChange(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitReplicatorDocumentChange FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  companion object {
    private const val TAG = "CblReplicatorModule"
  }

  // Drop CBL listeners before ReplicatorManager cleanup (same order as iOS).
  private fun removeActiveReplicatorListeners(replicatorId: String) {
    val records = ListenerTokenStore.removeAllForReplicator(replicatorId)
    for (record in records) {
      try {
        record.nativeListenerToken.remove()
      } catch (e: Throwable) {
        Log.e(TAG, "removeActiveReplicatorListeners token.remove failed: ${e.message}", e)
      }
    }
  }

  override fun replicator_Create(config: ReadableMap, promise: Promise) {
    // Match iOS: accept empty collectionConfig strings; reject missing or non-string values.
    val collectionConfigJson: String? = try {
      if (config.hasKey("collectionConfig") &&
        config.getType("collectionConfig") == ReadableType.String
      ) {
        config.getString("collectionConfig")
      } else {
        null
      }
    } catch (e: Throwable) {
      null
    }
    if (collectionConfigJson == null) {
      promise.reject(
        "REPLICATOR_ERROR",
        "Couldn't parse replicator config from dictionary",
      )
      return
    }
    scope.launch {
      try {
        val replicatorConfig = ReplicatorHelper.replicatorConfigFromJson(config)
        val replicatorId = ReplicatorManager.createReplicator(replicatorConfig)
        val map = Arguments.createMap()
        map.putString("replicatorId", replicatorId)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(map) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_Start(replicatorId: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise)) return@launch
        ReplicatorManager.start(replicatorId, false)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_Stop(replicatorId: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise)) return@launch
        ReplicatorManager.stop(replicatorId)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_Cleanup(replicatorId: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise)) return@launch
        removeActiveReplicatorListeners(replicatorId)
        ReplicatorManager.cleanUp(replicatorId)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_GetStatus(replicatorId: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise)) return@launch
        val status = ReplicatorManager.getStatus(replicatorId)
        val resultMap = ReplicatorHelper.generateReplicatorStatusMap(status)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(resultMap) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_ResetCheckpoint(replicatorId: String, promise: Promise) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise)) return@launch
        ReplicatorManager.resetCheckpoint(replicatorId)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_GetPendingDocumentIds(
    databaseUniqueName: String,
    replicatorId: String,
    collectionName: String,
    scopeName: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise) ||
          !DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise,
          )
        ) return@launch
        val ids = ReplicatorManager.pendingDocIs(
          replicatorId, collectionName, scopeName, databaseUniqueName,
        )
        val arr = Arguments.fromList(ids.toList())
        val map = Arguments.createMap()
        map.putArray("pendingDocumentIds", arr)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(map) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_IsDocumentPending(
    databaseUniqueName: String,
    replicatorId: String,
    collectionName: String,
    scopeName: String,
    documentId: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise) ||
          !DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise,
          ) ||
          !DataValidation.validateDocumentId(documentId, promise)
        ) return@launch
        val isPending = ReplicatorManager.isDocumentPending(
          documentId, replicatorId, collectionName, scopeName, databaseUniqueName,
        )
        val map = Arguments.createMap()
        map.putBoolean("isPending", isPending)
        reactApplicationContext.runOnUiQueueThread { promise.resolve(map) }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_AddChangeListener(
    changeListenerToken: String,
    replicatorId: String,
    promise: Promise,
  ) {
    Log.d(
      TAG,
      "replicator_AddChangeListener ENTER token=$changeListenerToken rep=$replicatorId",
    )
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise) ||
          !DataValidation.validateNonEmptyString(
            changeListenerToken, "changeListenerToken", promise, "LISTENER_ERROR",
          )
        ) return@launch

        val replicator = ReplicatorManager.getReplicator(replicatorId)
        if (replicator == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "REPLICATOR_ERROR",
              "No such replicator found for id $replicatorId",
            )
          }
          return@launch
        }

        val listener = replicator.addChangeListener { change ->
          Log.d(
            TAG,
            "[CBL CALLBACK] replicatorStatusChange fired: " +
              "token=$changeListenerToken activity=${change.status.activityLevel}",
          )
          val statusMap = ReplicatorHelper.generateReplicatorStatusMap(change.status)
          val payload = Arguments.createMap()
          payload.putString("token", changeListenerToken)
          payload.putMap("status", statusMap)
          emitReplicatorStatusChangeSafe(payload)
        }

        ListenerTokenStore.add(
          changeListenerToken,
          ChangeListenerRecord(
            nativeListenerToken = listener,
            listenerType = ChangeListenerType.REPLICATOR,
            replicatorId = replicatorId,
          ),
        )
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "replicator_AddChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_AddDocumentChangeListener(
    changeListenerToken: String,
    replicatorId: String,
    promise: Promise,
  ) {
    Log.d(
      TAG,
      "replicator_AddDocumentChangeListener ENTER token=$changeListenerToken rep=$replicatorId",
    )
    scope.launch {
      try {
        if (!DataValidation.validateReplicatorId(replicatorId, promise) ||
          !DataValidation.validateNonEmptyString(
            changeListenerToken, "changeListenerToken", promise, "LISTENER_ERROR",
          )
        ) return@launch

        val replicator = ReplicatorManager.getReplicator(replicatorId)
        if (replicator == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "REPLICATOR_ERROR",
              "No such replicator found for id $replicatorId",
            )
          }
          return@launch
        }

        val listener = replicator.addDocumentReplicationListener { change ->
          Log.d(
            TAG,
            "[CBL CALLBACK] replicatorDocumentChange fired: " +
              "token=$changeListenerToken docCount=${change.documents.size} isPush=${change.isPush}",
          )
          val docMap = ReplicatorHelper.generateDocumentReplicationMap(
            change.documents, change.isPush,
          )
          val payload = Arguments.createMap()
          payload.putString("token", changeListenerToken)
          payload.putMap("documents", docMap)
          emitReplicatorDocumentChangeSafe(payload)
        }

        ListenerTokenStore.add(
          changeListenerToken,
          ChangeListenerRecord(
            nativeListenerToken = listener,
            listenerType = ChangeListenerType.REPLICATOR_DOCUMENT,
            replicatorId = replicatorId,
          ),
        )
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "replicator_AddDocumentChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("REPLICATOR_ERROR", e.message)
        }
      }
    }
  }

  override fun replicator_RemoveChangeListener(
    changeListenerToken: String,
    replicatorId: String,
    promise: Promise,
  ) {
    Log.d(
      TAG,
      "replicator_RemoveChangeListener ENTER token=$changeListenerToken rep=$replicatorId",
    )
    scope.launch {
      try {
        val record = ListenerTokenStore.remove(changeListenerToken)
        if (record == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "No listener found for token $changeListenerToken",
            )
          }
          return@launch
        }

        if (record.listenerType != ChangeListenerType.REPLICATOR &&
          record.listenerType != ChangeListenerType.REPLICATOR_DOCUMENT
        ) {
          ListenerTokenStore.add(changeListenerToken, record)
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "Token $changeListenerToken is not a replicator listener",
            )
          }
          return@launch
        }

        val storedId = record.replicatorId
        if (storedId != null && storedId != replicatorId) {
          ListenerTokenStore.add(changeListenerToken, record)
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LISTENER_ERROR",
              "Token $changeListenerToken does not belong to replicator $replicatorId",
            )
          }
          return@launch
        }

        record.nativeListenerToken.remove()
        reactApplicationContext.runOnUiQueueThread { promise.resolve(null) }
      } catch (e: Throwable) {
        Log.e(
          TAG,
          "replicator_RemoveChangeListener threw: ${e.javaClass.simpleName} ${e.message}",
          e,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LISTENER_ERROR", e.message)
        }
      }
    }
  }
}
