package com.cblreactnative

import android.util.Log
import cbl.js.kotlin.LoggingManager
import cbl.js.kotlin.LogSinksManager
import com.couchbase.lite.LogDomain
import com.couchbase.lite.LogLevel
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableArray
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

@Suppress("FunctionName")
class CblLoggingModule(reactContext: ReactApplicationContext) :
  NativeCblLoggingSpec(reactContext) {

  // Module-scoped single-thread dispatcher so config changes to CBL's global
  // LogSinks are applied in JS call order and are tied to the module lifecycle.
  // This replaces GlobalScope/Dispatchers.IO, whose launches could outlive a JS
  // reload and race each other.
  private val logDispatcher = Executors.newSingleThreadExecutor { runnable ->
    Thread(runnable, "CblLoggingModule").apply { isDaemon = true }
  }.asCoroutineDispatcher()
  private val scope = CoroutineScope(logDispatcher + SupervisorJob())

  // Set once the module is invalidated (JS reload / bridge teardown). Guards the
  // emit path so an in-flight CBL callback doesn't push into a dead bridge.
  @Volatile
  private var isInvalidated = false

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  // Called by React Native when the module is torn down (JS reload, bridge
  // recreation). Couchbase Lite's LogSinks is a process-global singleton that
  // retains the custom sink — and through it this module and its
  // ReactApplicationContext. If we don't remove it here, CBL keeps invoking the
  // callback against a dead bridge (events silently dropped) and the module leaks
  // across every reload. Only the custom sink references the bridge, so we leave
  // the console/file sinks alone to avoid disrupting persistent file logging.
  override fun invalidate() {
    isInvalidated = true
    try {
      LogSinksManager.setCustomSink(null, null, null)
    } catch (e: Throwable) {
      Log.e(TAG, "Failed to clear custom log sink on invalidate", e)
    }
    scope.cancel()
    logDispatcher.close()
    super.invalidate()
  }

  // Don't let JSI errors bubble out of the CBL callback thread.
  private fun emitCustomLogMessageSafe(payload: WritableMap) {
    if (isInvalidated) return
    try {
      emitCustomLogMessage(payload)
    } catch (e: Throwable) {
      Log.e(TAG, "emitCustomLogMessage FAILED: ${e.javaClass.simpleName} ${e.message}", e)
    }
  }

  companion object {
    private const val TAG = "CblLoggingModule"
    // Same-thread re-entrancy guard for the custom-log hot path (see Bug 8):
    // if emitting a log entry synchronously triggers more CBL logging on the same
    // thread, the nested entry is dropped to avoid a feedback loop.
    private val emittingGuard = ThreadLocal.withInitial { false }
  }

  override fun database_SetLogLevel(
    domain: String,
    logLevel: Double,
    promise: Promise,
  ) {
    scope.launch {
      if (domain.isEmpty()) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", "Log domain must be provided")
        }
        return@launch
      }
      try {
        LoggingManager.setLogLevel(domain, logLevel.toInt())
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  // TODO: LoggingManager should skip maxSize/maxRotateCount when JS omits them (iOS does).
  override fun database_SetFileLoggingConfig(
    name: String,
    directory: String,
    logLevel: Double,
    maxSize: Double,
    maxRotateCount: Double,
    shouldUsePlainText: Boolean,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateDatabaseName(name, promise)) {
          return@launch
        }
        if (DataValidation.hasPathTraversal(directory)) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "DATABASE_ERROR",
              "Invalid log directory: parent-directory traversal ('..') is not allowed"
            )
          }
          return@launch
        }
        LoggingManager.setFileLoggingConfig(
          directory,
          logLevel.toInt(),
          maxSize.toLong(),
          maxRotateCount.toInt(),
          shouldUsePlainText,
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  // level -1 disables; empty domains on enable means ALL (not disable). See LogSinksManager.
  override fun logsinks_SetConsole(
    level: Double,
    domains: ReadableArray,
    promise: Promise,
  ) {
    scope.launch {
      try {
        val intLevel: Int? = if (level.toInt() == -1) null else level.toInt()
        val domainList: List<String>? = if (intLevel == null) {
          null
        } else {
          (0 until domains.size())
            .mapNotNull { i ->
              if (domains.getType(i) == com.facebook.react.bridge.ReadableType.String) {
                domains.getString(i)
              } else null
            }
        }
        LogSinksManager.setConsoleSink(intLevel, domainList)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LOGSINKS_ERROR", e.message)
        }
      }
    }
  }

  override fun logsinks_SetFile(
    level: Double,
    config: ReadableMap,
    promise: Promise,
  ) {
    scope.launch {
      try {
        val intLevel: Int? = if (level.toInt() == -1) null else level.toInt()
        val configMap: Map<String, Any>? =
          if (intLevel == null) null
          else config.toHashMap()
        val logDirectory = configMap?.get("directory") as? String
        if (logDirectory != null && DataValidation.hasPathTraversal(logDirectory)) {
          reactApplicationContext.runOnUiQueueThread {
            promise.reject(
              "LOGSINKS_ERROR",
              "Invalid log directory: parent-directory traversal ('..') is not allowed"
            )
          }
          return@launch
        }
        LogSinksManager.setFileSink(intLevel, configMap)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LOGSINKS_ERROR", e.message)
        }
      }
    }
  }

  // Same level/domain mapping as logsinks_SetConsole; token required when enabling.
  override fun logsinks_SetCustom(
    level: Double,
    domains: ReadableArray,
    token: String,
    promise: Promise,
  ) {
    val intLevel: Int? = if (level.toInt() == -1) null else level.toInt()

    if (intLevel != null && token.isEmpty()) {
      promise.reject(
        "LOGSINKS_ERROR",
        "Error: token must be provided when enabling a custom log sink",
      )
      return
    }

    scope.launch {
      try {
        val domainList: List<String>? = if (intLevel == null) {
          null
        } else {
          (0 until domains.size())
            .mapNotNull { i ->
              if (domains.getType(i) == com.facebook.react.bridge.ReadableType.String) {
                domains.getString(i)
              } else null
            }
        }
        val tokenValue: String? = if (token.isEmpty()) null else token

        val callback: ((LogLevel, LogDomain, String) -> Unit)? =
          if (intLevel != null && tokenValue != null) {
            cb@{ logLevel, logDomain, message ->
              if (emittingGuard.get() == true) return@cb
              emittingGuard.set(true)
              try {
                val eventData = Arguments.createMap().apply {
                  putString("token", tokenValue)
                  putInt("level", logLevel.ordinal)
                  putString("domain", LogSinksManager.logDomainToString(logDomain))
                  putString("message", message)
                }
                emitCustomLogMessageSafe(eventData)
              } finally {
                emittingGuard.set(false)
              }
            }
          } else null

        LogSinksManager.setCustomSink(intLevel, domainList, callback)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LOGSINKS_ERROR", e.message)
        }
      }
    }
  }

  override fun logging_WriteLog(
    level: Double,
    domain: String,
    message: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        LogSinksManager.writeLog(level.toInt(), domain, message)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("LOGSINKS_ERROR", e.message, e)
        }
      }
    }
  }
}
