package com.cblreactnative

import com.facebook.react.BaseReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfo
import com.facebook.react.module.model.ReactModuleInfoProvider

class CblReactnativePackage : BaseReactPackage() {

  override fun getModule(
    name: String,
    reactContext: ReactApplicationContext,
  ): NativeModule? = when (name) {
    NativeCblDatabaseSpec.NAME -> CblDatabaseModule(reactContext)
    NativeCblScopeSpec.NAME -> CblScopeModule(reactContext)
    NativeCblCollectionSpec.NAME -> CblCollectionModule(reactContext)
    NativeCblDocumentSpec.NAME -> CblDocumentModule(reactContext)
    NativeCblQuerySpec.NAME -> CblQueryModule(reactContext)
    NativeCblReplicatorSpec.NAME -> CblReplicatorModule(reactContext)
    NativeCblEngineSpec.NAME -> CblEngineModule(reactContext)
    NativeCblLoggingSpec.NAME -> CblLoggingModule(reactContext)
    else -> null
  }

  override fun getReactModuleInfoProvider(): ReactModuleInfoProvider =
    ReactModuleInfoProvider {
      mapOf(
        NativeCblDatabaseSpec.NAME to ReactModuleInfo(
          NativeCblDatabaseSpec.NAME,
          CblDatabaseModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblScopeSpec.NAME to ReactModuleInfo(
          NativeCblScopeSpec.NAME,
          CblScopeModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblCollectionSpec.NAME to ReactModuleInfo(
          NativeCblCollectionSpec.NAME,
          CblCollectionModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblDocumentSpec.NAME to ReactModuleInfo(
          NativeCblDocumentSpec.NAME,
          CblDocumentModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblQuerySpec.NAME to ReactModuleInfo(
          NativeCblQuerySpec.NAME,
          CblQueryModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblReplicatorSpec.NAME to ReactModuleInfo(
          NativeCblReplicatorSpec.NAME,
          CblReplicatorModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblEngineSpec.NAME to ReactModuleInfo(
          NativeCblEngineSpec.NAME,
          CblEngineModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
        NativeCblLoggingSpec.NAME to ReactModuleInfo(
          NativeCblLoggingSpec.NAME,
          CblLoggingModule::class.java.name,
          false,
          false,
          false,
          true,
        ),
      )
    }
}
