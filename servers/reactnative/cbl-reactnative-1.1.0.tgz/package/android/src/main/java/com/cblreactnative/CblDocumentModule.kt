package com.cblreactnative

import cbl.js.kotlin.CollectionManager
import com.couchbase.lite.ConcurrencyControl
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.WritableMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

@Suppress("FunctionName")
class CblDocumentModule(reactContext: ReactApplicationContext) :
  NativeCblDocumentSpec(reactContext) {

  // Module-lifecycle coroutine scope: cancelled in invalidate() so in-flight work doesn't
  // outlive a JS reload / bridge teardown (replaces GlobalScope, which had no lifecycle).
  private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

  init {
    CouchbaseLiteInitializer.ensureInit(reactContext)
  }

  override fun getName(): String = NAME

  override fun invalidate() {
    scope.cancel()
    super.invalidate()
  }

  private data class ConcurrencyParse(
    val isError: Boolean,
    val cc: ConcurrencyControl? = null,
  )

  // Same rules as iOS DataAdapter.adaptDocumentArgs (-9999 / 0 / 1 only).
  private fun parseConcurrencyControl(
    value: Double,
    promise: Promise,
  ): ConcurrencyParse {
    if (value == CONCURRENCY_CONTROL_SENTINEL) {
      return ConcurrencyParse(isError = false, cc = null)
    }
    if (value == 0.0) {
      return ConcurrencyParse(isError = false, cc = ConcurrencyControl.LAST_WRITE_WINS)
    }
    if (value == 1.0) {
      return ConcurrencyParse(isError = false, cc = ConcurrencyControl.FAIL_ON_CONFLICT)
    }
    reactApplicationContext.runOnUiQueueThread {
      promise.reject(
        "DOCUMENT_ERROR",
        "Error: concurrencyControlValue $value is not a valid ConcurrencyControl",
      )
    }
    return ConcurrencyParse(isError = true)
  }

  companion object {
    // -9999 = concurrencyControl omitted (Codegen param is non-nullable double).
    private const val CONCURRENCY_CONTROL_SENTINEL: Double = -9999.0
  }

  override fun collection_GetDocument(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch

        val doc = CollectionManager.getDocument(
          docId, collectionName, scopeName, databaseUniqueName
        )
        if (doc == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(Arguments.createMap())
          }
          return@launch
        }

        val documentJson = doc.toJSON()
        // Empty body still returns doc metadata (_id, _sequence, _revId).
        val documentMap: WritableMap = if (!documentJson.isNullOrEmpty()) {
          try {
            val parsed = JSONObject(documentJson)
            val map = DataAdapter.jsonObjectToMap(parsed)
            Arguments.makeNativeMap(map)
          } catch (e: Exception) {
            reactApplicationContext.runOnUiQueueThread {
              promise.reject("DOCUMENT_ERROR", "Failed to parse document JSON: ${e.message}")
            }
            return@launch
          }
        } else {
          Arguments.createMap()
        }
        val writableMap = Arguments.createMap()
        writableMap.putMap("_data", documentMap)
        writableMap.putString("_id", doc.id)
        writableMap.putDouble("_sequence", doc.sequence.toDouble())
        writableMap.putString("_revId", doc.revisionID ?: "")
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(writableMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_Save(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    document: String,
    blobs: String,
    concurrencyControlValue: Double,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch
        val parsed = parseConcurrencyControl(concurrencyControlValue, promise)
        if (parsed.isError) return@launch
        val result = CollectionManager.saveDocument(
          docId,
          document,
          blobs,
          parsed.cc,
          collectionName,
          scopeName,
          databaseUniqueName,
        )
        val writableMap = Arguments.createMap()
        writableMap.putString("_id", result._id)
        if (result._concurrencyControl != null) {
          writableMap.putBoolean("concurrencyControlResult", result._concurrencyControl)
        } else {
          writableMap.putNull("concurrencyControlResult")
        }
        writableMap.putString("_revId", result._revId)
        // _sequence is a 64-bit Long; forward as Double (the RN bridge has no 64-bit int)
        // to avoid truncation and to match the get-path, which also uses putDouble.
        writableMap.putDouble("_sequence", result._sequence.toDouble())
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(writableMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_DeleteDocument(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    concurrencyControl: Double,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch
        val parsed = parseConcurrencyControl(concurrencyControl, promise)
        if (parsed.isError) return@launch

        val result = if (parsed.cc == null) {
          CollectionManager.deleteDocument(
            docId, collectionName, scopeName, databaseUniqueName
          )
        } else {
          CollectionManager.deleteDocument(
            docId, collectionName, scopeName, databaseUniqueName, parsed.cc
          )
        }
        val writableMap = Arguments.createMap()
        writableMap.putBoolean("concurrencyControlResult", result)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(writableMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_PurgeDocument(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch
        CollectionManager.purgeDocument(
          docId, collectionName, scopeName, databaseUniqueName
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetDocumentExpiration(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch
        val expiration = CollectionManager.getDocumentExpiration(
          docId, collectionName, scopeName, databaseUniqueName
        )
        if (expiration == null) {
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(null)
          }
        } else {
          val map = Arguments.createMap()
          map.putString("date", DataAdapter.dateToISOString(expiration))
          reactApplicationContext.runOnUiQueueThread {
            promise.resolve(map)
          }
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_SetDocumentExpiration(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    docId: String,
    expiration: String?,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateDocumentId(docId, promise)
        ) return@launch
        CollectionManager.setDocumentExpiration(
          docId, expiration, collectionName, scopeName, databaseUniqueName
        )
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(null)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }

  override fun collection_GetBlobContent(
    databaseUniqueName: String,
    collectionName: String,
    scopeName: String,
    documentId: String,
    key: String,
    promise: Promise,
  ) {
    scope.launch {
      try {
        if (!DataValidation.validateCollection(
            collectionName, scopeName, databaseUniqueName, promise
          ) || !DataValidation.validateNonEmptyString(
            documentId, "docId", promise, "DOCUMENT_ERROR"
          ) || !DataValidation.validateNonEmptyString(
            key, "key", promise, "DOCUMENT_ERROR"
          )
        ) return@launch
        val writableArray = Arguments.createArray()
        val writableMap = Arguments.createMap()
        val content = CollectionManager.getBlobContent(
          key, documentId, collectionName, scopeName, databaseUniqueName
        )
        if (content != null && content.isNotEmpty()) {
          val intArray = content.map { it.toInt() and 0xFF }
          intArray.forEach { writableArray.pushInt(it) }
        }
        writableMap.putArray("data", writableArray)
        reactApplicationContext.runOnUiQueueThread {
          promise.resolve(writableMap)
        }
      } catch (e: Throwable) {
        reactApplicationContext.runOnUiQueueThread {
          promise.reject("DATABASE_ERROR", e.message)
        }
      }
    }
  }
}
