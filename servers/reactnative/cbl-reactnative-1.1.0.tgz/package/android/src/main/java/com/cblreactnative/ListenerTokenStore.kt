package com.cblreactnative

import android.util.Log
import com.couchbase.lite.ListenerToken
import java.util.concurrent.ConcurrentHashMap

enum class ChangeListenerType {
  COLLECTION,
  COLLECTION_DOCUMENT,
  QUERY,
  REPLICATOR,
  REPLICATOR_DOCUMENT,
}

data class ChangeListenerRecord(
  val nativeListenerToken: ListenerToken,
  val listenerType: ChangeListenerType,
  val replicatorId: String? = null,
  // RN unique database handle for collection / collection-document listeners, so they can
  // be swept when their owning database is closed or deleted. null for query (tracked via
  // QueryManager) and replicator (tracked via replicatorId) listeners.
  val databaseUniqueName: String? = null,
)

// Shared registry for TurboModules and legacy listenerToken_Remove.
internal object ListenerTokenStore {

  private const val TAG = "ListenerTokenStore"

  private val store = ConcurrentHashMap<String, ChangeListenerRecord>()

  fun add(token: String, record: ChangeListenerRecord) {
    // ConcurrentHashMap.put atomically returns the prior entry. If a record already
    // existed for this token, remove its native listener so overwriting the map entry
    // doesn't orphan the previous CBL ListenerToken.
    val previous = store.put(token, record)
    if (previous != null && previous !== record) {
      try {
        previous.nativeListenerToken.remove()
      } catch (e: Throwable) {
        Log.w(TAG, "Failed to remove orphaned listener for token $token: ${e.message}")
      }
    }
  }

  fun remove(token: String): ChangeListenerRecord? = store.remove(token)

  fun get(token: String): ChangeListenerRecord? = store[token]

  fun removeAllForReplicator(replicatorId: String): List<ChangeListenerRecord> {
    val matchedKeys = store.entries
      .filter { it.value.replicatorId == replicatorId }
      .map { it.key }
    return matchedKeys.mapNotNull { store.remove(it) }
  }

  fun removeAllForDatabase(databaseUniqueName: String): List<ChangeListenerRecord> {
    val matchedKeys = store.entries
      .filter { it.value.databaseUniqueName == databaseUniqueName }
      .map { it.key }
    return matchedKeys.mapNotNull { store.remove(it) }
  }
}
