import { Platform } from 'react-native';
import {
  CollectionChangeListenerArgs,
  ICoreEngine,
  ListenerCallback,
  CollectionArgs,
  CollectionCreateIndexArgs,
  CollectionDeleteDocumentArgs,
  CollectionDeleteIndexArgs,
  CollectionDocumentExpirationArgs,
  CollectionDocumentGetBlobContentArgs,
  CollectionDocumentSaveResult,
  CollectionGetDocumentArgs,
  CollectionPurgeDocumentArgs,
  CollectionSaveStringArgs,
  CollectionsResult,
  DatabaseArgs,
  DatabaseCopyArgs,
  DatabaseCreateIndexArgs,
  DatabaseDeleteDocumentArgs,
  DatabaseDeleteIndexArgs,
  DatabaseEncryptionKeyArgs,
  DatabaseExistsArgs,
  DatabaseGetDocumentArgs,
  DatabaseOpenArgs,
  DatabasePerformMaintenanceArgs,
  DatabasePurgeDocumentArgs,
  DatabaseSaveArgs,
  DatabaseSetFileLoggingConfigArgs,
  DatabaseSetLogLevelArgs,
  DocumentChangeListenerArgs,
  DocumentExpirationResult,
  DocumentResult,
  QueryChangeListenerArgs,
  QueryExecuteArgs,
  QueryRemoveChangeListenerArgs,
  ReplicationChangeListenerArgs,
  ReplicatorArgs,
  ReplicatorCollectionArgs,
  ReplicatorCreateArgs,
  ReplicatorDocumentPendingArgs,
  ScopeArgs,
  ScopesResult,
  NativeCollectionResult,
  NativeScopeResult,
  DocumentGetBlobContentArgs,
  URLEndpointListenerCreateArgs,
  URLEndpointListenerArgs,
  URLEndpointListenerTLSIdentityArgs,
  URLEndpointListenerStatus,
} from './cblite-js/cblite/core-types';

import { EngineLocator } from './cblite-js/cblite/src/engine-locator';
import { Result } from './cblite-js/cblite/src/result';
import { ReplicatorStatus } from './cblite-js/cblite/src/replicator-status';
import { ConcurrencyControl } from './cblite-js/cblite/src/concurrency-control';

import { LogLevel, LogDomain } from './cblite-js/cblite/src/log-sinks-enums';
import type {
  LogSinksSetConsoleArgs,
  LogSinksSetFileArgs,
  LogSinksSetCustomArgs,
} from './cblite-js/cblite/src/log-sinks-types';

import uuid from 'react-native-uuid';

import NativeCblDatabase from './NativeCblDatabase';
import NativeCblCollection from './NativeCblCollection';
import NativeCblDocument from './NativeCblDocument';
import NativeCblQuery from './NativeCblQuery';
import NativeCblReplicator from './NativeCblReplicator';
import NativeCblScope from './NativeCblScope';
import NativeCblLogging from './NativeCblLogging';
import NativeCblEngine from './NativeCblEngine';
import type {
  CollectionChangeEvent,
  CollectionDocumentChangeEvent,
} from './NativeCblCollection';
import type { CustomLogMessageEvent } from './NativeCblLogging';
import type { QueryChangeEvent } from './NativeCblQuery';
import type {
  ReplicatorDocumentChangeEvent,
  ReplicatorStatusChangeEvent,
} from './NativeCblReplicator';

// All the event names that can be emitted by the native layer (iOS/Android).
// Using `as const` makes TypeScript treat these as exact string literals rather
// than the generic `string` type, which lets us catch typos at compile time.
const ENGINE_EVENTS = {
  replicatorStatusChange: 'replicatorStatusChange', // Fired when a replicator's status changes (idle, busy, stopped, etc.)
  replicatorDocumentChange: 'replicatorDocumentChange', // Fired when a specific document is pushed/pulled by a replicator
  collectionChange: 'collectionChange', // Fired when documents are added/removed from a collection
  collectionDocumentChange: 'collectionDocumentChange', // Fired when a specific document inside a collection changes
  queryChange: 'queryChange', // Fired when the results of a live query change
  customLogMessage: 'customLogMessage', // Fired when the native layer emits a log entry to a custom log sink
} as const;

// A union type of all valid event name strings (derived from ENGINE_EVENTS above).
// For example: "replicatorStatusChange" | "collectionChange" | ...
type EngineEventName = (typeof ENGINE_EVENTS)[keyof typeof ENGINE_EVENTS];

// The shape of an active event subscription returned by the native event system.
// Calling .remove() tears down that specific subscription so we stop receiving events.
type NativeEventSubscription = { remove(): void };

// A union of all possible event payload shapes. A payload is the data object
// that arrives with each event (e.g. the new replicator status, the changed document, etc.).
type EngineEventPayload =
  | ReplicatorStatusChangeEvent
  | ReplicatorDocumentChangeEvent
  | CollectionChangeEvent
  | CollectionDocumentChangeEvent
  | QueryChangeEvent
  | CustomLogMessageEvent;

// Extracts the argument types of ListenerCallback so we can spread them when
// calling a stored callback: callback(...args) instead of callback(data, error).
type ListenerCallbackArgs = Parameters<ListenerCallback>;

// Prepended to wrapper-originated log lines so they are distinguishable from
// native CBL output in shared file/custom sinks. NOT applied to the public
// LogSinks.write path (logging_WriteLog), which carries caller-supplied text.
const RN_LOG_PREFIX = 'RN ';

function withRnPrefix(message: string): string {
  return message.startsWith(RN_LOG_PREFIX)
    ? message
    : `${RN_LOG_PREFIX}${message}`;
}

export class CblReactNativeEngine implements ICoreEngine {
  _defaultCollectionName = '_default';
  _defaultScopeName = '_default';
  debugConsole = false;
  platform = Platform.OS;

  // ─── Per-token maps (one entry per registered listener) ────────────────────
  //
  // When user code registers a listener (e.g. "notify me when this replicator
  // changes status"), the native layer hands back a unique string called a
  // *token*. Every map below is keyed by that same token, so when a native
  // event arrives we can look up the right callback instantly, and when the
  // user removes a listener we can clean up all entries in one pass
  // (see _removeListenerTokenAfterNativeSuccess).

  // token → callback for replicator status-change events
  private _replicatorChangeListeners: Map<string, ListenerCallback> = new Map();

  // token → callback for replicator document-change events
  private _replicatorDocumentChangeListeners: Map<string, ListenerCallback> =
    new Map();

  // token → callback for collection-level change events
  private _collectionChangeListeners: Map<string, ListenerCallback> = new Map();

  // token → callback for individual document changes inside a collection
  private _collectionDocumentChangeListeners: Map<string, ListenerCallback> =
    new Map();

  // token → callback for live-query result changes
  private _queryChangeListeners: Map<string, ListenerCallback> = new Map();

  // token → NativeEventSubscription handle returned by the event bus.
  // Keeping this allows us to call .remove() on a per-token basis when
  // the user stops listening.
  private _emitterSubscriptions: Map<string, NativeEventSubscription> =
    new Map();

  // ─── Shared (singleton) native subscriptions ────────────────────────────────
  //
  // All user callbacks for the same event type share ONE underlying native
  // subscription.  For example, even if 10 different replicators are active,
  // we only register once with the native "replicatorStatusChange" emitter.
  // When an event fires, we fan it out to the right per-token callback
  // ourselves (see _dispatchTokenEvent).
  //
  // eventName → the single active NativeEventSubscription for that event
  private _sharedEventSubscriptions: Map<
    EngineEventName,
    NativeEventSubscription
  > = new Map();

  // ─── Custom log sink ─────────────────────────────────────────────────────────
  //
  // The custom log sink has its own pair of fields because it is the only event
  // type that is subscribed eagerly in the constructor (before any user code
  // registers a log callback) and that supports multiple simultaneous callbacks
  // under different tokens.

  // The single shared subscription for custom log messages (set up in the
  // constructor and held here so it is never garbage-collected).
  private _customLogSubscription?: NativeEventSubscription;
  // token → custom log callback. Multiple custom sinks can be active at once,
  // each identified by its own token.
  private customLogCallbacksMap: Map<
    string,
    (level: LogLevel, domain: LogDomain, message: string) => void
  > = new Map();

  // True only while a custom-sink callback is being dispatched (see constructor).
  // Used to break the CBL→JS→CBL logging feedback loop.
  private _isDispatchingCustomLogCallback = false;

  // ─── Internal-log forwarding state (§3.5) ─────────────────────────────────
  // The minimum (most permissive) level of each sink that should receive
  // RN-forwarded logs, or null when that sink is disabled. Console-only logging
  // does NOT trigger forwarding (it adds a bridge round-trip with no persistent
  // or user-observable benefit), so only file + custom are tracked here. State
  // is updated by the JS-visible logging chokepoints (logsinks_SetFile,
  // logsinks_SetCustom, database_SetFileLoggingConfig) AFTER native confirms.
  private _fileSinkLevel: number | null = null;
  private _customSinkLevel: number | null = null;

  // True when at least one forwarded sink (file or custom) is enabled. While
  // false, debugLog never crosses the bridge — keeping the hot path cheap.
  private get forwardLogsToSinks(): boolean {
    return this._fileSinkLevel !== null || this._customSinkLevel !== null;
  }

  // The most permissive enabled forwarded-sink level. A line below this is
  // dropped JS-side so high-frequency DEBUG lines never cross the bridge unless
  // a configured sink could actually accept them (native filters again too).
  private get _minForwardLevel(): number {
    const levels = [this._fileSinkLevel, this._customSinkLevel].filter(
      (l): l is number => l !== null
    );
    // No forwarded sink → an unreachable threshold so nothing forwards.
    return levels.length === 0 ? LogLevel.NONE : Math.min(...levels);
  }

  constructor() {
    // Register this engine instance with EngineLocator so the rest of the
    // cblite-js library can find it without needing a direct import.
    EngineLocator.registerEngine(EngineLocator.key, this);

    // Subscribe to custom log events immediately so the sink is ready before any
    // logsinks_SetCustom call fires an event.
    //
    // When a log event arrives from the native layer it carries a `token` that
    // identifies *which* custom log sink the user registered.  We look up the
    // matching callback in customLogCallbacksMap and forward the message.
    this._customLogSubscription = this._ensureEventSubscription(
      ENGINE_EVENTS.customLogMessage,
      (data) => {
        const logEvent = data as CustomLogMessageEvent;
        const callback = this.customLogCallbacksMap.get(logEvent.token);
        if (callback) {
          // Recursion / feedback guard: while a custom-sink callback is running
          // we are *inside* CBL's log output. A synchronous LogSinks.write (or a
          // forwarded internal debugLog) made from here would loop the line back
          // into CBL logging, so logging_WriteLog and writeInternalLog drop/reject
          // while this flag is set. It cannot catch delayed (setTimeout/promise)
          // writes — those are a documented caller prohibition.
          this._isDispatchingCustomLogCallback = true;
          try {
            callback(
              logEvent.level as LogLevel,
              logEvent.domain as LogDomain,
              logEvent.message
            );
          } finally {
            this._isDispatchingCustomLogCallback = false;
          }
        }
      }
    );
  }

  // The single chokepoint for the wrapper's own diagnostics (§3.5).
  //
  // Behaviour:
  //  - When `debugConsole` is enabled, prints the (verbose) `message` to the JS
  //    console exactly as before — no behavioural change for local debugging.
  //  - When a forwarded sink (file/custom) is enabled, forwards a *sanitized*
  //    `forwardedMessage` into the CBL logging pipeline via logging_WriteLog so
  //    the wrapper's logs land in the file/custom sink like native SDK logs.
  //
  // `domain` and `level` are passed explicitly by each call site (never parsed
  // from the message) so classification is deterministic. Forwarding is
  // fire-and-forget: a logging failure must never reject a real operation.
  //
  // REDACTION: the console `message` may contain payload-heavy data (document
  // bodies, encryption keys, blobs, raw errors). Persistent/custom forwarding
  // must use `forwardedMessage`, which defaults to `message` — so call sites
  // that handle sensitive data MUST pass a sanitized `forwardedMessage`.
  private debugLog(
    message: string,
    domain: LogDomain = LogDomain.DATABASE,
    level: LogLevel = LogLevel.DEBUG,
    forwardedMessage: string = message
  ) {
    if (this.debugConsole) {
      console.log(withRnPrefix(message));
    }
    this.forwardInternalLog(level, domain, withRnPrefix(forwardedMessage));
  }

  private errorLog(
    message: string,
    domain: LogDomain = LogDomain.DATABASE,
    forwardedMessage: string = message
  ) {
    this.debugLog(message, domain, LogLevel.ERROR, forwardedMessage);
  }

  // ─── Operation-log helpers ─────────────────────────────────────────────────
  //
  // Canonical builders for the wrapper's own start / success / error / warning
  // diagnostics. They centralize the `::DEBUG::` / `::WARNING::` / `::ERROR::`
  // prefixes and the ` completed` / ` failed` / ` rejected` wording so it can't
  // drift between call sites, and they delegate to the debugLog/errorLog
  // chokepoint (so the fire-and-forget, recursion-guard, level-filter, and
  // forward-gating behavior is unchanged).
  //
  // SAFE-BY-DEFAULT: `forwardedDetail` defaults to '' (forward NO free-form
  // detail) and is NEVER derived from `consoleDetail`. A call site that forgets
  // to pass a sanitized detail can therefore only ever forward the bare
  // `::DEBUG:: <method>` / `::ERROR:: <method> failed` / `::WARNING:: <method>
  // rejected: <reason>` line — never a path, key, query string, credential, or
  // document body. The rich `consoleDetail` is printed to the JS console only
  // (gated by `debugConsole`) and never leaves the device. Call sites handling
  // sensitive data MUST pass an explicit, scrubbed `forwardedDetail`.

  private logOpStart(
    method: string,
    domain: LogDomain = LogDomain.DATABASE,
    consoleDetail = '',
    forwardedDetail = '',
    level: LogLevel = LogLevel.DEBUG
  ) {
    const consoleMessage = consoleDetail
      ? `::DEBUG:: ${method}: ${consoleDetail}`
      : `::DEBUG:: ${method}`;
    const forwardedMessage = forwardedDetail
      ? `::DEBUG:: ${method}(${forwardedDetail})`
      : `::DEBUG:: ${method}`;
    this.debugLog(consoleMessage, domain, level, forwardedMessage);
  }

  private logOpDone(
    method: string,
    domain: LogDomain = LogDomain.DATABASE,
    consoleDetail = '',
    forwardedDetail = '',
    level: LogLevel = LogLevel.DEBUG
  ) {
    const consoleMessage = consoleDetail
      ? `::DEBUG:: ${method} completed with result: ${consoleDetail}`
      : `::DEBUG:: ${method} completed`;
    const forwardedMessage = forwardedDetail
      ? `::DEBUG:: ${method} completed (${forwardedDetail})`
      : `::DEBUG:: ${method} completed`;
    this.debugLog(consoleMessage, domain, level, forwardedMessage);
  }

  // Canonical error line. The raw error is printed to console only; the
  // forwarded line uses a fixed sanitized summary (never the raw error).
  private logOpError(
    method: string,
    rawError: unknown,
    domain: LogDomain = LogDomain.DATABASE,
    forwardedDetail = ''
  ) {
    const forwardedMessage = forwardedDetail
      ? `::ERROR:: ${method} failed (${forwardedDetail})`
      : `::ERROR:: ${method} failed`;
    this.errorLog(
      `::ERROR:: ${method} Error: ${rawError}`,
      domain,
      forwardedMessage
    );
  }

  // Canonical WARNING line for caller-misuse / no-op conditions (e.g. pre-native
  // duplicate-token or "no listener found" validation failures). Separate from
  // logOpError because warnings must carry a `::WARNING::` prefix AND forward at
  // WARNING level — reusing logOpError would emit a WARNING-level line under an
  // `::ERROR::` prefix.
  private logOpWarn(
    method: string,
    reason: string,
    domain: LogDomain = LogDomain.DATABASE,
    forwardedDetail = ''
  ) {
    const consoleMessage = `::WARNING:: ${method} rejected: ${reason}`;
    const forwardedMessage = forwardedDetail
      ? `::WARNING:: ${method} rejected: ${reason} (${forwardedDetail})`
      : `::WARNING:: ${method} rejected: ${reason}`;
    this.debugLog(consoleMessage, domain, LogLevel.WARNING, forwardedMessage);
  }

  // Fire-and-forget forwarding of an already-sanitized internal log line into
  // the CBL logging pipeline. Gated on `forwardLogsToSinks` (so no bridge work
  // when no forwarded sink is configured) and on the per-sink minimum level.
  private forwardInternalLog(
    level: LogLevel,
    domain: LogDomain,
    message: string
  ) {
    if (!this.forwardLogsToSinks) return;
    // Don't bounce CBL's own log output back into CBL logging.
    if (this._isDispatchingCustomLogCallback) return;
    if ((level as number) < this._minForwardLevel) return;
    // Never let a logging failure reject the underlying DB/query/replicator op.
    void NativeCblLogging.logging_WriteLog(
      Number(level),
      String(domain),
      message
    ).catch(() => {});
  }

  // Ensures there is exactly ONE native subscription for a given event type.
  //
  // Think of this like a lazy singleton: if we have already subscribed to
  // "replicatorStatusChange" at the native level, we reuse that subscription
  // instead of creating a second one.  This keeps the native event bus clean.
  private _ensureEventSubscription(
    eventName: EngineEventName,
    handler: (data: EngineEventPayload) => void
  ): NativeEventSubscription {
    const existingSubscription = this._sharedEventSubscriptions.get(eventName);
    if (existingSubscription) {
      // Already subscribed — return the existing handle.
      return existingSubscription;
    }

    // First subscriber for this event type: create the native subscription and
    // cache it so future callers reuse it.
    const subscription = this._subscribeToEvent(eventName, handler);
    this._sharedEventSubscriptions.set(eventName, subscription);
    return subscription;
  }

  // Tears down the shared native subscription for an event type, but only if
  // there are no remaining per-token listeners that still care about it.
  //
  // This is called after a token is removed.  If `listeners` is now empty it
  // means nobody is listening any more, so we can unsubscribe from the native
  // layer entirely and free the resource.
  private _removeEventSubscriptionIfIdle(
    eventName: EngineEventName,
    listeners: Map<string, ListenerCallback>
  ): void {
    if (listeners.size > 0) {
      // At least one listener is still active — keep the native subscription alive.
      return;
    }

    // No listeners left — remove the shared native subscription.
    this._sharedEventSubscriptions.get(eventName)?.remove();
    this._sharedEventSubscriptions.delete(eventName);
  }

  // Receives a raw native event and routes it to the correct per-token callback.
  //
  // Every event payload carries a `token` that identifies which specific
  // listener (replicator, collection, query, …) the event is meant for.
  // This method looks up the token in the provided `listeners` Map and invokes
  // the stored callback with the correctly shaped arguments.
  //
  // `selectCallbackArgs` is a small adapter function (provided by each caller)
  // that knows how to unpack the raw payload into the [data, error] tuple that
  // ListenerCallback expects.
  private _dispatchTokenEvent(
    eventName: EngineEventName,
    listeners: Map<string, ListenerCallback>,
    payload: EngineEventPayload,
    selectCallbackArgs: (payload: EngineEventPayload) => ListenerCallbackArgs
  ): void {
    const token = payload.token;
    if (!token) {
      // A missing token means something went wrong on the native side.
      // eventName is non-sensitive; forward an explicit sanitized line.
      this.errorLog(
        `::ERROR:: Received ${eventName} event without a token`,
        LogDomain.LISTENER,
        `::ERROR:: Received ${eventName} event without a token`
      );
      return;
    }

    const callback = listeners.get(token);
    if (!callback) {
      // The token doesn't match any active listener.  This can happen when an
      // event is in-flight while the listener is being removed — safe to ignore.
      // eventName + token are non-sensitive; forward an explicit sanitized line.
      this.debugLog(
        `::DEBUG:: Ignoring ${eventName} event for stale token: ${token}`,
        LogDomain.LISTENER,
        LogLevel.DEBUG,
        `::DEBUG:: Ignoring ${eventName} event for stale token: ${token}`
      );
      return;
    }

    // Unpack the payload into the expected callback arguments and invoke the
    // user-supplied callback.
    //
    // The callback MUST NOT be allowed to throw out of this method. In the New
    // Architecture (Bridgeless) event system this method runs synchronously on
    // the TurboModule event-emitter dispatch path. The cblite-js listener
    // bridges (replicator.ts, collection.ts, query.ts, …) deliberately throw on
    // the error arg (`if (err) { throw err; }`) and on malformed payloads. If
    // that throw escaped here it would become an UNHANDLED exception in the
    // event-dispatch path — a red-box / app crash on exactly the events apps
    // care most about (replication auth/network failures, etc.) — rather than a
    // recoverable listener error. We therefore contain any throw and route it to
    // the safe error log channel instead of letting it propagate.
    const [data, error] = selectCallbackArgs(payload);
    try {
      callback(data, error);
    } catch (callbackError) {
      // eventName + token are non-sensitive. The thrown error may carry
      // payload-derived detail, so it is printed to the JS console only (gated
      // by debugConsole) and is NEVER forwarded to persistent/custom sinks.
      const detail =
        callbackError instanceof Error
          ? callbackError.message
          : String(callbackError);
      this.errorLog(
        `::ERROR:: ${eventName} listener (token: ${token}) threw during dispatch: ${detail}`,
        LogDomain.LISTENER,
        `::ERROR:: ${eventName} listener (token: ${token}) threw during dispatch`
      );
    }
  }

  // Removes a listener token from all tracking structures, but only after the
  // native layer has successfully deregistered it.
  //
  // The sequence is:
  //   1. Tell native to stop sending events for this token (await nativeRemove).
  //   2. Remove the per-token NativeEventSubscription handle from _emitterSubscriptions.
  //   3. Delete the token from every listener Map that was passed in.
  //   4. Call the optional afterRemove hook (e.g. to tear down the shared
  //      subscription if no listeners remain).
  //
  // Doing native cleanup first prevents a race where an event arrives between
  // the JS cleanup and the native deregistration.
  private async _removeListenerTokenAfterNativeSuccess(
    token: string,
    nativeRemove: () => Promise<void>,
    listenerMaps: Array<Map<string, ListenerCallback>>,
    afterRemove?: () => void
  ): Promise<void> {
    await nativeRemove();

    this._emitterSubscriptions.get(token)?.remove();
    this._emitterSubscriptions.delete(token);
    listenerMaps.forEach((listeners) => listeners.delete(token));
    afterRemove?.();
  }

  // Typed TurboModule emitters on both platforms (customLogMessage included).
  // `as any`: codegen declares EventEmitter<T> as a property, not subscribe().
  private _subscribeToEvent(
    eventName: EngineEventName,
    callback: (data: EngineEventPayload) => void
  ): NativeEventSubscription {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const collection = NativeCblCollection as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const replicator = NativeCblReplicator as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const query = NativeCblQuery as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const logging = NativeCblLogging as any;
    switch (eventName) {
      case ENGINE_EVENTS.collectionChange:
        return collection.collectionChange(callback);
      case ENGINE_EVENTS.collectionDocumentChange:
        return collection.collectionDocumentChange(callback);
      case ENGINE_EVENTS.replicatorStatusChange:
        return replicator.replicatorStatusChange(callback);
      case ENGINE_EVENTS.replicatorDocumentChange:
        return replicator.replicatorDocumentChange(callback);
      case ENGINE_EVENTS.queryChange:
        return query.queryChange(callback);
      case ENGINE_EVENTS.customLogMessage:
        return logging.customLogMessage(callback);
      default:
        throw new Error(`Unknown event: ${eventName}`);
    }
  }

  // Public entry point for subscribing to a named engine event.
  //
  // Unlike _ensureEventSubscription (which is for internal shared subscriptions),
  // this method creates a *fresh* subscription every time it is called.  It is
  // used in contexts where the caller manages its own subscription lifetime
  // (e.g. a component that wants to receive events and clean up on unmount).
  //
  // Returns a NativeEventSubscription whose .remove() method the caller should
  // invoke when it no longer wants events.
  startListeningEvents = (
    event: EngineEventName,
    callback: (data: EngineEventPayload) => void
  ): NativeEventSubscription => {
    this.debugLog(
      `::DEBUG:: Registering listener for event: ${event}`,
      LogDomain.LISTENER
    );
    return this._subscribeToEvent(event, (data) => {
      // Console keeps the full payload for local debugging; the forwarded line
      // omits the event data (it may carry document/replication payloads).
      this.debugLog(
        `::DEBUG:: Received event: ${event} with data: ${JSON.stringify(data)}`,
        LogDomain.LISTENER,
        LogLevel.DEBUG,
        `::DEBUG:: Received event: ${event}`
      );
      callback(data);
    });
  };

  // ─── NativeCblDatabase ────────────────────────────────────────────────────

  database_Open(
    args: DatabaseOpenArgs
  ): Promise<{ databaseUniqueName: string }> {
    // Database can be constructed with no configuration — fall back to null on each field.
    const directory = args.config?.directory ?? null;
    const encryptionKey = args.config?.encryptionKey ?? null;
    // Console keeps the raw directory/key for local debugging; the forwarded
    // line never persists the directory path or the encryption key.
    this.logOpStart(
      'database_Open',
      LogDomain.DATABASE,
      `name=${args.databaseName} directory=${directory} encrypted=${encryptionKey != null}`,
      `name=${args.databaseName}, directory=<redacted>, encrypted=${encryptionKey != null}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_Open(
        args.databaseName,
        directory,
        encryptionKey
      ).then(
        (databaseUniqueName) => {
          this.logOpDone(
            'database_Open',
            LogDomain.DATABASE,
            '',
            `name=${args.databaseName}`
          );
          resolve(
            databaseUniqueName as unknown as { databaseUniqueName: string }
          );
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_Open',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseName}`
          );
          reject(error);
        }
      );
    });
  }

  database_Close(args: DatabaseArgs): Promise<void> {
    this.logOpStart(
      'database_Close',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_Close(args.databaseUniqueName).then(
        () => {
          this.logOpDone(
            'database_Close',
            LogDomain.DATABASE,
            '',
            `name=${args.databaseUniqueName}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_Close',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  database_Delete(args: DatabaseArgs): Promise<void> {
    this.logOpStart(
      'database_Delete',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_Delete(args.databaseUniqueName).then(
        () => {
          this.logOpDone(
            'database_Delete',
            LogDomain.DATABASE,
            '',
            `name=${args.databaseUniqueName}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_Delete',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  database_DeleteWithPath(args: DatabaseExistsArgs): Promise<void> {
    // Console keeps the directory for local debugging; the forwarded line redacts it.
    this.logOpStart(
      'database_DeleteWithPath',
      LogDomain.DATABASE,
      `name=${args.databaseName} directory=${args.directory}`,
      `name=${args.databaseName}, directory=<redacted>`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_DeleteWithPath(
        args.directory,
        args.databaseName
      ).then(
        () => {
          this.logOpDone(
            'database_DeleteWithPath',
            LogDomain.DATABASE,
            '',
            `name=${args.databaseName}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_DeleteWithPath',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseName}`
          );
          reject(error);
        }
      );
    });
  }

  database_Copy(args: DatabaseCopyArgs): Promise<void> {
    const encrypted = (args.config?.encryptionKey ?? null) != null;
    // Console keeps the source path for local debugging; the forwarded line
    // never persists the source path or the encryption key.
    this.logOpStart(
      'database_Copy',
      LogDomain.DATABASE,
      `newName=${args.newDatabaseName} fromPath=${args.path} directory=${args.config?.directory ?? null}`,
      `newName=${args.newDatabaseName}, fromPath=<redacted>, encrypted=${encrypted}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_Copy(
        args.path,
        args.newDatabaseName,
        args.config?.directory ?? null,
        args.config?.encryptionKey ?? null
      ).then(
        () => {
          this.logOpDone(
            'database_Copy',
            LogDomain.DATABASE,
            '',
            `newName=${args.newDatabaseName}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_Copy',
            error,
            LogDomain.DATABASE,
            `newName=${args.newDatabaseName}`
          );
          reject(error);
        }
      );
    });
  }

  database_Exists(args: DatabaseExistsArgs): Promise<{ exists: boolean }> {
    // Console keeps the directory for local debugging; the forwarded line
    // never persists the directory path.
    this.logOpStart(
      'database_Exists',
      LogDomain.DATABASE,
      `${args.databaseName} ${args.directory}`,
      `name=${args.databaseName}, directory=<redacted>`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_Exists(args.databaseName, args.directory).then(
        (result: boolean) => {
          this.logOpDone(
            'database_Exists',
            LogDomain.DATABASE,
            `${result}`,
            `name=${args.databaseName}, exists=${result}`
          );
          resolve({ exists: result });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_Exists',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseName}`
          );
          reject(error);
        }
      );
    });
  }

  database_GetPath(args: DatabaseArgs): Promise<{ path: string }> {
    this.logOpStart(
      'database_GetPath',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_GetPath(args.databaseUniqueName).then(
        (result: string) => {
          // Console keeps the resolved path; the forwarded line omits it.
          this.logOpDone(
            'database_GetPath',
            LogDomain.DATABASE,
            result,
            `name=${args.databaseUniqueName}`
          );
          resolve({ path: result });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_GetPath',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  database_PerformMaintenance(
    args: DatabasePerformMaintenanceArgs
  ): Promise<void> {
    const numValue = args.maintenanceType.valueOf();
    this.logOpStart(
      'database_PerformMaintenance',
      LogDomain.DATABASE,
      `${args.databaseUniqueName} ${numValue}`,
      `name=${args.databaseUniqueName}, type=${numValue}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_PerformMaintenance(
        args.databaseUniqueName,
        numValue
      ).then(
        () => {
          this.logOpDone(
            'database_PerformMaintenance',
            LogDomain.DATABASE,
            '',
            `type=${numValue}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_PerformMaintenance',
            error,
            LogDomain.DATABASE,
            `type=${numValue}`
          );
          reject(error);
        }
      );
    });
  }

  database_ChangeEncryptionKey(args: DatabaseEncryptionKeyArgs): Promise<void> {
    const newKeyPresent = (args.newKey ?? null) != null;
    // The encryption key is NEVER logged (console or forwarded). Only a boolean
    // indicating whether a new key was supplied is recorded.
    this.logOpStart(
      'database_ChangeEncryptionKey',
      LogDomain.DATABASE,
      `name=${args.databaseUniqueName} newKeyPresent=${newKeyPresent}`,
      `name=${args.databaseUniqueName}, newKeyPresent=${newKeyPresent}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblDatabase.database_ChangeEncryptionKey(
        args.databaseUniqueName,
        args.newKey
      ).then(
        () => {
          this.logOpDone(
            'database_ChangeEncryptionKey',
            LogDomain.DATABASE,
            '',
            `name=${args.databaseUniqueName}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'database_ChangeEncryptionKey',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  /**
   * @deprecated This function will be removed in future versions. Use collection_CreateIndex instead.
   */
  database_CreateIndex(args: DatabaseCreateIndexArgs): Promise<void> {
    const colArgs: CollectionCreateIndexArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      indexName: args.indexName,
      index: args.index,
    };
    return this.collection_CreateIndex(colArgs);
  }

  /**
   * @deprecated This will be removed in future versions. Use collection_DeleteDocument instead.
   */
  database_DeleteDocument(args: DatabaseDeleteDocumentArgs): Promise<void> {
    const colArgs: CollectionDeleteDocumentArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      docId: args.docId,
      concurrencyControl: args.concurrencyControl,
    };
    this.debugLog(
      `::DEBUG:: database_DeleteDocument: ${args.docId} ${args.databaseUniqueName} ${this._defaultScopeName} ${this._defaultCollectionName} ${args.concurrencyControl}`
    );
    return this.collection_DeleteDocument(colArgs);
  }

  /**
   * @deprecated This function will be removed in future versions. Use collection_DeleteIndex instead.
   */
  database_DeleteIndex(args: DatabaseDeleteIndexArgs): Promise<void> {
    const colArgs: CollectionDeleteIndexArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      indexName: args.indexName,
    };
    return this.collection_DeleteIndex(colArgs);
  }

  /**
   * @deprecated This will be removed in future versions. Use collection_GetCount instead.
   */
  database_GetCount(args: DatabaseArgs): Promise<{ count: number }> {
    const colArgs: CollectionArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
    };
    return this.collection_GetCount(colArgs);
  }

  /**
   * @deprecated This will be removed in future versions. Use collection_GetDocument instead.
   */
  database_GetDocument(args: DatabaseGetDocumentArgs): Promise<DocumentResult> {
    const colArgs: CollectionGetDocumentArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      docId: args.docId,
    };
    return this.collection_GetDocument(colArgs);
  }

  /**
   * @deprecated This function will be removed in future versions. Use collection_GetIndexes instead.
   */
  database_GetIndexes(args: DatabaseArgs): Promise<{ indexes: string[] }> {
    const colArgs: CollectionArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
    };
    return this.collection_GetIndexes(colArgs);
  }

  /**
   * @deprecated This will be removed in future versions. Use collection_PurgeDocument instead.
   */
  database_PurgeDocument(args: DatabasePurgeDocumentArgs): Promise<void> {
    const colArgs: CollectionPurgeDocumentArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      docId: args.docId,
    };
    return this.collection_PurgeDocument(colArgs);
  }

  /**
   * @deprecated This function will be removed in future versions. Use collection_Save instead.
   */
  database_Save(args: DatabaseSaveArgs): Promise<{ _id: string }> {
    const colArgs: CollectionSaveStringArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      id: args.id,
      document: JSON.stringify(args.document),
      blobs: JSON.stringify(args.blobs),
      concurrencyControl: args.concurrencyControl,
    };
    return this.collection_Save(colArgs);
  }

  // ─── NativeCblCollection ──────────────────────────────────────────────────

  collection_CreateCollection(
    args: CollectionArgs
  ): Promise<NativeCollectionResult> {
    this.logOpStart(
      'collection_CreateCollection',
      LogDomain.DATABASE,
      `${args.scopeName} ${args.collectionName} ${args.databaseUniqueName}`,
      `scope=${args.scopeName}, name=${args.collectionName}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_CreateCollection(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      ).then(
        (result) => {
          this.logOpDone(
            'collection_CreateCollection',
            LogDomain.DATABASE,
            '',
            `scope=${args.scopeName}, name=${args.collectionName}`,
            LogLevel.INFO
          );
          resolve(result as unknown as NativeCollectionResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_CreateCollection',
            error,
            LogDomain.DATABASE,
            `scope=${args.scopeName}, name=${args.collectionName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_DeleteCollection(args: CollectionArgs): Promise<void> {
    this.logOpStart(
      'collection_DeleteCollection',
      LogDomain.DATABASE,
      `${args.scopeName} ${args.collectionName} ${args.databaseUniqueName}`,
      `scope=${args.scopeName}, name=${args.collectionName}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_DeleteCollection(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      ).then(
        () => {
          this.logOpDone(
            'collection_DeleteCollection',
            LogDomain.DATABASE,
            '',
            `scope=${args.scopeName}, name=${args.collectionName}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_DeleteCollection',
            error,
            LogDomain.DATABASE,
            `scope=${args.scopeName}, name=${args.collectionName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetCollection(
    args: CollectionArgs
  ): Promise<NativeCollectionResult> {
    this.logOpStart(
      'collection_GetCollection',
      LogDomain.DATABASE,
      `${args.scopeName} ${args.collectionName} ${args.databaseUniqueName}`,
      `scope=${args.scopeName}, name=${args.collectionName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_GetCollection(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      ).then(
        (result) => {
          this.logOpDone(
            'collection_GetCollection',
            LogDomain.DATABASE,
            '',
            `name=${args.collectionName}, found=${result != null}`
          );
          resolve(result as unknown as NativeCollectionResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetCollection',
            error,
            LogDomain.DATABASE,
            `name=${args.collectionName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetCollections(args: ScopeArgs): Promise<CollectionsResult> {
    this.logOpStart(
      'collection_GetCollections',
      LogDomain.DATABASE,
      `${args.scopeName} ${args.databaseUniqueName}`,
      `scope=${args.scopeName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_GetCollections(
        args.databaseUniqueName,
        args.scopeName
      ).then(
        (result) => {
          const collections = (result as unknown as CollectionsResult)
            ?.collections;
          const count = Array.isArray(collections)
            ? collections.length
            : undefined;
          this.logOpDone(
            'collection_GetCollections',
            LogDomain.DATABASE,
            '',
            count !== undefined ? `scope=${args.scopeName}, count=${count}` : ''
          );
          resolve(result as unknown as CollectionsResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetCollections',
            error,
            LogDomain.DATABASE,
            `scope=${args.scopeName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetDefault(args: DatabaseArgs): Promise<NativeCollectionResult> {
    this.logOpStart(
      'collection_GetDefault',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_GetDefault(args.databaseUniqueName).then(
        (result) => {
          this.logOpDone('collection_GetDefault', LogDomain.DATABASE);
          resolve(result as unknown as NativeCollectionResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetDefault',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetCount(args: CollectionArgs): Promise<{ count: number }> {
    this.debugLog(
      `::DEBUG:: collection_GetCount: ${args.collectionName} ${args.databaseUniqueName} ${args.scopeName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_GetCount(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      ).then(
        (result) => {
          this.debugLog(
            `::DEBUG:: collection_GetCount completed with result: ${JSON.stringify(result)}`
          );
          resolve(result as unknown as { count: number });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.errorLog(
            `::ERROR:: collection_GetCount Error: ${error}`,
            LogDomain.DATABASE,
            `::ERROR:: collection_GetCount failed for ${args.collectionName}`
          );
          reject(error);
        }
      );
    });
  }

  async collection_GetFullName(
    args: CollectionArgs
  ): Promise<{ fullName: string }> {
    this.debugLog(
      `::DEBUG:: collection_GetFullName: ${args.collectionName} ${args.databaseUniqueName} ${args.scopeName}`
    );

    try {
      const result = await NativeCblCollection.collection_GetFullName(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      );

      this.debugLog(
        `::DEBUG:: collection_GetFullName completed with result: ${JSON.stringify(result)}`
      );

      return result as unknown as { fullName: string };
    } catch (error: unknown) {
      this.errorLog(
        `::ERROR:: collection_GetFullName Error: ${error}`,
        LogDomain.DATABASE,
        `::ERROR:: collection_GetFullName failed for ${args.collectionName}`
      );
      throw error;
    }
  }

  collection_CreateIndex(args: CollectionCreateIndexArgs): Promise<void> {
    // The index spec (args.index) may describe queried fields; never forward it.
    // Only the index name + scope/collection are forwarded.
    this.logOpStart(
      'collection_CreateIndex',
      LogDomain.QUERY,
      `${args.scopeName} ${args.collectionName} ${args.indexName}`,
      `scope=${args.scopeName}, col=${args.collectionName}, index=${args.indexName}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_CreateIndex(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.indexName,
        args.index
      ).then(
        () => {
          this.logOpDone(
            'collection_CreateIndex',
            LogDomain.QUERY,
            '',
            `index=${args.indexName}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_CreateIndex',
            error,
            LogDomain.QUERY,
            `index=${args.indexName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_DeleteIndex(args: CollectionDeleteIndexArgs): Promise<void> {
    this.logOpStart(
      'collection_DeleteIndex',
      LogDomain.QUERY,
      `${args.scopeName} ${args.collectionName} ${args.indexName}`,
      `scope=${args.scopeName}, col=${args.collectionName}, index=${args.indexName}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_DeleteIndex(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.indexName
      ).then(
        () => {
          this.logOpDone(
            'collection_DeleteIndex',
            LogDomain.QUERY,
            '',
            `index=${args.indexName}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_DeleteIndex',
            error,
            LogDomain.QUERY,
            `index=${args.indexName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetIndexes(args: CollectionArgs): Promise<{ indexes: string[] }> {
    this.logOpStart(
      'collection_GetIndexes',
      LogDomain.QUERY,
      `${args.scopeName} ${args.collectionName}`,
      `scope=${args.scopeName}, col=${args.collectionName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblCollection.collection_GetIndexes(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName
      ).then(
        (items) => {
          const indexes = (items as unknown as { indexes?: string[] })?.indexes;
          const count = Array.isArray(indexes) ? indexes.length : undefined;
          this.logOpDone(
            'collection_GetIndexes',
            LogDomain.QUERY,
            '',
            count !== undefined ? `count=${count}` : ''
          );
          resolve(items as unknown as { indexes: string[] });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetIndexes',
            error,
            LogDomain.QUERY,
            `col=${args.collectionName}`
          );
          reject(error);
        }
      );
    });
  }

  collection_AddChangeListener(
    args: CollectionChangeListenerArgs,
    lcb: ListenerCallback
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const token = args.changeListenerToken;

      if (this._collectionChangeListeners.has(token)) {
        this.logOpWarn(
          'collection_AddChangeListener',
          'duplicate token',
          LogDomain.LISTENER,
          `token=${token}`
        );
        reject(new Error('Change listener token already exists'));
        return;
      }

      this.logOpStart(
        'collection_AddChangeListener',
        LogDomain.LISTENER,
        `${args.scopeName} ${args.collectionName} token: ${token}`,
        `scope=${args.scopeName}, col=${args.collectionName}, token=${token}`
      );

      this._collectionChangeListeners.set(token, lcb);
      this._ensureEventSubscription(
        ENGINE_EVENTS.collectionChange,
        (results) => {
          this._dispatchTokenEvent(
            ENGINE_EVENTS.collectionChange,
            this._collectionChangeListeners,
            results,
            (payload) => [payload as CollectionChangeEvent]
          );
        }
      );

      NativeCblCollection.collection_AddChangeListener(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        token
      ).then(
        () => {
          this.logOpDone(
            'collection_AddChangeListener',
            LogDomain.LISTENER,
            '',
            `token=${token}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this._collectionChangeListeners.delete(token);
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.collectionChange,
            this._collectionChangeListeners
          );
          this.logOpError(
            'collection_AddChangeListener',
            error,
            LogDomain.LISTENER,
            `token=${token}`
          );
          reject(error);
        }
      );
    });
  }

  collection_AddDocumentChangeListener(
    args: DocumentChangeListenerArgs,
    lcb: ListenerCallback
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const token = args.changeListenerToken;

      if (this._collectionDocumentChangeListeners.has(token)) {
        this.logOpWarn(
          'collection_AddDocumentChangeListener',
          'duplicate token',
          LogDomain.LISTENER,
          `token=${token}`
        );
        reject(new Error('Document change listener token already exists'));
        return;
      }

      this.logOpStart(
        'collection_AddDocumentChangeListener',
        LogDomain.LISTENER,
        `${args.collectionName} docId: ${args.documentId} token: ${token}`,
        `col=${args.collectionName}, docId=${args.documentId}, token=${token}`
      );

      this._collectionDocumentChangeListeners.set(token, lcb);
      this._ensureEventSubscription(
        ENGINE_EVENTS.collectionDocumentChange,
        (results) => {
          this._dispatchTokenEvent(
            ENGINE_EVENTS.collectionDocumentChange,
            this._collectionDocumentChangeListeners,
            results,
            (payload) => [payload as CollectionDocumentChangeEvent]
          );
        }
      );

      NativeCblCollection.collection_AddDocumentChangeListener(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.documentId,
        token
      ).then(
        () => {
          this.logOpDone(
            'collection_AddDocumentChangeListener',
            LogDomain.LISTENER,
            '',
            `token=${token}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this._collectionDocumentChangeListeners.delete(token);
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.collectionDocumentChange,
            this._collectionDocumentChangeListeners
          );
          this.logOpError(
            'collection_AddDocumentChangeListener',
            error,
            LogDomain.LISTENER,
            `token=${token}`
          );
          reject(error);
        }
      );
    });
  }

  collection_RemoveChangeListener(
    // eslint-disable-next-line
    args: CollectionChangeListenerArgs
  ): Promise<void> {
    const token = args.changeListenerToken;

    if (!this._collectionChangeListeners.has(token)) {
      this.logOpWarn(
        'collection_RemoveChangeListener',
        'no listener for token',
        LogDomain.LISTENER,
        `token=${token}`
      );
      return Promise.reject(
        new Error(`No listener found with token: ${token}`)
      );
    }

    this.logOpStart(
      'collection_RemoveChangeListener',
      LogDomain.LISTENER,
      `token: ${token}`,
      `token=${token}`
    );

    return this._removeListenerTokenAfterNativeSuccess(
      token,
      () => NativeCblCollection.collection_RemoveChangeListener(token),
      [this._collectionChangeListeners],
      () =>
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.collectionChange,
          this._collectionChangeListeners
        )
    ).then(
      () => {
        this.logOpDone(
          'collection_RemoveChangeListener',
          LogDomain.LISTENER,
          `for token: ${token}`,
          `token=${token}`
        );
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error: any) => {
        this.logOpError(
          'collection_RemoveChangeListener',
          error,
          LogDomain.LISTENER,
          `token=${token}`
        );
        throw error;
      }
    );
  }

  collection_RemoveDocumentChangeListener(
    // eslint-disable-next-line
    args: CollectionChangeListenerArgs
  ): Promise<void> {
    const token = args.changeListenerToken;

    if (!this._collectionDocumentChangeListeners.has(token)) {
      this.logOpWarn(
        'collection_RemoveDocumentChangeListener',
        'no listener for token',
        LogDomain.LISTENER,
        `token=${token}`
      );
      return Promise.reject(
        new Error(`No document listener found with token: ${token}`)
      );
    }

    this.logOpStart(
      'collection_RemoveDocumentChangeListener',
      LogDomain.LISTENER,
      `token: ${token}`,
      `token=${token}`
    );

    return this._removeListenerTokenAfterNativeSuccess(
      token,
      () => NativeCblCollection.collection_RemoveChangeListener(token),
      [this._collectionDocumentChangeListeners],
      () =>
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.collectionDocumentChange,
          this._collectionDocumentChangeListeners
        )
    ).then(
      () => {
        this.logOpDone(
          'collection_RemoveDocumentChangeListener',
          LogDomain.LISTENER,
          `for token: ${token}`,
          `token=${token}`
        );
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error: any) => {
        this.logOpError(
          'collection_RemoveDocumentChangeListener',
          error,
          LogDomain.LISTENER,
          `token=${token}`
        );
        throw error;
      }
    );
  }

  // ─── NativeCblDocument ────────────────────────────────────────────────────

  collection_GetDocument(
    args: CollectionGetDocumentArgs
  ): Promise<DocumentResult> {
    // Console keeps the full context; the forwarded line uses col+id only
    // (never the document body which arrives in the success callback).
    this.logOpStart(
      'collection_GetDocument',
      LogDomain.DATABASE,
      `${args.docId} ${args.databaseUniqueName} ${args.scopeName} ${args.collectionName}`,
      `col=${args.collectionName}, id=${args.docId}`
    );

    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_GetDocument(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.docId
      ).then(
        (dr) => {
          // Console keeps the full document for debugging; the forwarded line
          // never persists the document body.
          this.logOpDone(
            'collection_GetDocument',
            LogDomain.DATABASE,
            JSON.stringify(dr),
            `id=${args.docId}`
          );
          resolve(dr as unknown as DocumentResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetDocument',
            error,
            LogDomain.DATABASE,
            `id=${args.docId}`
          );
          reject(error);
        }
      );
    });
  }

  collection_Save(
    args: CollectionSaveStringArgs
  ): Promise<CollectionDocumentSaveResult> {
    //deal with react native passing nulls
    const concurrencyControl =
      args.concurrencyControl !== null
        ? (args.concurrencyControl as number)
        : -9999;
    // Console keeps the full document/blobs for local debugging; the forwarded
    // line never persists the document body or blob payloads.
    const hasBlobs =
      typeof args.blobs === 'string' &&
      args.blobs !== '{}' &&
      args.blobs.length > 0;
    this.logOpStart(
      'collection_Save',
      LogDomain.DATABASE,
      `${args.document} ${args.blobs} ${args.id} ${args.databaseUniqueName} ${args.scopeName} ${args.collectionName} ${concurrencyControl}`,
      `col=${args.collectionName}, id=${args.id}, hasBlobs=${hasBlobs}`
    );

    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_Save(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.id,
        args.document,
        args.blobs,
        concurrencyControl
      ).then(
        (resultsData) => {
          // Console keeps the full result for debugging; the forwarded line
          // carries only the id (safe scalar, no body or blob payloads).
          this.logOpDone(
            'collection_Save',
            LogDomain.DATABASE,
            JSON.stringify(resultsData),
            `id=${args.id}`
          );
          resolve(resultsData as unknown as CollectionDocumentSaveResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_Save',
            error,
            LogDomain.DATABASE,
            `id=${args.id}`
          );
          reject(error);
        }
      );
    });
  }

  collection_DeleteDocument(args: CollectionDeleteDocumentArgs): Promise<void> {
    const concurrencyControl =
      args.concurrencyControl !== null
        ? (args.concurrencyControl as number)
        : -9999;
    this.logOpStart(
      'collection_DeleteDocument',
      LogDomain.DATABASE,
      `${args.docId} ${args.databaseUniqueName} ${args.scopeName} ${args.collectionName} ${concurrencyControl}`,
      `col=${args.collectionName}, id=${args.docId}`
    );

    // The native bridge identifies documents by id only; it cannot directly
    // observe that the caller is holding a stale (older revision) handle.
    // For FAIL_ON_CONFLICT we emulate optimistic-locking semantics in JS by
    // comparing the caller's revisionID against the current persisted
    // revisionID before invoking the native delete. If they differ, reject
    // immediately with a FAIL_ON_CONFLICT error.
    const failOnConflict =
      args.concurrencyControl === ConcurrencyControl.FAIL_ON_CONFLICT;
    const callerRevisionID =
      typeof args.revisionID === 'string' && args.revisionID.length > 0
        ? args.revisionID
        : null;

    const performDelete = (): Promise<void> =>
      new Promise<void>((resolve, reject) => {
        NativeCblDocument.collection_DeleteDocument(
          args.databaseUniqueName,
          args.collectionName,
          args.scopeName,
          args.docId,
          concurrencyControl
        ).then(
          (result) => {
            const ccr = (
              result as { concurrencyControlResult?: boolean } | undefined
            )?.concurrencyControlResult;
            this.logOpDone(
              'collection_DeleteDocument',
              LogDomain.DATABASE,
              `ccr=${ccr ?? '<none>'}`,
              `id=${args.docId}`
            );
            if (failOnConflict && ccr === false) {
              reject(
                new Error(
                  `Delete failed for document '${args.docId}': concurrent modification detected (FAIL_ON_CONFLICT)`
                )
              );
              return;
            }
            resolve();
          },
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (error: any) => {
            this.errorLog(
              `::ERROR:: collection_DeleteDocument Error: ${error}`,
              LogDomain.DATABASE,
              `::ERROR:: collection_DeleteDocument failed (id=${args.docId})`
            );
            reject(error);
          }
        );
      });

    if (!failOnConflict || callerRevisionID === null) {
      return performDelete();
    }

    return new Promise<void>((resolve, reject) => {
      NativeCblDocument.collection_GetDocument(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.docId
      ).then(
        (current) => {
          const currentRevisionID = (
            current as { _revId?: string; _id?: string } | undefined
          )?._revId;
          if (
            typeof currentRevisionID === 'string' &&
            currentRevisionID.length > 0 &&
            currentRevisionID !== callerRevisionID
          ) {
            reject(
              new Error(
                `Delete failed for document '${args.docId}': concurrent modification detected (FAIL_ON_CONFLICT)`
              )
            );
            return;
          }
          performDelete().then(resolve, reject);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.errorLog(
            `::ERROR:: collection_DeleteDocument pre-check Error: ${error}`,
            LogDomain.DATABASE,
            `::ERROR:: collection_DeleteDocument pre-check failed (id=${args.docId})`
          );
          reject(error);
        }
      );
    });
  }

  collection_PurgeDocument(args: CollectionPurgeDocumentArgs): Promise<void> {
    this.logOpStart(
      'collection_PurgeDocument',
      LogDomain.DATABASE,
      `${args.collectionName} ${args.docId}`,
      `col=${args.collectionName}, id=${args.docId}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_PurgeDocument(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.docId
      ).then(
        () => {
          this.logOpDone(
            'collection_PurgeDocument',
            LogDomain.DATABASE,
            '',
            `id=${args.docId}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_PurgeDocument',
            error,
            LogDomain.DATABASE,
            `id=${args.docId}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetDocumentExpiration(
    args: CollectionGetDocumentArgs
  ): Promise<DocumentExpirationResult | null> {
    this.logOpStart(
      'collection_GetDocumentExpiration',
      LogDomain.DATABASE,
      `${args.collectionName} ${args.docId}`,
      `col=${args.collectionName}, id=${args.docId}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_GetDocumentExpiration(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.docId
      ).then(
        (raw) => {
          const iso = raw != null ? (raw as { date?: string }).date : undefined;
          // The expiration timestamp is never forwarded; only a boolean.
          this.logOpDone(
            'collection_GetDocumentExpiration',
            LogDomain.DATABASE,
            '',
            `id=${args.docId}, hasExpiration=${iso != null}`
          );
          if (raw == null) {
            resolve(null);
            return;
          }
          resolve(iso ? { date: new Date(iso) } : null);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetDocumentExpiration',
            error,
            LogDomain.DATABASE,
            `id=${args.docId}`
          );
          reject(error);
        }
      );
    });
  }

  collection_SetDocumentExpiration(
    args: CollectionDocumentExpirationArgs
  ): Promise<void> {
    const clearing = args.expiration == null;
    // The expiration timestamp value is never forwarded; only a boolean
    // indicating whether the expiration is being cleared.
    this.logOpStart(
      'collection_SetDocumentExpiration',
      LogDomain.DATABASE,
      `${args.collectionName} ${args.docId} ${
        args.expiration != null ? args.expiration.toISOString() : null
      }`,
      `col=${args.collectionName}, id=${args.docId}, clear=${clearing}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_SetDocumentExpiration(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.docId,
        args.expiration != null ? args.expiration.toISOString() : null
      ).then(
        () => {
          this.logOpDone(
            'collection_SetDocumentExpiration',
            LogDomain.DATABASE,
            '',
            `id=${args.docId}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_SetDocumentExpiration',
            error,
            LogDomain.DATABASE,
            `id=${args.docId}`
          );
          reject(error);
        }
      );
    });
  }

  collection_GetBlobContent(
    args: CollectionDocumentGetBlobContentArgs
  ): Promise<{ data: ArrayBuffer }> {
    // The blob key and the blob bytes are never forwarded; only the docId and
    // (on success) the byte length are recorded.
    this.logOpStart(
      'collection_GetBlobContent',
      LogDomain.DATABASE,
      `${args.collectionName} ${args.documentId}`,
      `col=${args.collectionName}, docId=${args.documentId}`
    );
    return new Promise((resolve, reject) => {
      NativeCblDocument.collection_GetBlobContent(
        args.databaseUniqueName,
        args.collectionName,
        args.scopeName,
        args.documentId,
        args.key
      ).then(
        (resultsData) => {
          const bytes = new Uint8Array(
            (resultsData as unknown as { data: Iterable<number> }).data
          );
          this.logOpDone(
            'collection_GetBlobContent',
            LogDomain.DATABASE,
            '',
            `docId=${args.documentId}, bytes=${bytes.byteLength}`
          );
          resolve({ data: bytes.buffer });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'collection_GetBlobContent',
            error,
            LogDomain.DATABASE,
            `docId=${args.documentId}`
          );
          reject(error);
        }
      );
    });
  }

  /**
   * @deprecated This will be removed in future versions. Use collection_GetBlobContent instead.
   */
  document_GetBlobContent(
    args: DocumentGetBlobContentArgs
  ): Promise<{ data: ArrayBuffer }> {
    const colArgs: CollectionDocumentGetBlobContentArgs = {
      databaseUniqueName: args.databaseUniqueName,
      collectionName: this._defaultCollectionName,
      scopeName: this._defaultScopeName,
      documentId: args.documentId,
      key: args.key,
    };
    return this.collection_GetBlobContent(colArgs);
  }

  // ─── NativeCblQuery ───────────────────────────────────────────────────────

  query_Execute(args: QueryExecuteArgs): Promise<Result> {
    const hasParams = args.parameters != null;
    // The N1QL/QueryBuilder string and parameter values may carry PII/business
    // data; never forward args.query or args.parameters — only queryId.
    this.logOpStart(
      'query_Execute',
      LogDomain.QUERY,
      `${args.databaseUniqueName} ${args.queryId ?? ''} ${args.query}`,
      `db=${args.databaseUniqueName}, queryId=${args.queryId ?? ''}, hasParams=${hasParams}`
    );
    return new Promise((resolve, reject) => {
      NativeCblQuery.query_Execute(
        args.databaseUniqueName,
        args.queryId ?? '',
        args.query,
        args.parameters
      ).then(
        (result) => {
          // No row count: the engine receives an unparsed JSON string and must
          // not parse it just for logging (Query.execute parses it later).
          this.logOpDone(
            'query_Execute',
            LogDomain.QUERY,
            '',
            `queryId=${args.queryId ?? ''}`
          );
          resolve(result as unknown as Result);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'query_Execute',
            error,
            LogDomain.QUERY,
            `queryId=${args.queryId ?? ''}`
          );
          reject(error);
        }
      );
    });
  }

  query_Explain(args: QueryExecuteArgs): Promise<{ data: string }> {
    const hasParams = args.parameters != null;
    this.logOpStart(
      'query_Explain',
      LogDomain.QUERY,
      `${args.databaseUniqueName} ${args.queryId ?? ''} ${args.query}`,
      `db=${args.databaseUniqueName}, queryId=${args.queryId ?? ''}, hasParams=${hasParams}`
    );
    return new Promise((resolve, reject) => {
      NativeCblQuery.query_Explain(
        args.databaseUniqueName,
        args.queryId ?? '',
        args.query,
        args.parameters
      ).then(
        (result) => {
          // The returned plan text is never forwarded; only queryId.
          this.logOpDone(
            'query_Explain',
            LogDomain.QUERY,
            '',
            `queryId=${args.queryId ?? ''}`
          );
          resolve(result as unknown as { data: string });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'query_Explain',
            error,
            LogDomain.QUERY,
            `queryId=${args.queryId ?? ''}`
          );
          reject(error);
        }
      );
    });
  }

  query_AddChangeListener(
    args: QueryChangeListenerArgs,
    lcb: ListenerCallback
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const token = args.changeListenerToken;

      if (this._queryChangeListeners.has(token)) {
        this.logOpWarn(
          'query_AddChangeListener',
          'duplicate token',
          LogDomain.QUERY,
          `token=${token}`
        );
        reject(new Error('Query change listener token already exists'));
        return;
      }

      this.logOpStart(
        'query_AddChangeListener',
        LogDomain.QUERY,
        `${args.queryId ?? ''} token: ${token}`,
        `queryId=${args.queryId ?? ''}, token=${token}`
      );

      this._queryChangeListeners.set(token, lcb);
      this._ensureEventSubscription(ENGINE_EVENTS.queryChange, (results) => {
        this._dispatchTokenEvent(
          ENGINE_EVENTS.queryChange,
          this._queryChangeListeners,
          results,
          (payload) => [payload as QueryChangeEvent]
        );
      });

      NativeCblQuery.query_AddChangeListener(
        args.databaseUniqueName,
        args.queryId ?? '',
        args.query,
        args.parameters,
        token
      ).then(
        () => {
          this.logOpDone(
            'query_AddChangeListener',
            LogDomain.QUERY,
            '',
            `token=${token}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this._queryChangeListeners.delete(token);
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.queryChange,
            this._queryChangeListeners
          );
          this.logOpError(
            'query_AddChangeListener',
            error,
            LogDomain.QUERY,
            `token=${token}`
          );
          reject(error);
        }
      );
    });
  }

  query_RemoveChangeListener(
    args: QueryRemoveChangeListenerArgs
  ): Promise<void> {
    const token = args.changeListenerToken;

    if (!this._queryChangeListeners.has(token)) {
      this.logOpWarn(
        'query_RemoveChangeListener',
        'no listener for token',
        LogDomain.QUERY,
        `token=${token}`
      );
      return Promise.reject(
        new Error(`No query listener found with token: ${token}`)
      );
    }

    this.logOpStart(
      'query_RemoveChangeListener',
      LogDomain.QUERY,
      `token: ${token}`,
      `token=${token}`
    );

    return this._removeListenerTokenAfterNativeSuccess(
      token,
      () => NativeCblQuery.query_RemoveChangeListener(token),
      [this._queryChangeListeners],
      () =>
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.queryChange,
          this._queryChangeListeners
        )
    ).then(
      () => {
        this.logOpDone(
          'query_RemoveChangeListener',
          LogDomain.QUERY,
          `for token: ${token}`,
          `token=${token}`
        );
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error: any) => {
        this.logOpError(
          'query_RemoveChangeListener',
          error,
          LogDomain.QUERY,
          `token=${token}`
        );
        throw error;
      }
    );
  }

  // ─── NativeCblReplicator ──────────────────────────────────────────────────

  // Returns a safe, scalar-only summary of a replicator config, or '' — never
  // throws and never reads endpoint URL or authenticator/credentials. The
  // config is typed `any` and supports multiple shapes, so every access is
  // defensive and wrapped.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private safeReplicatorSummary(config: any): string {
    try {
      const continuous =
        typeof config?.continuous === 'boolean' ? config.continuous : undefined;
      const type =
        typeof config?.replicatorType === 'string'
          ? config.replicatorType
          : typeof config?.type === 'string'
            ? config.type
            : undefined;
      const collections = Array.isArray(config?.collections)
        ? config.collections.length
        : Array.isArray(config?.collectionConfig)
          ? config.collectionConfig.length
          : undefined;
      const parts = [
        collections !== undefined ? `collections=${collections}` : null,
        continuous !== undefined ? `continuous=${continuous}` : null,
        type !== undefined ? `type=${type}` : null,
      ].filter((p): p is string => p !== null);
      return parts.join(', ');
    } catch {
      return '';
    }
  }

  replicator_Create(args: ReplicatorCreateArgs): Promise<ReplicatorArgs> {
    // Never forward the endpoint URL or authenticator; only a scalar summary.
    this.logOpStart(
      'replicator_Create',
      LogDomain.REPLICATOR,
      '',
      this.safeReplicatorSummary(args.config),
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_Create(args.config).then(
        (results) => {
          const replicatorId = (results as { replicatorId?: string })
            ?.replicatorId;
          this.logOpDone(
            'replicator_Create',
            LogDomain.REPLICATOR,
            '',
            replicatorId ? `replicatorId=${replicatorId}` : '',
            LogLevel.INFO
          );
          resolve(results as unknown as ReplicatorArgs);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError('replicator_Create', error, LogDomain.REPLICATOR);
          reject(error);
        }
      );
    });
  }

  replicator_Start(args: ReplicatorArgs): Promise<void> {
    this.logOpStart(
      'replicator_Start',
      LogDomain.REPLICATOR,
      args.replicatorId,
      `replicatorId=${args.replicatorId}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_Start(args.replicatorId).then(
        () => {
          this.logOpDone(
            'replicator_Start',
            LogDomain.REPLICATOR,
            '',
            `replicatorId=${args.replicatorId}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_Start',
            error,
            LogDomain.REPLICATOR,
            `replicatorId=${args.replicatorId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_Stop(args: ReplicatorArgs): Promise<void> {
    this.logOpStart(
      'replicator_Stop',
      LogDomain.REPLICATOR,
      args.replicatorId,
      `replicatorId=${args.replicatorId}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_Stop(args.replicatorId).then(
        () => {
          this.logOpDone(
            'replicator_Stop',
            LogDomain.REPLICATOR,
            '',
            `replicatorId=${args.replicatorId}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_Stop',
            error,
            LogDomain.REPLICATOR,
            `replicatorId=${args.replicatorId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_Cleanup(args: ReplicatorArgs): Promise<void> {
    this.logOpStart(
      'replicator_Cleanup',
      LogDomain.REPLICATOR,
      args.replicatorId,
      `replicatorId=${args.replicatorId}`
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_Cleanup(args.replicatorId).then(
        () => {
          this.logOpDone(
            'replicator_Cleanup',
            LogDomain.REPLICATOR,
            '',
            `replicatorId=${args.replicatorId}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_Cleanup',
            error,
            LogDomain.REPLICATOR,
            `replicatorId=${args.replicatorId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_GetStatus(args: ReplicatorArgs): Promise<ReplicatorStatus> {
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_GetStatus(args.replicatorId).then(
        (results) => {
          resolve(results as unknown as ReplicatorStatus);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          reject(error);
        }
      );
    });
  }

  replicator_ResetCheckpoint(args: ReplicatorArgs): Promise<void> {
    this.logOpStart(
      'replicator_ResetCheckpoint',
      LogDomain.REPLICATOR,
      args.replicatorId,
      `replicatorId=${args.replicatorId}`,
      LogLevel.INFO
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_ResetCheckpoint(args.replicatorId).then(
        () => {
          this.logOpDone(
            'replicator_ResetCheckpoint',
            LogDomain.REPLICATOR,
            '',
            `replicatorId=${args.replicatorId}`,
            LogLevel.INFO
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_ResetCheckpoint',
            error,
            LogDomain.REPLICATOR,
            `replicatorId=${args.replicatorId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_GetPendingDocumentIds(
    args: ReplicatorCollectionArgs
  ): Promise<{ pendingDocumentIds: string[] }> {
    this.logOpStart(
      'replicator_GetPendingDocumentIds',
      LogDomain.REPLICATOR,
      `${args.replicatorId} ${args.collectionName}`,
      `replicatorId=${args.replicatorId}, col=${args.collectionName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_GetPendingDocumentIds(
        args.databaseUniqueName,
        args.replicatorId,
        args.collectionName,
        args.scopeName
      ).then(
        (results) => {
          // Forward the count only, never the document ids.
          const ids = (results as { pendingDocumentIds?: string[] })
            ?.pendingDocumentIds;
          const count = Array.isArray(ids) ? ids.length : undefined;
          this.logOpDone(
            'replicator_GetPendingDocumentIds',
            LogDomain.REPLICATOR,
            '',
            count !== undefined ? `count=${count}` : ''
          );
          resolve(results as unknown as { pendingDocumentIds: string[] });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_GetPendingDocumentIds',
            error,
            LogDomain.REPLICATOR,
            `replicatorId=${args.replicatorId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_IsDocumentPending(
    args: ReplicatorDocumentPendingArgs
  ): Promise<{ isPending: boolean }> {
    this.logOpStart(
      'replicator_IsDocumentPending',
      LogDomain.REPLICATOR,
      `${args.replicatorId} ${args.collectionName} ${args.documentId}`,
      `replicatorId=${args.replicatorId}, col=${args.collectionName}, docId=${args.documentId}`
    );
    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_IsDocumentPending(
        args.databaseUniqueName,
        args.replicatorId,
        args.collectionName,
        args.scopeName,
        args.documentId
      ).then(
        (results) => {
          const isPending = (results as { isPending?: boolean })?.isPending;
          this.logOpDone(
            'replicator_IsDocumentPending',
            LogDomain.REPLICATOR,
            '',
            `docId=${args.documentId}, isPending=${isPending}`
          );
          resolve(results as unknown as { isPending: boolean });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'replicator_IsDocumentPending',
            error,
            LogDomain.REPLICATOR,
            `docId=${args.documentId}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_AddChangeListener(
    args: ReplicationChangeListenerArgs,
    lcb: ListenerCallback
  ): Promise<void> {
    if (this._replicatorChangeListeners.has(args.changeListenerToken)) {
      this.logOpWarn(
        'replicator_AddChangeListener',
        'duplicate token',
        LogDomain.REPLICATOR,
        `token=${args.changeListenerToken}`
      );
      throw new Error(
        'ERROR:  changeListenerToken already exists and is registered to listen to callbacks, cannot add a new one'
      );
    }

    this.logOpStart(
      'replicator_AddChangeListener',
      LogDomain.REPLICATOR,
      `${args.replicatorId} token: ${args.changeListenerToken}`,
      `replicatorId=${args.replicatorId}, token=${args.changeListenerToken}`
    );

    this._replicatorChangeListeners.set(args.changeListenerToken, lcb);
    this._ensureEventSubscription(
      ENGINE_EVENTS.replicatorStatusChange,
      (results) => {
        this._dispatchTokenEvent(
          ENGINE_EVENTS.replicatorStatusChange,
          this._replicatorChangeListeners,
          results,
          (payload) => {
            const statusEvent = payload as ReplicatorStatusChangeEvent;
            return [
              statusEvent.status as ListenerCallbackArgs[0],
              statusEvent.error as ListenerCallbackArgs[1],
            ];
          }
        );
      }
    );

    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_AddChangeListener(
        args.changeListenerToken,
        args.replicatorId
      ).then(
        () => {
          this.logOpDone(
            'replicator_AddChangeListener',
            LogDomain.REPLICATOR,
            '',
            `token=${args.changeListenerToken}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this._replicatorChangeListeners.delete(args.changeListenerToken);
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.replicatorStatusChange,
            this._replicatorChangeListeners
          );
          this.logOpError(
            'replicator_AddChangeListener',
            error,
            LogDomain.REPLICATOR,
            `token=${args.changeListenerToken}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_AddDocumentChangeListener(
    args: ReplicationChangeListenerArgs,
    lcb: ListenerCallback
  ): Promise<void> {
    if (this._replicatorDocumentChangeListeners.has(args.changeListenerToken)) {
      this.logOpWarn(
        'replicator_AddDocumentChangeListener',
        'duplicate token',
        LogDomain.REPLICATOR,
        `token=${args.changeListenerToken}`
      );
      throw new Error(
        'ERROR: changeListenerToken already exists and is registered to listen to document callbacks, cannot add a new one'
      );
    }

    this._replicatorDocumentChangeListeners.set(args.changeListenerToken, lcb);
    this._ensureEventSubscription(
      ENGINE_EVENTS.replicatorDocumentChange,
      (results) => {
        this._dispatchTokenEvent(
          ENGINE_EVENTS.replicatorDocumentChange,
          this._replicatorDocumentChangeListeners,
          results,
          (payload) => {
            const documentEvent = payload as ReplicatorDocumentChangeEvent;
            return [
              documentEvent.documents as ListenerCallbackArgs[0],
              documentEvent.error as ListenerCallbackArgs[1],
            ];
          }
        );
      }
    );

    this.logOpStart(
      'replicator_AddDocumentChangeListener',
      LogDomain.REPLICATOR,
      `replicatorId=${args.replicatorId} token: ${args.changeListenerToken}`,
      `replicatorId=${args.replicatorId}, token=${args.changeListenerToken}`
    );

    return new Promise((resolve, reject) => {
      NativeCblReplicator.replicator_AddDocumentChangeListener(
        args.changeListenerToken,
        args.replicatorId
      ).then(
        () => {
          this.logOpDone(
            'replicator_AddDocumentChangeListener',
            LogDomain.REPLICATOR,
            `with token: ${args.changeListenerToken}`,
            `token=${args.changeListenerToken}`
          );
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this._replicatorDocumentChangeListeners.delete(
            args.changeListenerToken
          );
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.replicatorDocumentChange,
            this._replicatorDocumentChangeListeners
          );
          this.logOpError(
            'replicator_AddDocumentChangeListener',
            error,
            LogDomain.REPLICATOR,
            `token=${args.changeListenerToken}`
          );
          reject(error);
        }
      );
    });
  }

  replicator_RemoveChangeListener(
    args: ReplicationChangeListenerArgs
  ): Promise<void> {
    const token = args.changeListenerToken;
    const isStatusListener = this._replicatorChangeListeners.has(token);
    const isDocumentListener =
      this._replicatorDocumentChangeListeners.has(token);

    if (!isStatusListener && !isDocumentListener) {
      this.logOpWarn(
        'replicator_RemoveChangeListener',
        'no listener for token',
        LogDomain.REPLICATOR,
        `token=${token}`
      );
      return Promise.reject(
        new Error(`No replicator listener found with token: ${token}`)
      );
    }

    this.logOpStart(
      'replicator_RemoveChangeListener',
      LogDomain.REPLICATOR,
      `token: ${token}`,
      `token=${token}, kind=${isStatusListener ? 'status' : 'document'}`
    );

    // Symmetry contract: a token is owned by exactly one of the two maps
    // (status XOR document). Only touch the map that actually owns it, and
    // only re-evaluate idleness for the event source we just unsubscribed
    // from. Tokens are UUIDs today so cross-map collisions are practically
    // impossible, but encoding ownership here prevents a future change that
    // reuses tokens across listener kinds from silently tearing down both
    // registrations on a single remove call.
    const owningMaps: Array<Map<string, ListenerCallback>> = isStatusListener
      ? [this._replicatorChangeListeners]
      : [this._replicatorDocumentChangeListeners];

    return this._removeListenerTokenAfterNativeSuccess(
      token,
      () =>
        NativeCblReplicator.replicator_RemoveChangeListener(
          token,
          args.replicatorId
        ),
      owningMaps,
      () => {
        if (isStatusListener) {
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.replicatorStatusChange,
            this._replicatorChangeListeners
          );
        } else {
          this._removeEventSubscriptionIfIdle(
            ENGINE_EVENTS.replicatorDocumentChange,
            this._replicatorDocumentChangeListeners
          );
        }
      }
    ).then(
      () => {
        this.logOpDone(
          'replicator_RemoveChangeListener',
          LogDomain.REPLICATOR,
          `for token: ${token}`,
          `token=${token}`
        );
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error: any) => {
        this.logOpError(
          'replicator_RemoveChangeListener',
          error,
          LogDomain.REPLICATOR,
          `token=${token}`
        );
        throw error;
      }
    );
  }

  // ─── NativeCblScope ───────────────────────────────────────────────────────

  scope_GetDefault(args: DatabaseArgs): Promise<NativeScopeResult> {
    this.logOpStart(
      'scope_GetDefault',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblScope.scope_GetDefault(args.databaseUniqueName).then(
        (result) => {
          this.logOpDone('scope_GetDefault', LogDomain.DATABASE);
          resolve(result as unknown as NativeScopeResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'scope_GetDefault',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  scope_GetScope(args: ScopeArgs): Promise<NativeScopeResult> {
    this.logOpStart(
      'scope_GetScope',
      LogDomain.DATABASE,
      `${args.databaseUniqueName} ${args.scopeName}`,
      `name=${args.databaseUniqueName}, scope=${args.scopeName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblScope.scope_GetScope(
        args.databaseUniqueName,
        args.scopeName
      ).then(
        (result) => {
          this.logOpDone(
            'scope_GetScope',
            LogDomain.DATABASE,
            '',
            `scope=${args.scopeName}, found=${result != null}`
          );
          resolve(result as unknown as NativeScopeResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'scope_GetScope',
            error,
            LogDomain.DATABASE,
            `scope=${args.scopeName}`
          );
          reject(error);
        }
      );
    });
  }

  scope_GetScopes(args: DatabaseArgs): Promise<ScopesResult> {
    this.logOpStart(
      'scope_GetScopes',
      LogDomain.DATABASE,
      args.databaseUniqueName,
      `name=${args.databaseUniqueName}`
    );
    return new Promise((resolve, reject) => {
      NativeCblScope.scope_GetScopes(args.databaseUniqueName).then(
        (result) => {
          const scopes = (result as unknown as ScopesResult)?.scopes;
          const count = Array.isArray(scopes) ? scopes.length : undefined;
          this.logOpDone(
            'scope_GetScopes',
            LogDomain.DATABASE,
            '',
            count !== undefined ? `count=${count}` : ''
          );
          resolve(result as unknown as ScopesResult);
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'scope_GetScopes',
            error,
            LogDomain.DATABASE,
            `name=${args.databaseUniqueName}`
          );
          reject(error);
        }
      );
    });
  }

  // ─── NativeCblLogging ─────────────────────────────────────────────────────

  database_SetLogLevel(args: DatabaseSetLogLevelArgs): Promise<void> {
    return new Promise((resolve, reject) => {
      NativeCblLogging.database_SetLogLevel(args.domain, args.logLevel).then(
        () => resolve(),
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          reject(error);
        }
      );
    });
  }

  database_SetFileLoggingConfig(
    args: DatabaseSetFileLoggingConfigArgs
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      // Spec requires non-null args; config fields are optional on the JS type.
      NativeCblLogging.database_SetFileLoggingConfig(
        args.databaseUniqueName,
        args.config.directory,
        args.config.level,
        args.config.maxSize ?? 0,
        args.config.maxRotateCount ?? 0,
        args.config.usePlaintext ?? false
      ).then(
        () => {
          // The legacy file-logging API delegates to the same LogSinksManager
          // file sink internally, so it must enable file-forwarding state too.
          this._fileSinkLevel = args.config.level;
          resolve();
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          reject(error);
        }
      );
    });
  }

  /**
   * Sets or disables the console log sink
   * @param args Arguments containing level and domains, or null to disable
   */
  async logsinks_SetConsole(args: LogSinksSetConsoleArgs): Promise<void> {
    return NativeCblLogging.logsinks_SetConsole(args.level, args.domains);
  }

  /**
   * Sets or disables the file log sink
   * @param args Arguments containing level and config, or null to disable
   */
  async logsinks_SetFile(args: LogSinksSetFileArgs): Promise<void> {
    await NativeCblLogging.logsinks_SetFile(args.level, args.config);
    // Update forwarding state only after native confirms. -1 = disable.
    this._fileSinkLevel = args.level === -1 ? null : args.level;
  }

  /**
   * Sets or disables the custom log sink
   * @param args Arguments containing level, domains, and token, or null to disable
   */
  async logsinks_SetCustom(args: LogSinksSetCustomArgs): Promise<void> {
    await NativeCblLogging.logsinks_SetCustom(
      args.level,
      args.domains,
      args.token
    );
    // Update forwarding state only after native confirms. -1 = disable.
    this._customSinkLevel = args.level === -1 ? null : args.level;
  }

  /**
   * Writes a single log message into the CBL logging pipeline (file + console +
   * custom). Public-facing validation (level/domain scope) happens in
   * LogSinks.write; here we only enforce the custom-sink recursion guard before
   * crossing the bridge.
   */
  logging_WriteLog(
    level: LogLevel,
    domain: LogDomain,
    message: string
  ): Promise<void> {
    // A synchronous write from inside a custom-sink callback would feed CBL's
    // own log output back into CBL logging and loop. Reject it.
    if (this._isDispatchingCustomLogCallback) {
      return Promise.reject(
        new Error(
          'LogSinks.write must not be called synchronously from within a custom log sink callback'
        )
      );
    }
    return NativeCblLogging.logging_WriteLog(
      Number(level),
      String(domain),
      message
    );
  }

  // ─── NativeCblEngine ──────────────────────────────────────────────────────

  file_GetDefaultPath(): Promise<{ path: string }> {
    this.logOpStart('file_GetDefaultPath', LogDomain.DATABASE);
    return new Promise((resolve, reject) => {
      NativeCblEngine.file_GetDefaultPath().then(
        (result: string) => {
          // The resolved path is never forwarded.
          this.logOpDone('file_GetDefaultPath', LogDomain.DATABASE, result);
          resolve({ path: result });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError('file_GetDefaultPath', error, LogDomain.DATABASE);
          reject(error);
        }
      );
    });
  }

  file_GetFileNamesInDirectory(args: {
    path: string;
  }): Promise<{ files: string[] }> {
    // The directory path is never forwarded; only a redaction marker + count.
    this.logOpStart(
      'file_GetFileNamesInDirectory',
      LogDomain.DATABASE,
      args.path,
      `directory=<redacted>`
    );
    return new Promise((resolve, reject) => {
      NativeCblEngine.file_GetFileNamesInDirectory(args.path).then(
        (result) => {
          const files = (result as { files?: string[] })?.files;
          const count = Array.isArray(files) ? files.length : undefined;
          this.logOpDone(
            'file_GetFileNamesInDirectory',
            LogDomain.DATABASE,
            '',
            count !== undefined ? `count=${count}` : ''
          );
          resolve(result as unknown as { files: string[] });
        },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (error: any) => {
          this.logOpError(
            'file_GetFileNamesInDirectory',
            error,
            LogDomain.DATABASE
          );
          reject(error);
        }
      );
    });
  }

  /**
   * Generic method to remove any listener by its UUID token.
   * Calls the native listenerToken_Remove method via NativeCblEngine.
   */
  listenerToken_Remove(args: { changeListenerToken: string }): Promise<void> {
    return NativeCblEngine.listenerToken_Remove(args.changeListenerToken).then(
      () => {
        const token = args.changeListenerToken;
        this._emitterSubscriptions.get(token)?.remove();
        this._emitterSubscriptions.delete(token);
        this._collectionChangeListeners.delete(token);
        this._collectionDocumentChangeListeners.delete(token);
        this._queryChangeListeners.delete(token);
        this._replicatorChangeListeners.delete(token);
        this._replicatorDocumentChangeListeners.delete(token);
        // Custom log tokens aren't in ListenerTokenStore; cleared via logsinks_SetCustom.
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.collectionChange,
          this._collectionChangeListeners
        );
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.collectionDocumentChange,
          this._collectionDocumentChangeListeners
        );
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.queryChange,
          this._queryChangeListeners
        );
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.replicatorStatusChange,
          this._replicatorChangeListeners
        );
        this._removeEventSubscriptionIfIdle(
          ENGINE_EVENTS.replicatorDocumentChange,
          this._replicatorDocumentChangeListeners
        );

        this.logOpDone(
          'listenerToken_Remove',
          LogDomain.LISTENER,
          `token ${token}`,
          `token=${token}`
        );
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (error: any) => {
        this.logOpError(
          'listenerToken_Remove',
          error,
          LogDomain.LISTENER,
          `token=${args.changeListenerToken}`
        );
        throw error;
      }
    );
  }

  // ─── URLEndpointListener (not yet implemented) ────────────────────────────

  URLEndpointListener_createListener(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    args: URLEndpointListenerCreateArgs
  ): Promise<{ listenerId: string }> {
    return Promise.reject(new Error('URLEndpointListener not implemented yet'));
  }

  URLEndpointListener_startListener(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    args: URLEndpointListenerArgs
  ): Promise<void> {
    return Promise.reject(new Error('URLEndpointListener not implemented yet'));
  }

  URLEndpointListener_stopListener(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    args: URLEndpointListenerArgs
  ): Promise<void> {
    return Promise.reject(new Error('URLEndpointListener not implemented yet'));
  }

  URLEndpointListener_getStatus(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    args: URLEndpointListenerArgs
  ): Promise<URLEndpointListenerStatus> {
    return Promise.reject(new Error('URLEndpointListener not implemented yet'));
  }

  URLEndpointListener_deleteIdentity(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    args: URLEndpointListenerTLSIdentityArgs
  ): Promise<void> {
    return Promise.reject(new Error('URLEndpointListener not implemented yet'));
  }

  getUUID(): string {
    return uuid.v4().toString();
  }

  /**
   * Tears down all engine-owned native subscriptions and clears in-memory state.
   *
   * Safe to call multiple times. After dispose() the engine instance should be
   * considered unusable; create a new one (and re-register via EngineLocator)
   * to resume work.
   *
   * Today this is only useful in:
   *   - Jest tests that want to assert subscriptions are released.
   *   - Hot-reload scenarios in dev where the JS bundle is replaced but the
   *     native side keeps the previous subscription alive.
   */
  dispose(): void {
    // _customLogSubscription is the same handle that _ensureEventSubscription
    // stored into _sharedEventSubscriptions, so the loop below already removes
    // it. We just need to drop our private reference and clear the callback map.
    this._customLogSubscription = undefined;
    this.customLogCallbacksMap.clear();

    // Reset internal-log forwarding state so a disposed engine never forwards.
    this._fileSinkLevel = null;
    this._customSinkLevel = null;
    this._isDispatchingCustomLogCallback = false;

    this._sharedEventSubscriptions.forEach((sub) => sub.remove());
    this._sharedEventSubscriptions.clear();

    this._emitterSubscriptions.forEach((sub) => sub.remove());
    this._emitterSubscriptions.clear();

    this._collectionChangeListeners.clear();
    this._collectionDocumentChangeListeners.clear();
    this._queryChangeListeners.clear();
    this._replicatorChangeListeners.clear();
    this._replicatorDocumentChangeListeners.clear();
  }
}
