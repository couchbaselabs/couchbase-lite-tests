/* eslint-disable @typescript-eslint/ban-types */
import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

export interface Spec extends TurboModule {
  scope_GetDefault(databaseUniqueName: string): Promise<Object>;

  scope_GetScope(
    databaseUniqueName: string,
    scopeName: string
  ): Promise<Object>;

  scope_GetScopes(databaseUniqueName: string): Promise<Object>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('CblScope');
