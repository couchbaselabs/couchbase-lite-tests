/* eslint-disable @typescript-eslint/ban-types */
import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
import { TurboModuleRegistry } from 'react-native';

export type QueryChangeEvent = {
  token: string;
  data?: string;
  error?: string;
};

export interface Spec extends TurboModule {
  readonly queryChange: EventEmitter<QueryChangeEvent>;

  query_Execute(
    databaseUniqueName: string,
    queryId: string,
    query: string,
    parameters: Object
  ): Promise<Object>;

  query_Explain(
    databaseUniqueName: string,
    queryId: string,
    query: string,
    parameters: Object
  ): Promise<Object>;

  query_AddChangeListener(
    databaseUniqueName: string,
    queryId: string,
    query: string,
    parameters: Object,
    changeListenerToken: string
  ): Promise<void>;

  query_RemoveChangeListener(changeListenerToken: string): Promise<void>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('CblQuery');
