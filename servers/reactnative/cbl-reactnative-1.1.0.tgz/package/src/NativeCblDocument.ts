/* eslint-disable @typescript-eslint/ban-types */
import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

export type DocumentExpirationResult = {
  date: string;
};

export interface Spec extends TurboModule {
  collection_GetDocument(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string
  ): Promise<Object>;

  collection_Save(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string,
    document: string,
    blobs: string,
    concurrencyControlValue: number
  ): Promise<Object>;

  collection_DeleteDocument(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string,
    concurrencyControl: number
  ): Promise<Object>;

  collection_PurgeDocument(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string
  ): Promise<void>;

  collection_GetDocumentExpiration(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string
  ): Promise<DocumentExpirationResult | null>;

  collection_SetDocumentExpiration(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    docId: string,
    expiration: string | null
  ): Promise<void>;

  collection_GetBlobContent(
    databaseUniqueName: string,
    collectionName: string,
    scopeName: string,
    documentId: string,
    key: string
  ): Promise<Object>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('CblDocument');
