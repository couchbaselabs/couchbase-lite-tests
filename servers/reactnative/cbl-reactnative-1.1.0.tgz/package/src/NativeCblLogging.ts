/* eslint-disable @typescript-eslint/ban-types */
import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
import { TurboModuleRegistry } from 'react-native';

export type CustomLogMessageEvent = {
  token: string;
  level: number;
  domain: string;
  message: string;
};

export interface Spec extends TurboModule {
  readonly customLogMessage: EventEmitter<CustomLogMessageEvent>;

  // Legacy logging API
  database_SetLogLevel(domain: string, logLevel: number): Promise<void>;

  database_SetFileLoggingConfig(
    name: string,
    directory: string,
    logLevel: number,
    maxSize: number,
    maxRotateCount: number,
    shouldUsePlainText: boolean
  ): Promise<void>;

  // New LogSinks API
  logsinks_SetConsole(level: number, domains: string[]): Promise<void>;

  logsinks_SetFile(level: number, config: Object): Promise<void>;

  logsinks_SetCustom(
    level: number,
    domains: string[],
    token: string
  ): Promise<void>;

  // Writes one log line into the CBL logging pipeline (file + console + custom).
  // `domain` is kept as a string for consistency with logsinks_SetConsole and
  // the customLogMessage payload, which already use string domain names.
  logging_WriteLog(
    level: number,
    domain: string,
    message: string
  ): Promise<void>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('CblLogging');
