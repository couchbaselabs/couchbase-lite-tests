/* eslint-disable @typescript-eslint/ban-types */
import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
import { TurboModuleRegistry } from 'react-native';

/** Native replicatorStatusChange payload (activityLevel is ReplicatorActivityLevel ordinal). */
export type ReplicatorStatusChangeEvent = {
  token: string;
  status?: {
    activityLevel: number;
    progress: { completed: number; total: number };
    error?: { message: string };
  };
  error?: Object;
};

export type ReplicatorDocumentChangeEvent = {
  token: string;
  documents?: Object;
  error?: Object;
};

export interface Spec extends TurboModule {
  readonly replicatorStatusChange: EventEmitter<ReplicatorStatusChangeEvent>;
  readonly replicatorDocumentChange: EventEmitter<ReplicatorDocumentChangeEvent>;

  replicator_Create(config: Object): Promise<Object>;

  replicator_Start(replicatorId: string): Promise<void>;

  replicator_Stop(replicatorId: string): Promise<void>;

  replicator_Cleanup(replicatorId: string): Promise<void>;

  replicator_GetStatus(replicatorId: string): Promise<Object>;

  replicator_ResetCheckpoint(replicatorId: string): Promise<void>;

  replicator_GetPendingDocumentIds(
    databaseUniqueName: string,
    replicatorId: string,
    collectionName: string,
    scopeName: string
  ): Promise<Object>;

  replicator_IsDocumentPending(
    databaseUniqueName: string,
    replicatorId: string,
    collectionName: string,
    scopeName: string,
    documentId: string
  ): Promise<Object>;

  replicator_AddChangeListener(
    changeListenerToken: string,
    replicatorId: string
  ): Promise<void>;

  replicator_AddDocumentChangeListener(
    changeListenerToken: string,
    replicatorId: string
  ): Promise<void>;

  replicator_RemoveChangeListener(
    changeListenerToken: string,
    replicatorId: string
  ): Promise<void>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('CblReplicator');
