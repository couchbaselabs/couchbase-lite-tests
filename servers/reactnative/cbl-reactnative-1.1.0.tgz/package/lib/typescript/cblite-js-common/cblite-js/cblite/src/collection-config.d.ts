/**
 * **[DEPRECATED - Use CollectionConfiguration instead]**
 *
 * Configuration for collection replication (OLD API).
 * This class allows multiple collections to share the same replication configuration.
 *
 * **Migration Guide:**
 * ```typescript
 * // OLD API (still works):
 * const config = new CollectionConfig();
 * config.setChannels(['public']);
 * replConfig.addCollections([collection1, collection2], config);
 *
 * // NEW API (recommended):
 * const config1 = new CollectionConfiguration(collection1).setChannels(['public']);
 * const config2 = new CollectionConfiguration(collection2).setChannels(['public']);
 * const replConfig = new ReplicatorConfiguration([config1, config2], endpoint);
 * ```
 *
 * @deprecated Use {@link CollectionConfiguration} instead for better type safety and clarity.
 */
export declare class CollectionConfig {
    private channels;
    private documentIDs;
    private pullFilter;
    private pushFilter;
    constructor();
    /**
     * Gets the list of Sync Gateway channel names to pull from.
     *
     * @returns Array of channel names
     * @deprecated Use {@link CollectionConfiguration.getChannels} instead
     */
    getChannels(): string[];
    /**
     * Gets the list of document IDs to replicate.
     *
     * @returns Array of document IDs
     * @deprecated Use {@link CollectionConfiguration.getDocumentIDs} instead
     */
    getDocumentIDs(): string[];
    /**
     * Gets the pull replication filter function.
     *
     * @returns The pull filter function as a string
     * @deprecated Use {@link CollectionConfiguration.getPullFilter} instead
     */
    getPullFilter(): string;
    /**
     * Gets the push replication filter function.
     *
     * @returns The push filter function as a string
     * @deprecated Use {@link CollectionConfiguration.getPushFilter} instead
     */
    getPushFilter(): string;
    /**
     * Sets the list of Sync Gateway channel names to pull from.
     *
     * @param channels - Array of channel names
     * @deprecated Use {@link CollectionConfiguration.setChannels} instead
     */
    setChannels(channels: string[]): void;
    /**
     * Sets the list of document IDs to replicate.
     *
     * @param documentIDs - Array of document IDs
     * @deprecated Use {@link CollectionConfiguration.setDocumentIDs} instead
     */
    setDocumentIDs(documentIDs: string[]): void;
    /**
     * Sets the pull replication filter.
     *
     * The filter is serialized to source and re-evaluated in a separate JS engine on the
     * native side, so it must be self-contained (no closure variables). Throws immediately
     * if the filter cannot be serialized to usable source (e.g. a Hermes `[bytecode]`
     * placeholder in a release build) rather than silently dropping documents.
     *
     * @param pullFilter - Filter function (or function-source string) for pull replication
     * @throws Error if the filter cannot be serialized to a usable source string
     * @deprecated Use {@link CollectionConfiguration.setPullFilter} instead
     */
    setPullFilter(pullFilter: ((document: any, flags: string[]) => boolean) | string): void;
    /**
     * Sets the push replication filter.
     *
     * The filter is serialized to source and re-evaluated in a separate JS engine on the
     * native side, so it must be self-contained (no closure variables). Throws immediately
     * if the filter cannot be serialized to usable source (e.g. a Hermes `[bytecode]`
     * placeholder in a release build) rather than silently dropping documents.
     *
     * @param pushFilter - Filter function (or function-source string) for push replication
     * @throws Error if the filter cannot be serialized to a usable source string
     * @deprecated Use {@link CollectionConfiguration.setPushFilter} instead
     */
    setPushFilter(pushFilter: ((document: any, flags: string[]) => boolean) | string): void;
    /**
     * Converts this config to JSON for the native layer.
     *
     * @returns JSON object
     * @internal
     */
    toJson(): any;
}
//# sourceMappingURL=collection-config.d.ts.map