/**
 * Utilities for safely serializing replication push/pull filter functions before
 * they are sent across the React Native bridge and re-evaluated inside a separate
 * JavaScript engine (JavaScriptCore on iOS, V8 on Android) on the native side.
 *
 * Replication filters are captured as source text via `Function.prototype.toString()`.
 * That mechanism has well known, *silent* failure modes that all manifest as "don't
 * replicate this document" with no error surfaced to the JS caller, causing hard to
 * debug replication data loss. This module guards against them by failing loudly at
 * configuration time instead:
 *
 * 1. **Hermes bytecode placeholder (the production killer).** Hermes — the default
 *    React Native engine — compiles JavaScript to bytecode and discards the original
 *    source in release builds. `Function.prototype.toString()` then returns a
 *    `function () { [bytecode] }` placeholder rather than the real source. Sending that
 *    to the native engine is a syntax error that gets coerced to "reject the document",
 *    so *every* document is silently dropped in production. See
 *    https://github.com/facebook/hermes/issues/114.
 * 2. **Empty / non-function source.** Likewise produces a filter that rejects everything.
 *
 * It also documents the hard constraint that filters MUST be self-contained: because
 * only the function body survives `toString()`, any closure variable the filter relied
 * on is `undefined` on the native side and the filter throws (again coerced to "drop").
 */
/**
 * Accepted input for a replication filter: either a live function (serialized via
 * `toString()`) or an explicit function-source string. Passing an explicit string is
 * the recommended escape hatch when running under Hermes without a `'show source'`
 * directive, since it avoids relying on `Function.prototype.toString()` entirely.
 */
export type ReplicationFilterInput = ((document: any, flags: string[]) => boolean) | string;
/**
 * Serializes and validates a replication filter, throwing a descriptive error rather
 * than allowing a broken filter to silently drop documents during replication.
 *
 * @param filter - The filter function or its source string.
 * @param kind - "push" or "pull", used only for clearer error messages.
 * @returns The validated filter source string to send to the native layer.
 * @throws Error if the filter is missing, empty, not serializable to source, or was
 *   stripped to a Hermes/native bytecode placeholder.
 */
export declare function serializeReplicationFilter(filter: ReplicationFilterInput, kind: 'push' | 'pull'): string;
//# sourceMappingURL=replication-filter-utils.d.ts.map