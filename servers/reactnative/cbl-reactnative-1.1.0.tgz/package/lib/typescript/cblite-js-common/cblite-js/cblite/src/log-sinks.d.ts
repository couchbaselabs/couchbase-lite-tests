import { LogLevel, LogDomain } from './log-sinks-enums';
import type { ConsoleLogSinkConfig, FileLogSinkConfig, CustomLogSinkConfig } from './log-sinks-types';
/**
 * LogSinks provides methods to configure logging in Couchbase Lite.
 * You can configure console logging, file logging, and custom logging.
 */
export declare class LogSinks {
    private static currentCustomToken;
    /**
     * Lazily retrieves the engine instance at runtime to ensure it's initialized
     */
    private static get _engine();
    /**
     * Sets or disables console logging
     * @param config Configuration for console logging, or null to disable
     * @example
     * // Enable console logging
     * await LogSinks.setConsole({
     *   level: LogLevel.INFO,
     *   domains: [LogDomain.DATABASE, LogDomain.QUERY]
     * });
     *
     * // Disable console logging
     * await LogSinks.setConsole(null);
     */
    static setConsole(config: ConsoleLogSinkConfig | null): Promise<void>;
    /**
     * Sets or disables file logging
     * @param config Configuration for file logging, or null to disable
     * @example
     * // Enable file logging
     * await LogSinks.setFile({
     *   level: LogLevel.DEBUG,
     *   directory: '/path/to/logs',
     *   usePlaintext: true,
     *   maxFileSize: 1024 * 1024, // 1MB
     *   maxKeptFiles: 5
     * });
     *
     * // Disable file logging
     * await LogSinks.setFile(null);
     */
    static setFile(config: FileLogSinkConfig | null): Promise<void>;
    /**
     * Sets or disables custom logging with a callback
     *
     * IMPORTANT: the callback is invoked on Couchbase Lite's logging path, once per
     * log line at/above the configured level. Keep it lightweight and non-blocking,
     * and do NOT log through Couchbase Lite from inside it — doing so can create a
     * feedback loop. Under verbose domains (e.g. ALL at DEBUG during replication) it
     * can fire at high frequency, so avoid heavy work or synchronous I/O.
     *
     * @param config Configuration for custom logging, or null to disable
     * @example
     * // Enable custom logging
     * await LogSinks.setCustom({
     *   level: LogLevel.VERBOSE,
     *   domains: [LogDomain.REPLICATOR, LogDomain.NETWORK],
     *   callback: (level, domain, message) => {
     *     console.log(`[${domain}] ${message}`);
     *   }
     * });
     *
     * // Disable custom logging
     * await LogSinks.setCustom(null);
     */
    /**
     * The log domains that are valid targets for {@link LogSinks.write}.
     *
     * A single log line has exactly one concrete domain, so `ALL` (a filter
     * concept) is NOT accepted here.
     */
    private static readonly WRITE_DOMAINS;
    /**
     * Writes a single log message into the Couchbase Lite logging pipeline so it
     * is delivered to every configured sink — file, console, and custom — exactly
     * like a native SDK platform log line (with CBL's own timestamp/level/domain
     * formatting).
     *
     * If no sink is configured the call still succeeds but the message goes
     * nowhere, so configure {@link LogSinks.setFile} (and/or console/custom)
     * first.
     *
     * IMPORTANT: do NOT call `write` synchronously from inside a custom log sink
     * callback — that would feed CBL's own log output back into CBL logging and
     * loop. Such a call is rejected. Scheduling a delayed write (via setTimeout,
     * a promise, etc.) from a custom-sink callback is likewise prohibited; the
     * runtime guard cannot detect it, so it is the caller's responsibility.
     *
     * @param level   Severity, DEBUG(0) through ERROR(4). NONE and out-of-range
     *                values are rejected — `write` has no "disable" concept.
     * @param domain  One of DATABASE, QUERY, REPLICATOR, NETWORK, LISTENER.
     *                ALL is rejected.
     * @param message The message to log.
     *
     * @example
     * await LogSinks.write(LogLevel.WARNING, LogDomain.DATABASE, 'sync retry #3 failed');
     */
    static write(level: LogLevel, domain: LogDomain, message: string): Promise<void>;
    static setCustom(config: CustomLogSinkConfig | null): Promise<void>;
}
//# sourceMappingURL=log-sinks.d.ts.map