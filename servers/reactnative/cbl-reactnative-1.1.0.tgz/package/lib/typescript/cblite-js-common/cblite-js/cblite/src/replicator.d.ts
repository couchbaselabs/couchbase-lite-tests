import { ReplicatorConfiguration } from './replicator-configuration';
import { ReplicatorChangeListener, ReplicatorDocumentChangeListener } from '../core-types';
import { ReplicatorStatus } from './replicator-status';
import { Collection } from './collection';
import { ListenerToken } from './listener-token';
/**
 * Manages replication of data between a local database and a remote endpoint.
 *
 * **Lifecycle:** `Replicator.create(config)` → {@link start} → {@link stop} → {@link cleanup}.
 *
 * {@link stop} only halts replication and leaves the replicator **resumable** (listeners stay
 * attached, the native object stays alive), so you can call {@link start} again. When you are
 * permanently finished, you **must** call {@link cleanup} to remove all listeners and free native
 * resources — `stop()` alone does not do this, and skipping `cleanup()` leaks listeners/native
 * objects and lets callbacks keep firing.
 */
export declare class Replicator {
    private _replicatorId;
    private status;
    private readonly _config;
    private _engine;
    private _statusChangeListeners;
    private _documentChangeListener;
    private _replicatorListenerTokensByUuid;
    private _replicatorDocListenerTokensByUuid;
    /**
     * Initializes a replicator with the given configuration
     *
     * @param config
     */
    private constructor();
    /**
     * Adds a replicator change listener for listening to status updates
     *
     * @function
     *
     */
    addChangeListener(listener: ReplicatorChangeListener): Promise<ListenerToken>;
    addDocumentChangeListener(listener: ReplicatorDocumentChangeListener): Promise<ListenerToken>;
    /**
   * Creates a new Replicator instance for database synchronization
   * @param {ReplicatorConfiguration} config - The configuration for the replicator
   * @returns {Promise<Replicator>} A Promise that resolves to a new Replicator instance
   * @throws {Error} If the configuration is invalid or required parameters are missing
   */
    static create(config: ReplicatorConfiguration): Promise<Replicator>;
    /**
     * Tears down the replicator: stops it, removes **all** of its change/document listeners, and
     * removes the underlying native replicator from the engine's registry (on Android this also
     * releases the per-thread JavaScript runtime and compiled push/pull filters).
     *
     * **This is the required teardown step and must be called when you are done with a replicator**
     * (typically after {@link stop}). {@link stop} on its own keeps the replicator resumable and
     * leaves listeners attached, so skipping `cleanup()` leaks listeners and native objects and lets
     * status/document callbacks keep arriving.
     *
     * After `cleanup()` the replicator id is released; calling {@link start} again will create a new
     * native replicator with a new id.
     *
     * @function
     * @see {@link stop}
     */
    cleanup(): Promise<void>;
    /**
     * returns the replicator id used to manage the replicator between the engine and the
     * replicator native implementation.  This value should get set when the replicator is
     * created in the native engine via the start method.
     *
     * @function
     */
    getId(): string | undefined;
    /**
     * returns a copy of the replicators current configuration.
     * @function
     */
    getConfiguration(): ReplicatorConfiguration;
    /**
     * returns the replicators current status: its activity level and progress.
     *
     * @function
     */
    getStatus(): Promise<ReplicatorStatus>;
    /**
     * Get pending document ids for the given collection. If the given collection is not part of the replication, an error will be thrown.
     *
     * @function
     */
    getPendingDocumentIds(collection: Collection): Promise<{
        pendingDocumentIds: string[];
    }>;
    /**
     * Check whether the document in the given collection is pending to push or not. If the given collection is not part of the replicator, an Exception will be thrown.
     *
     * @function
     */
    isDocumentPending(documentId: string, collection: Collection): Promise<{
        isPending: boolean;
    }>;
    private notifyDocumentChange;
    private buildStatusChange;
    /**
     * Removes a change listener with the given listener token.
     *
     * @function
     */
    removeChangeListener(token: string | ListenerToken): Promise<void>;
    /**
     * Starts the replicator with an option to reset the local checkpoint of the replicator. When the
     * local checkpoint is reset, the replicator will sync all changes since the beginning of time from
     * the remote database.
     *
     * This method returns immediately; the replicator runs asynchronously and will report its progress
     * through the replicator change notification.
     *
     * @function
     *
     * @param {boolean} reset Resets the local checkpoint before starting the replicator.
     */
    start(reset: boolean | undefined): Promise<void>;
    /**
     * Stops a running replicator. This method returns immediately; when the replicator actually
     * stops, the replicator will change its status's activity level to
     * `ReplicatorActivityLevel.STOPPED` and the replicator change notification will be notified
     * accordingly.
     *
     * **Important — `stop()` is not teardown.** Stopping only halts replication; it intentionally
     * leaves the replicator **resumable** (you may call {@link start} again on this same instance)
     * and therefore keeps your change/document listeners attached (so you can still observe the
     * `STOPPED` transition and later restarts). Because of that, `stop()` alone does **not** release
     * resources: the native replicator stays registered and your listeners stay subscribed (on
     * Android this also retains the per-thread JavaScript runtime used for push/pull filters).
     *
     * When you are permanently done with this replicator, you **must** call {@link cleanup} (after
     * `stop()`) to remove all listeners and free the native object. Failing to call {@link cleanup}
     * leaks listeners and native objects and lets status/document callbacks keep arriving.
     *
     * @function
     * @see {@link cleanup}
     */
    stop(): Promise<void>;
}
//# sourceMappingURL=replicator.d.ts.map