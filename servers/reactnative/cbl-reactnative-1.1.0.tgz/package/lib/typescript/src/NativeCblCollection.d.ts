import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
export type CollectionMap = {
    databaseUniqueName: string;
    scope: string;
    collection: string;
};
export type CollectionChangeEvent = {
    token: string;
    documentIDs: string[];
    collection: CollectionMap;
};
export type CollectionDocumentChangeEvent = {
    token: string;
    documentId: string;
    database: string;
    collection: CollectionMap;
};
export interface Spec extends TurboModule {
    readonly collectionChange: EventEmitter<CollectionChangeEvent>;
    readonly collectionDocumentChange: EventEmitter<CollectionDocumentChangeEvent>;
    collection_CreateCollection(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<Object>;
    collection_DeleteCollection(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<void>;
    collection_GetCollection(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<Object>;
    collection_GetCollections(databaseUniqueName: string, scopeName: string): Promise<Object>;
    collection_GetDefault(databaseUniqueName: string): Promise<Object>;
    collection_GetCount(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<Object>;
    collection_GetFullName(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<Object>;
    collection_CreateIndex(databaseUniqueName: string, collectionName: string, scopeName: string, indexName: string, index: Object): Promise<void>;
    collection_DeleteIndex(databaseUniqueName: string, collectionName: string, scopeName: string, indexName: string): Promise<void>;
    collection_GetIndexes(databaseUniqueName: string, collectionName: string, scopeName: string): Promise<Object>;
    collection_AddChangeListener(databaseUniqueName: string, collectionName: string, scopeName: string, changeListenerToken: string): Promise<void>;
    collection_AddDocumentChangeListener(databaseUniqueName: string, collectionName: string, scopeName: string, docId: string, changeListenerToken: string): Promise<void>;
    collection_RemoveChangeListener(changeListenerToken: string): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCblCollection.d.ts.map