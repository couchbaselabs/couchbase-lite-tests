import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
export type CustomLogMessageEvent = {
    token: string;
    level: number;
    domain: string;
    message: string;
};
export interface Spec extends TurboModule {
    readonly customLogMessage: EventEmitter<CustomLogMessageEvent>;
    database_SetLogLevel(domain: string, logLevel: number): Promise<void>;
    database_SetFileLoggingConfig(name: string, directory: string, logLevel: number, maxSize: number, maxRotateCount: number, shouldUsePlainText: boolean): Promise<void>;
    logsinks_SetConsole(level: number, domains: string[]): Promise<void>;
    logsinks_SetFile(level: number, config: Object): Promise<void>;
    logsinks_SetCustom(level: number, domains: string[], token: string): Promise<void>;
    logging_WriteLog(level: number, domain: string, message: string): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCblLogging.d.ts.map