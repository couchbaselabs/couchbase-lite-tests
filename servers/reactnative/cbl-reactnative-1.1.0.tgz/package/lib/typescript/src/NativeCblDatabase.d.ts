import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    database_Open(databaseName: string, directory: string | null, encryptionKey: string | null): Promise<Object>;
    database_Close(databaseUniqueName: string): Promise<void>;
    database_Delete(databaseUniqueName: string): Promise<void>;
    database_DeleteWithPath(path: string, databaseName: string): Promise<void>;
    database_Copy(path: string, newDatabaseName: string, directory: string | null, encryptionKey: string | null): Promise<void>;
    database_Exists(databaseName: string, directory: string): Promise<boolean>;
    database_GetPath(databaseUniqueName: string): Promise<string>;
    database_PerformMaintenance(databaseUniqueName: string, maintenanceType: number): Promise<void>;
    database_ChangeEncryptionKey(databaseUniqueName: string, newKey: string | null): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCblDatabase.d.ts.map