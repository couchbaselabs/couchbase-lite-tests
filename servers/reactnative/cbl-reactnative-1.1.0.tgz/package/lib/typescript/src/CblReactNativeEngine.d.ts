import { CollectionChangeListenerArgs, ICoreEngine, ListenerCallback, CollectionArgs, CollectionCreateIndexArgs, CollectionDeleteDocumentArgs, CollectionDeleteIndexArgs, CollectionDocumentExpirationArgs, CollectionDocumentGetBlobContentArgs, CollectionDocumentSaveResult, CollectionGetDocumentArgs, CollectionPurgeDocumentArgs, CollectionSaveStringArgs, CollectionsResult, DatabaseArgs, DatabaseCopyArgs, DatabaseCreateIndexArgs, DatabaseDeleteDocumentArgs, DatabaseDeleteIndexArgs, DatabaseEncryptionKeyArgs, DatabaseExistsArgs, DatabaseGetDocumentArgs, DatabaseOpenArgs, DatabasePerformMaintenanceArgs, DatabasePurgeDocumentArgs, DatabaseSaveArgs, DatabaseSetFileLoggingConfigArgs, DatabaseSetLogLevelArgs, DocumentChangeListenerArgs, DocumentExpirationResult, DocumentResult, QueryChangeListenerArgs, QueryExecuteArgs, QueryRemoveChangeListenerArgs, ReplicationChangeListenerArgs, ReplicatorArgs, ReplicatorCollectionArgs, ReplicatorCreateArgs, ReplicatorDocumentPendingArgs, ScopeArgs, ScopesResult, NativeCollectionResult, NativeScopeResult, DocumentGetBlobContentArgs, URLEndpointListenerCreateArgs, URLEndpointListenerArgs, URLEndpointListenerTLSIdentityArgs, URLEndpointListenerStatus } from './cblite-js/cblite/core-types';
import { Result } from './cblite-js/cblite/src/result';
import { ReplicatorStatus } from './cblite-js/cblite/src/replicator-status';
import { LogLevel, LogDomain } from './cblite-js/cblite/src/log-sinks-enums';
import type { LogSinksSetConsoleArgs, LogSinksSetFileArgs, LogSinksSetCustomArgs } from './cblite-js/cblite/src/log-sinks-types';
import type { CollectionChangeEvent, CollectionDocumentChangeEvent } from './NativeCblCollection';
import type { CustomLogMessageEvent } from './NativeCblLogging';
import type { QueryChangeEvent } from './NativeCblQuery';
import type { ReplicatorDocumentChangeEvent, ReplicatorStatusChangeEvent } from './NativeCblReplicator';
declare const ENGINE_EVENTS: {
    readonly replicatorStatusChange: "replicatorStatusChange";
    readonly replicatorDocumentChange: "replicatorDocumentChange";
    readonly collectionChange: "collectionChange";
    readonly collectionDocumentChange: "collectionDocumentChange";
    readonly queryChange: "queryChange";
    readonly customLogMessage: "customLogMessage";
};
type EngineEventName = (typeof ENGINE_EVENTS)[keyof typeof ENGINE_EVENTS];
type NativeEventSubscription = {
    remove(): void;
};
type EngineEventPayload = ReplicatorStatusChangeEvent | ReplicatorDocumentChangeEvent | CollectionChangeEvent | CollectionDocumentChangeEvent | QueryChangeEvent | CustomLogMessageEvent;
export declare class CblReactNativeEngine implements ICoreEngine {
    _defaultCollectionName: string;
    _defaultScopeName: string;
    debugConsole: boolean;
    platform: "ios" | "android" | "windows" | "macos" | "web";
    private _replicatorChangeListeners;
    private _replicatorDocumentChangeListeners;
    private _collectionChangeListeners;
    private _collectionDocumentChangeListeners;
    private _queryChangeListeners;
    private _emitterSubscriptions;
    private _sharedEventSubscriptions;
    private _customLogSubscription?;
    private customLogCallbacksMap;
    private _isDispatchingCustomLogCallback;
    private _fileSinkLevel;
    private _customSinkLevel;
    private get forwardLogsToSinks();
    private get _minForwardLevel();
    constructor();
    private debugLog;
    private errorLog;
    private logOpStart;
    private logOpDone;
    private logOpError;
    private logOpWarn;
    private forwardInternalLog;
    private _ensureEventSubscription;
    private _removeEventSubscriptionIfIdle;
    private _dispatchTokenEvent;
    private _removeListenerTokenAfterNativeSuccess;
    private _subscribeToEvent;
    startListeningEvents: (event: EngineEventName, callback: (data: EngineEventPayload) => void) => NativeEventSubscription;
    database_Open(args: DatabaseOpenArgs): Promise<{
        databaseUniqueName: string;
    }>;
    database_Close(args: DatabaseArgs): Promise<void>;
    database_Delete(args: DatabaseArgs): Promise<void>;
    database_DeleteWithPath(args: DatabaseExistsArgs): Promise<void>;
    database_Copy(args: DatabaseCopyArgs): Promise<void>;
    database_Exists(args: DatabaseExistsArgs): Promise<{
        exists: boolean;
    }>;
    database_GetPath(args: DatabaseArgs): Promise<{
        path: string;
    }>;
    database_PerformMaintenance(args: DatabasePerformMaintenanceArgs): Promise<void>;
    database_ChangeEncryptionKey(args: DatabaseEncryptionKeyArgs): Promise<void>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_CreateIndex instead.
     */
    database_CreateIndex(args: DatabaseCreateIndexArgs): Promise<void>;
    /**
     * @deprecated This will be removed in future versions. Use collection_DeleteDocument instead.
     */
    database_DeleteDocument(args: DatabaseDeleteDocumentArgs): Promise<void>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_DeleteIndex instead.
     */
    database_DeleteIndex(args: DatabaseDeleteIndexArgs): Promise<void>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetCount instead.
     */
    database_GetCount(args: DatabaseArgs): Promise<{
        count: number;
    }>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetDocument instead.
     */
    database_GetDocument(args: DatabaseGetDocumentArgs): Promise<DocumentResult>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_GetIndexes instead.
     */
    database_GetIndexes(args: DatabaseArgs): Promise<{
        indexes: string[];
    }>;
    /**
     * @deprecated This will be removed in future versions. Use collection_PurgeDocument instead.
     */
    database_PurgeDocument(args: DatabasePurgeDocumentArgs): Promise<void>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_Save instead.
     */
    database_Save(args: DatabaseSaveArgs): Promise<{
        _id: string;
    }>;
    collection_CreateCollection(args: CollectionArgs): Promise<NativeCollectionResult>;
    collection_DeleteCollection(args: CollectionArgs): Promise<void>;
    collection_GetCollection(args: CollectionArgs): Promise<NativeCollectionResult>;
    collection_GetCollections(args: ScopeArgs): Promise<CollectionsResult>;
    collection_GetDefault(args: DatabaseArgs): Promise<NativeCollectionResult>;
    collection_GetCount(args: CollectionArgs): Promise<{
        count: number;
    }>;
    collection_GetFullName(args: CollectionArgs): Promise<{
        fullName: string;
    }>;
    collection_CreateIndex(args: CollectionCreateIndexArgs): Promise<void>;
    collection_DeleteIndex(args: CollectionDeleteIndexArgs): Promise<void>;
    collection_GetIndexes(args: CollectionArgs): Promise<{
        indexes: string[];
    }>;
    collection_AddChangeListener(args: CollectionChangeListenerArgs, lcb: ListenerCallback): Promise<void>;
    collection_AddDocumentChangeListener(args: DocumentChangeListenerArgs, lcb: ListenerCallback): Promise<void>;
    collection_RemoveChangeListener(args: CollectionChangeListenerArgs): Promise<void>;
    collection_RemoveDocumentChangeListener(args: CollectionChangeListenerArgs): Promise<void>;
    collection_GetDocument(args: CollectionGetDocumentArgs): Promise<DocumentResult>;
    collection_Save(args: CollectionSaveStringArgs): Promise<CollectionDocumentSaveResult>;
    collection_DeleteDocument(args: CollectionDeleteDocumentArgs): Promise<void>;
    collection_PurgeDocument(args: CollectionPurgeDocumentArgs): Promise<void>;
    collection_GetDocumentExpiration(args: CollectionGetDocumentArgs): Promise<DocumentExpirationResult | null>;
    collection_SetDocumentExpiration(args: CollectionDocumentExpirationArgs): Promise<void>;
    collection_GetBlobContent(args: CollectionDocumentGetBlobContentArgs): Promise<{
        data: ArrayBuffer;
    }>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetBlobContent instead.
     */
    document_GetBlobContent(args: DocumentGetBlobContentArgs): Promise<{
        data: ArrayBuffer;
    }>;
    query_Execute(args: QueryExecuteArgs): Promise<Result>;
    query_Explain(args: QueryExecuteArgs): Promise<{
        data: string;
    }>;
    query_AddChangeListener(args: QueryChangeListenerArgs, lcb: ListenerCallback): Promise<void>;
    query_RemoveChangeListener(args: QueryRemoveChangeListenerArgs): Promise<void>;
    private safeReplicatorSummary;
    replicator_Create(args: ReplicatorCreateArgs): Promise<ReplicatorArgs>;
    replicator_Start(args: ReplicatorArgs): Promise<void>;
    replicator_Stop(args: ReplicatorArgs): Promise<void>;
    replicator_Cleanup(args: ReplicatorArgs): Promise<void>;
    replicator_GetStatus(args: ReplicatorArgs): Promise<ReplicatorStatus>;
    replicator_ResetCheckpoint(args: ReplicatorArgs): Promise<void>;
    replicator_GetPendingDocumentIds(args: ReplicatorCollectionArgs): Promise<{
        pendingDocumentIds: string[];
    }>;
    replicator_IsDocumentPending(args: ReplicatorDocumentPendingArgs): Promise<{
        isPending: boolean;
    }>;
    replicator_AddChangeListener(args: ReplicationChangeListenerArgs, lcb: ListenerCallback): Promise<void>;
    replicator_AddDocumentChangeListener(args: ReplicationChangeListenerArgs, lcb: ListenerCallback): Promise<void>;
    replicator_RemoveChangeListener(args: ReplicationChangeListenerArgs): Promise<void>;
    scope_GetDefault(args: DatabaseArgs): Promise<NativeScopeResult>;
    scope_GetScope(args: ScopeArgs): Promise<NativeScopeResult>;
    scope_GetScopes(args: DatabaseArgs): Promise<ScopesResult>;
    database_SetLogLevel(args: DatabaseSetLogLevelArgs): Promise<void>;
    database_SetFileLoggingConfig(args: DatabaseSetFileLoggingConfigArgs): Promise<void>;
    /**
     * Sets or disables the console log sink
     * @param args Arguments containing level and domains, or null to disable
     */
    logsinks_SetConsole(args: LogSinksSetConsoleArgs): Promise<void>;
    /**
     * Sets or disables the file log sink
     * @param args Arguments containing level and config, or null to disable
     */
    logsinks_SetFile(args: LogSinksSetFileArgs): Promise<void>;
    /**
     * Sets or disables the custom log sink
     * @param args Arguments containing level, domains, and token, or null to disable
     */
    logsinks_SetCustom(args: LogSinksSetCustomArgs): Promise<void>;
    /**
     * Writes a single log message into the CBL logging pipeline (file + console +
     * custom). Public-facing validation (level/domain scope) happens in
     * LogSinks.write; here we only enforce the custom-sink recursion guard before
     * crossing the bridge.
     */
    logging_WriteLog(level: LogLevel, domain: LogDomain, message: string): Promise<void>;
    file_GetDefaultPath(): Promise<{
        path: string;
    }>;
    file_GetFileNamesInDirectory(args: {
        path: string;
    }): Promise<{
        files: string[];
    }>;
    /**
     * Generic method to remove any listener by its UUID token.
     * Calls the native listenerToken_Remove method via NativeCblEngine.
     */
    listenerToken_Remove(args: {
        changeListenerToken: string;
    }): Promise<void>;
    URLEndpointListener_createListener(args: URLEndpointListenerCreateArgs): Promise<{
        listenerId: string;
    }>;
    URLEndpointListener_startListener(args: URLEndpointListenerArgs): Promise<void>;
    URLEndpointListener_stopListener(args: URLEndpointListenerArgs): Promise<void>;
    URLEndpointListener_getStatus(args: URLEndpointListenerArgs): Promise<URLEndpointListenerStatus>;
    URLEndpointListener_deleteIdentity(args: URLEndpointListenerTLSIdentityArgs): Promise<void>;
    getUUID(): string;
    /**
     * Tears down all engine-owned native subscriptions and clears in-memory state.
     *
     * Safe to call multiple times. After dispose() the engine instance should be
     * considered unusable; create a new one (and re-register via EngineLocator)
     * to resume work.
     *
     * Today this is only useful in:
     *   - Jest tests that want to assert subscriptions are released.
     *   - Hot-reload scenarios in dev where the JS bundle is replaced but the
     *     native side keeps the previous subscription alive.
     */
    dispose(): void;
}
export {};
//# sourceMappingURL=CblReactNativeEngine.d.ts.map