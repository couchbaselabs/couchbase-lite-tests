import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    file_GetDefaultPath(): Promise<string>;
    file_GetFileNamesInDirectory(path: string): Promise<{
        files: string[];
    }>;
    listenerToken_Remove(changeListenerToken: string): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCblEngine.d.ts.map