import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    scope_GetDefault(databaseUniqueName: string): Promise<Object>;
    scope_GetScope(databaseUniqueName: string, scopeName: string): Promise<Object>;
    scope_GetScopes(databaseUniqueName: string): Promise<Object>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeCblScope.d.ts.map