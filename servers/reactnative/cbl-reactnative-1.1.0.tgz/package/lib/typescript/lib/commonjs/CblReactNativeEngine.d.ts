export const __esModule: boolean;
export class CblReactNativeEngine {
    _defaultCollectionName: string;
    _defaultScopeName: string;
    debugConsole: boolean;
    platform: "ios" | "android" | "windows" | "macos" | "web";
    _replicatorChangeListeners: Map<any, any>;
    _replicatorDocumentChangeListeners: Map<any, any>;
    _collectionChangeListeners: Map<any, any>;
    _collectionDocumentChangeListeners: Map<any, any>;
    _queryChangeListeners: Map<any, any>;
    _emitterSubscriptions: Map<any, any>;
    _sharedEventSubscriptions: Map<any, any>;
    customLogCallbacksMap: Map<any, any>;
    _isDispatchingCustomLogCallback: boolean;
    _fileSinkLevel: any;
    _customSinkLevel: any;
    get forwardLogsToSinks(): boolean;
    get _minForwardLevel(): any;
    _customLogSubscription: any;
    debugLog(message: any, domain?: any, level?: any, forwardedMessage?: any): void;
    errorLog(message: any, domain?: any, forwardedMessage?: any): void;
    logOpStart(method: any, domain?: any, consoleDetail?: string, forwardedDetail?: string, level?: any): void;
    logOpDone(method: any, domain?: any, consoleDetail?: string, forwardedDetail?: string, level?: any): void;
    logOpError(method: any, rawError: any, domain?: any, forwardedDetail?: string): void;
    logOpWarn(method: any, reason: any, domain?: any, forwardedDetail?: string): void;
    forwardInternalLog(level: any, domain: any, message: any): void;
    _ensureEventSubscription(eventName: any, handler: any): any;
    _removeEventSubscriptionIfIdle(eventName: any, listeners: any): void;
    _dispatchTokenEvent(eventName: any, listeners: any, payload: any, selectCallbackArgs: any): void;
    _removeListenerTokenAfterNativeSuccess(token: any, nativeRemove: any, listenerMaps: any, afterRemove: any): Promise<void>;
    _subscribeToEvent(eventName: any, callback: any): any;
    startListeningEvents: (event: any, callback: any) => any;
    database_Open(args: any): Promise<any>;
    database_Close(args: any): Promise<any>;
    database_Delete(args: any): Promise<any>;
    database_DeleteWithPath(args: any): Promise<any>;
    database_Copy(args: any): Promise<any>;
    database_Exists(args: any): Promise<any>;
    database_GetPath(args: any): Promise<any>;
    database_PerformMaintenance(args: any): Promise<any>;
    database_ChangeEncryptionKey(args: any): Promise<any>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_CreateIndex instead.
     */
    database_CreateIndex(args: any): Promise<any>;
    /**
     * @deprecated This will be removed in future versions. Use collection_DeleteDocument instead.
     */
    database_DeleteDocument(args: any): Promise<any>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_DeleteIndex instead.
     */
    database_DeleteIndex(args: any): Promise<any>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetCount instead.
     */
    database_GetCount(args: any): Promise<any>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetDocument instead.
     */
    database_GetDocument(args: any): Promise<any>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_GetIndexes instead.
     */
    database_GetIndexes(args: any): Promise<any>;
    /**
     * @deprecated This will be removed in future versions. Use collection_PurgeDocument instead.
     */
    database_PurgeDocument(args: any): Promise<any>;
    /**
     * @deprecated This function will be removed in future versions. Use collection_Save instead.
     */
    database_Save(args: any): Promise<any>;
    collection_CreateCollection(args: any): Promise<any>;
    collection_DeleteCollection(args: any): Promise<any>;
    collection_GetCollection(args: any): Promise<any>;
    collection_GetCollections(args: any): Promise<any>;
    collection_GetDefault(args: any): Promise<any>;
    collection_GetCount(args: any): Promise<any>;
    collection_GetFullName(args: any): Promise<any>;
    collection_CreateIndex(args: any): Promise<any>;
    collection_DeleteIndex(args: any): Promise<any>;
    collection_GetIndexes(args: any): Promise<any>;
    collection_AddChangeListener(args: any, lcb: any): Promise<any>;
    collection_AddDocumentChangeListener(args: any, lcb: any): Promise<any>;
    collection_RemoveChangeListener(args: any): Promise<void>;
    collection_RemoveDocumentChangeListener(args: any): Promise<void>;
    collection_GetDocument(args: any): Promise<any>;
    collection_Save(args: any): Promise<any>;
    collection_DeleteDocument(args: any): Promise<any>;
    collection_PurgeDocument(args: any): Promise<any>;
    collection_GetDocumentExpiration(args: any): Promise<any>;
    collection_SetDocumentExpiration(args: any): Promise<any>;
    collection_GetBlobContent(args: any): Promise<any>;
    /**
     * @deprecated This will be removed in future versions. Use collection_GetBlobContent instead.
     */
    document_GetBlobContent(args: any): Promise<any>;
    query_Execute(args: any): Promise<any>;
    query_Explain(args: any): Promise<any>;
    query_AddChangeListener(args: any, lcb: any): Promise<any>;
    query_RemoveChangeListener(args: any): Promise<void>;
    safeReplicatorSummary(config: any): string;
    replicator_Create(args: any): Promise<any>;
    replicator_Start(args: any): Promise<any>;
    replicator_Stop(args: any): Promise<any>;
    replicator_Cleanup(args: any): Promise<any>;
    replicator_GetStatus(args: any): Promise<any>;
    replicator_ResetCheckpoint(args: any): Promise<any>;
    replicator_GetPendingDocumentIds(args: any): Promise<any>;
    replicator_IsDocumentPending(args: any): Promise<any>;
    replicator_AddChangeListener(args: any, lcb: any): Promise<any>;
    replicator_AddDocumentChangeListener(args: any, lcb: any): Promise<any>;
    replicator_RemoveChangeListener(args: any): Promise<void>;
    scope_GetDefault(args: any): Promise<any>;
    scope_GetScope(args: any): Promise<any>;
    scope_GetScopes(args: any): Promise<any>;
    database_SetLogLevel(args: any): Promise<any>;
    database_SetFileLoggingConfig(args: any): Promise<any>;
    /**
     * Sets or disables the console log sink
     * @param args Arguments containing level and domains, or null to disable
     */
    logsinks_SetConsole(args: any): Promise<any>;
    /**
     * Sets or disables the file log sink
     * @param args Arguments containing level and config, or null to disable
     */
    logsinks_SetFile(args: any): Promise<void>;
    /**
     * Sets or disables the custom log sink
     * @param args Arguments containing level, domains, and token, or null to disable
     */
    logsinks_SetCustom(args: any): Promise<void>;
    /**
     * Writes a single log message into the CBL logging pipeline (file + console +
     * custom). Public-facing validation (level/domain scope) happens in
     * LogSinks.write; here we only enforce the custom-sink recursion guard before
     * crossing the bridge.
     */
    logging_WriteLog(level: any, domain: any, message: any): any;
    file_GetDefaultPath(): Promise<any>;
    file_GetFileNamesInDirectory(args: any): Promise<any>;
    /**
     * Generic method to remove any listener by its UUID token.
     * Calls the native listenerToken_Remove method via NativeCblEngine.
     */
    listenerToken_Remove(args: any): any;
    URLEndpointListener_createListener(args: any): Promise<never>;
    URLEndpointListener_startListener(args: any): Promise<never>;
    URLEndpointListener_stopListener(args: any): Promise<never>;
    URLEndpointListener_getStatus(args: any): Promise<never>;
    URLEndpointListener_deleteIdentity(args: any): Promise<never>;
    getUUID(): any;
    /**
     * Tears down all engine-owned native subscriptions and clears in-memory state.
     *
     * Safe to call multiple times. After dispose() the engine instance should be
     * considered unusable; create a new one (and re-register via EngineLocator)
     * to resume work.
     *
     * Today this is only useful in:
     *   - Jest tests that want to assert subscriptions are released.
     *   - Hot-reload scenarios in dev where the JS bundle is replaced but the
     *     native side keeps the previous subscription alive.
     */
    dispose(): void;
}
//# sourceMappingURL=CblReactNativeEngine.d.ts.map