declare const _default: import("react-native").TurboModule;
export default _default;
//# sourceMappingURL=NativeCblDatabase.d.ts.map