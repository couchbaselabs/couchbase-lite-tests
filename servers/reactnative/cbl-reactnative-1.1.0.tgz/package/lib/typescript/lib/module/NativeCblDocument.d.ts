declare const _default: import("react-native").TurboModule;
export default _default;
//# sourceMappingURL=NativeCblDocument.d.ts.map