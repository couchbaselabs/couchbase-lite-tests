declare const _default: import("react-native").TurboModule;
export default _default;
//# sourceMappingURL=NativeCblReplicator.d.ts.map