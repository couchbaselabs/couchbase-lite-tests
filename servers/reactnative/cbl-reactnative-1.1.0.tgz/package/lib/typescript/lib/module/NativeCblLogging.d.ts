declare const _default: import("react-native").TurboModule;
export default _default;
//# sourceMappingURL=NativeCblLogging.d.ts.map