require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "cbl-reactnative"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => min_ios_version_supported }
  s.source       = { :git => "https://github.com/couchbase/couchbase-lite-react-native.git", :tag => "#{s.version}" }

  s.swift_version = '5.5'
  s.dependency 'CouchbaseLite-Swift-Enterprise', '3.3.3'
  s.source_files = "ios/**/*.{h,m,mm,swift}", "cblite-js-common/cbl-js-swift/**/*.swift"
  # Legacy old-arch bridge sources are kept in-repo for reference only (see file headers).
  s.exclude_files = "ios/legacy_*.{h,m,mm,swift}"
  # RCTCblModules.h imports C++ TurboModule specs, which breaks the ObjC module
  # umbrella header scanned by Swift's -import-underlying-module. Marking it
  # private keeps it out of the umbrella while still accessible to the .mm file.
  s.private_header_files = "ios/RCTCblModules.h"

  install_modules_dependencies(s)
end
